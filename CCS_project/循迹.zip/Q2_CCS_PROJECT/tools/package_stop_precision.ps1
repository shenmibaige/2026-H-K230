[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Repository,

    [Parameter(Mandatory = $true)]
    [string]$BaselineZip,

    [Parameter(Mandatory = $true)]
    [string]$PinWorkbook,

    [Parameter(Mandatory = $true)]
    [string]$ProblemPdf,

    [Parameter(Mandatory = $true)]
    [string]$OutputDirectory
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$fixedTime = [DateTimeOffset]::new(
    2000, 1, 1, 0, 0, 0, [TimeSpan]::Zero)

function Get-Sha256Bytes
{
    param([byte[]]$Bytes)

    $sha = [Security.Cryptography.SHA256]::Create()
    try
    {
        return ([BitConverter]::ToString(
            $sha.ComputeHash($Bytes))).Replace('-', '')
    }
    finally
    {
        $sha.Dispose()
    }
}

function New-PackageEntry
{
    param(
        [string]$Path,
        [byte[]]$Bytes
    )

    [pscustomobject]@{
        Path = $Path.Replace('\', '/')
        Bytes = $Bytes
        Length = $Bytes.LongLength
        SHA256 = Get-Sha256Bytes $Bytes
    }
}

function Write-DeterministicZip
{
    param(
        [string]$Path,
        [object[]]$Entries
    )

    if ([IO.File]::Exists($Path))
    {
        throw "Refusing to overwrite existing file: $Path"
    }

    $stream = New-Object IO.FileStream(
        $Path,
        [IO.FileMode]::CreateNew,
        [IO.FileAccess]::Write,
        [IO.FileShare]::None)
    try
    {
        $archive = New-Object IO.Compression.ZipArchive(
            $stream,
            [IO.Compression.ZipArchiveMode]::Create,
            $false,
            $utf8NoBom)
        try
        {
            foreach ($item in @($Entries | Sort-Object Path))
            {
                $entry = $archive.CreateEntry(
                    $item.Path,
                    [IO.Compression.CompressionLevel]::Optimal)
                $entry.LastWriteTime = $fixedTime
                $entryStream = $entry.Open()
                try
                {
                    $entryStream.Write(
                        $item.Bytes,
                        0,
                        $item.Bytes.Length)
                }
                finally
                {
                    $entryStream.Dispose()
                }
            }
        }
        finally
        {
            $archive.Dispose()
        }
    }
    finally
    {
        $stream.Dispose()
    }
}

$repositoryPath = (Resolve-Path -LiteralPath $Repository).Path
$baselineZipPath = (Resolve-Path -LiteralPath $BaselineZip).Path
$pinWorkbookPath = (Resolve-Path -LiteralPath $PinWorkbook).Path
$problemPdfPath = (Resolve-Path -LiteralPath $ProblemPdf).Path
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$outputPath = (Resolve-Path -LiteralPath $OutputDirectory).Path

$status = @(git -C $repositoryPath status --porcelain)
if ($LASTEXITCODE -ne 0)
{
    throw 'git status failed'
}
if ($status.Count -ne 0)
{
    throw 'Repository must be clean before packaging'
}

$commit = (git -C $repositoryPath rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0)
{
    throw 'git rev-parse failed'
}
$shortCommit = $commit.Substring(0, 7)

$tracked = @(git -C $repositoryPath ls-files)
if ($LASTEXITCODE -ne 0)
{
    throw 'git ls-files failed'
}

$entries = New-Object Collections.Generic.List[object]
foreach ($relativePath in @($tracked | Sort-Object))
{
    $nativeRelative = $relativePath.Replace(
        '/', [IO.Path]::DirectorySeparatorChar)
    $sourcePath = Join-Path $repositoryPath $nativeRelative
    if (-not [IO.File]::Exists($sourcePath))
    {
        throw "Tracked file is missing: $relativePath"
    }
    $entries.Add((New-PackageEntry `
        -Path "Q2_CCS_PROJECT/$relativePath" `
        -Bytes ([IO.File]::ReadAllBytes($sourcePath))))
}

$entries.Add((New-PackageEntry `
    -Path 'REFERENCE_READONLY/balance_car_v1.3.zip' `
    -Bytes ([IO.File]::ReadAllBytes($baselineZipPath))))
$entries.Add((New-PackageEntry `
    -Path 'REFERENCE_READONLY/NEW_PIN_ASSIGNMENT.xlsx' `
    -Bytes ([IO.File]::ReadAllBytes($pinWorkbookPath))))
$entries.Add((New-PackageEntry `
    -Path 'REFERENCE_READONLY/H_problem.pdf' `
    -Bytes ([IO.File]::ReadAllBytes($problemPdfPath))))

$firmwarePath =
    Join-Path $repositoryPath 'firmware_stop_precision\05_OLED.out'
$firmwareHash = (
    Get-FileHash -Algorithm SHA256 -LiteralPath $firmwarePath
).Hash
$baselineHash = (
    Get-FileHash -Algorithm SHA256 -LiteralPath $baselineZipPath
).Hash
$pinHash = (
    Get-FileHash -Algorithm SHA256 -LiteralPath $pinWorkbookPath
).Hash
$pdfHash = (
    Get-FileHash -Algorithm SHA256 -LiteralPath $problemPdfPath
).Hash

$readme = @"
# H Q2 v1.3 stopping-precision delivery

Git commit: $commit

Flash only:
Q2_CCS_PROJECT/firmware_stop_precision/05_OLED.out

Firmware SHA-256:
$firmwareHash

Do not flash historical OUT files under Debug, firmware_smooth_pid or other
legacy directories.

Reference SHA-256:
- balance_car_v1.3.zip: $baselineHash
- NEW_PIN_ASSIGNMENT.xlsx: $pinHash
- H_problem.pdf: $pdfHash

Code implementation, host tests, target syntax check, static audit, baseline
CCS Clean/Full Build and optimized CCS Clean/Full Build have passed.  The
firmware has not been downloaded and has not completed wheel-direction,
current, temperature, lap-time or ten-run stopping-error tests.

Read first:
- Q2_CCS_PROJECT/README_STOP_PRECISION.md
- Q2_CCS_PROJECT/STOP_PRECISION_BUILD_REPORT.md
- Q2_CCS_PROJECT/docs/STOP_PRECISION_ENGINEERING.md
- Q2_CCS_PROJECT/docs/STOP_PRECISION_BOARD_TEST.md
"@
$entries.Add((New-PackageEntry `
    -Path 'PACKAGE_README.md' `
    -Bytes $utf8NoBom.GetBytes(
        $readme.Replace("`r`n", "`n"))))

$manifestLines = New-Object Collections.Generic.List[string]
$manifestLines.Add('path,length,sha256')
foreach ($item in @($entries | Sort-Object Path))
{
    $escapedPath = $item.Path.Replace('"', '""')
    $manifestLines.Add(
        "`"$escapedPath`",$($item.Length),$($item.SHA256)")
}
$manifestText = ($manifestLines -join "`n") + "`n"
$entries.Add((New-PackageEntry `
    -Path 'MANIFEST_SHA256.csv' `
    -Bytes $utf8NoBom.GetBytes($manifestText)))

$baseName =
    "H_Q2_v13_stop_precision_20260730_$shortCommit"
$pass1 = Join-Path $outputPath "$baseName.pass1.tmp"
$pass2 = Join-Path $outputPath "$baseName.pass2.tmp"
$finalZip = Join-Path $outputPath "$baseName.zip"

foreach ($candidate in @($pass1, $pass2, $finalZip))
{
    if ([IO.File]::Exists($candidate))
    {
        throw "Refusing to overwrite existing package: $candidate"
    }
}

Write-DeterministicZip -Path $pass1 -Entries $entries
Write-DeterministicZip -Path $pass2 -Entries $entries
$hash1 = (Get-FileHash -Algorithm SHA256 -LiteralPath $pass1).Hash
$hash2 = (Get-FileHash -Algorithm SHA256 -LiteralPath $pass2).Hash
if ($hash1 -ne $hash2)
{
    throw "Deterministic ZIP mismatch: $hash1 != $hash2"
}

[IO.File]::Move($pass1, $finalZip)
[IO.File]::Delete($pass2)

$expected = @{}
foreach ($item in $entries)
{
    $expected[$item.Path] = $item
}

$mismatches = New-Object Collections.Generic.List[string]
$fileStream = [IO.File]::OpenRead($finalZip)
try
{
    $archive = New-Object IO.Compression.ZipArchive(
        $fileStream,
        [IO.Compression.ZipArchiveMode]::Read,
        $false,
        $utf8NoBom)
    try
    {
        $actualNames = @(
            $archive.Entries |
            ForEach-Object FullName)
        $expectedNames = @(
            $entries |
            Sort-Object Path |
            ForEach-Object Path)

        if (($actualNames -join "`n") -ne
            ($expectedNames -join "`n"))
        {
            $mismatches.Add('ORDER,ZIP entries are not sorted')
        }

        foreach ($expectedName in $expected.Keys)
        {
            if ($actualNames -notcontains $expectedName)
            {
                $mismatches.Add("MISSING,$expectedName")
            }
        }
        foreach ($actualName in $actualNames)
        {
            if (-not $expected.ContainsKey($actualName))
            {
                $mismatches.Add("EXTRA,$actualName")
            }
        }

        foreach ($entry in $archive.Entries)
        {
            if (-not $expected.ContainsKey($entry.FullName))
            {
                continue
            }

            $memory = New-Object IO.MemoryStream
            $entryStream = $entry.Open()
            try
            {
                $entryStream.CopyTo($memory)
            }
            finally
            {
                $entryStream.Dispose()
            }
            $bytes = $memory.ToArray()
            $memory.Dispose()
            $expectedItem = $expected[$entry.FullName]
            if ($bytes.LongLength -ne $expectedItem.Length)
            {
                $mismatches.Add("LENGTH,$($entry.FullName)")
            }
            if ((Get-Sha256Bytes $bytes) -ne
                $expectedItem.SHA256)
            {
                $mismatches.Add("SHA256,$($entry.FullName)")
            }
        }
        $entryCount = $archive.Entries.Count
    }
    finally
    {
        $archive.Dispose()
    }
}
finally
{
    $fileStream.Dispose()
}

$zipHash = (
    Get-FileHash -Algorithm SHA256 -LiteralPath $finalZip
).Hash
$hashPath = "$finalZip.sha256"
$verificationPath = "$finalZip.verification.txt"
[IO.File]::WriteAllText(
    $hashPath,
    "$zipHash  $([IO.Path]::GetFileName($finalZip))`n",
    $utf8NoBom)

$verificationLines = @(
    "ZIP=$finalZip",
    "SHA256=$zipHash",
    "COMMIT=$commit",
    "DETERMINISTIC_PASS1=$hash1",
    "DETERMINISTIC_PASS2=$hash2",
    "ENTRY_COUNT=$entryCount",
    "EXPECTED_COUNT=$($entries.Count)",
    "MISMATCH_COUNT=$($mismatches.Count)"
) + $mismatches
[IO.File]::WriteAllText(
    $verificationPath,
    (($verificationLines -join "`n") + "`n"),
    $utf8NoBom)

if ($mismatches.Count -ne 0)
{
    throw "ZIP verification failed: $($mismatches.Count) mismatch(es)"
}

Write-Host "ZIP=$finalZip"
Write-Host "SHA256=$zipHash"
Write-Host "ENTRY_COUNT=$entryCount"
Write-Host 'MISMATCH_COUNT=0'
Write-Host "VERIFICATION=$verificationPath"
