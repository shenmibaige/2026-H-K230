[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$projectRoot = Split-Path -Parent $PSScriptRoot
$provinceRoot =
    Split-Path -Parent (
        Split-Path -Parent (
            Split-Path -Parent $projectRoot))
$failures = 0

function Assert-Check
{
    param(
        [bool]$Condition,
        [string]$Message
    )

    if ($Condition)
    {
        Write-Host "PASS: $Message"
    }
    else
    {
        Write-Host "FAIL: $Message"
        $script:failures++
    }
}

$v13ZipMatches = @(
    Get-ChildItem -LiteralPath $provinceRoot -Recurse -File `
        -Filter 'balance_car_v1.3.zip' |
        Where-Object {
            $_.Directory.Parent.FullName -eq $provinceRoot
        }
)
$pinWorkbookMatches = @(
    Get-ChildItem -LiteralPath $provinceRoot -Recurse -File `
        -Filter '*xlsx' |
        Where-Object {
            ($_.Directory.Parent.FullName -eq $provinceRoot) -and
            ((Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash -eq
                '3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61'
            )
        }
)
Assert-Check ($v13ZipMatches.Count -eq 1) `
    'exactly one read-only balance_car_v1.3.zip was found'
Assert-Check ($pinWorkbookMatches.Count -eq 1) `
    'exactly one authoritative pin workbook was found by hash'
if (($v13ZipMatches.Count -ne 1) -or
    ($pinWorkbookMatches.Count -ne 1))
{
    throw 'Cannot uniquely resolve immutable source inputs'
}
$v13Zip = $v13ZipMatches[0].FullName
$pinWorkbook = $pinWorkbookMatches[0].FullName

Assert-Check `
    ((Get-FileHash -Algorithm SHA256 -LiteralPath $v13Zip).Hash -eq
        '799A72B54C33F1E3978712380EC146B4702F4090488F1086A75913980E7F5B8B') `
    'read-only balance_car_v1.3.zip is unchanged'
Assert-Check `
    ((Get-FileHash -Algorithm SHA256 -LiteralPath $pinWorkbook).Hash -eq
        '3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61') `
    'authoritative pin workbook is unchanged'

$protected = [ordered]@{
    'empty.syscfg' =
        'D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66'
    'Debug\ti_msp_dl_config.h' =
        '219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0'
    'Debug\ti_msp_dl_config.c' =
        '8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6'
    'driver\uart.c' =
        '35036AA5EC1ED315DDCE5B138C481F17CF9354AC61D9509B001A591B6C3DEDFB'
    'driver\uart.h' =
        '37546411CA0CA64D2AF0870BCAB9947C3CEFF75BE9C8077A53A440D193BC657C'
}
foreach ($entry in $protected.GetEnumerator())
{
    $path = Join-Path $projectRoot $entry.Key
    $actual =
        (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash
    Assert-Check ($actual -eq $entry.Value) `
        "protected file unchanged: $($entry.Key)"
}

$params =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_params.h') `
        -Raw -Encoding UTF8
$controlHeader =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_control.h') `
        -Raw -Encoding UTF8
$control =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_control.c') `
        -Raw -Encoding UTF8
$main =
    Get-Content -LiteralPath (Join-Path $projectRoot 'main.c') `
        -Raw -Encoding UTF8
$motor =
    Get-Content -LiteralPath (
        Join-Path $projectRoot 'driver\motor.c') `
        -Raw -Encoding UTF8
$uart =
    (Get-Content -LiteralPath (
        Join-Path $projectRoot 'driver\uart.c') `
        -Raw -Encoding UTF8) + "`n" +
    (Get-Content -LiteralPath (
        Join-Path $projectRoot 'driver\uart.h') `
        -Raw -Encoding UTF8)

Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_LINE_PID_KP\s+0\.48f[\s\S]*?' +
        'CURVE_LINE_PID_KI\s+0\.01f[\s\S]*?' +
        'CURVE_LINE_PID_KD\s+0\.25f[\s\S]*?' +
        'CURVE_LINE_PID_I_OUT_LIMIT\s+15\.0f[\s\S]*?' +
        'CURVE_LINE_PID_OUT_LIMIT\s+52\.0f')) `
    'verified v1.3 tracing PID remains unchanged'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_BASE_STRAIGHT_PWM\s+98[\s\S]*?' +
        'CURVE_BASE_MID_PWM\s+80[\s\S]*?' +
        'CURVE_BASE_OUTER_PWM\s+65[\s\S]*?' +
        'CURVE_PWM_LIMIT\s+100')) `
    'normal v1.3 speed schedule remains unchanged'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_FINISH_APPROACH_STAGE1_MS\s+12000U[\s\S]*?' +
        'CURVE_FINISH_APPROACH_STAGE2_MS\s+14000U[\s\S]*?' +
        'CURVE_FINISH_RAW_CONFIRM_SAMPLES\s+2U')) `
    '12/14 s approach stages and 2 ms finish confirmation are configured'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_APPROACH1_STRAIGHT_PWM\s+82[\s\S]*?' +
        'CURVE_APPROACH1_MID_PWM\s+70[\s\S]*?' +
        'CURVE_APPROACH1_OUTER_PWM\s+58[\s\S]*?' +
        'CURVE_APPROACH2_STRAIGHT_PWM\s+60[\s\S]*?' +
        'CURVE_APPROACH2_MID_PWM\s+54[\s\S]*?' +
        'CURVE_APPROACH2_OUTER_PWM\s+46')) `
    'two-stage final-approach PWM schedule is centralized'

foreach ($api in @(
        'CurveControl_Init',
        'CurveControl_Start',
        'CurveControl_PushSample1ms',
        'CurveControl_Step5ms',
        'CurveControl_StopImmediate'))
{
    Assert-Check ($controlHeader -match "\b$api\s*\(") `
        "public control API remains available: $api"
}
Assert-Check `
    ([regex]::IsMatch(
        $controlHeader,
        'approach_stage[\s\S]*?finish_trigger')) `
    'approach and finish diagnostics are exposed'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'filtered_mask\s*==\s*0U[\s\S]*?' +
        'gap_hold\s*=\s*1U[\s\S]*?return\s*;')) `
    '00000 still holds the complete control state'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'state\s*==\s*CURVE_STATE_FINISH_ARMED[\s\S]*?' +
        'CurveControl_IsFinishCandidate\s*\(\s*raw_mask\s*\)' +
        '[\s\S]*?CURVE_FINISH_RAW_CONFIRM_SAMPLES[\s\S]*?' +
        'CURVE_FINISH_TRIGGER_RAW_FAST')) `
    'raw BCD fast finish is restricted to FINISH_ARMED'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'CURVE_FINISH_CONFIRM_CYCLES[\s\S]*?' +
        'CURVE_FINISH_TRIGGER_FILTERED_FALLBACK')) `
    'filtered BCD x3 finish remains as fallback'
Assert-Check `
    (-not [regex]::IsMatch(
        $main,
        '\bSpeed[12]PID\b|PID_SetActualMagnitude\s*\(')) `
    'encoder remains telemetry-only'
Assert-Check `
    ([regex]::IsMatch(
        $main,
        'Motor1_SetSpeed\s*\(\s*output\.right_pwm\s*\)[\s\S]*?' +
        'Motor2_SetSpeed\s*\(\s*output\.left_pwm\s*\)')) `
    'Motor1 remains right wheel and Motor2 remains left wheel'

$isrMatch =
    [regex]::Match(
        $main,
        'void\s+TIMER_PID_INST_IRQHandler\s*\(\s*void\s*\)[\s\S]*$')
Assert-Check $isrMatch.Success '1 ms timer ISR is present'
if ($isrMatch.Success)
{
    $isr = $isrMatch.Value
    Assert-Check `
        (-not [regex]::IsMatch(
            $isr,
            '\b(?:OLED_|UART|printf|sprintf|delay_)[A-Za-z0-9_]*\s*\(')) `
        'ISR contains no OLED, UART, formatting or delay calls'

    $k4Index = $isr.IndexOf('Key_IsPressed')
    $sampleIndex = $isr.IndexOf('CurveControl_PushSample1ms')
    Assert-Check `
        (($k4Index -ge 0) -and
         ($sampleIndex -ge 0) -and
         ($k4Index -lt $sampleIndex)) `
        'K4 check has priority over finish sampling'
    Assert-Check `
        ([regex]::IsMatch(
            $isr,
            'CURVE_FINISH_TRIGGER_RAW_FAST[\s\S]*?' +
            'Motor_StopSafe\s*\(\s*\)[\s\S]*?return\s*;')) `
        'raw finish calls Motor_StopSafe in the same 1 ms ISR'
}

Assert-Check `
    ([regex]::IsMatch(
        $motor,
        'Motor1_SetSpeed[\s\S]*?' +
        'DL_GPIO_clearPins\s*\(\s*DC_MOTOR_AIN1_PORT[\s\S]*?' +
        'DL_GPIO_setPins\s*\(\s*DC_MOTOR_AIN2_PORT')) `
    'Motor1 reversed-forward electrical direction is preserved'
Assert-Check `
    ([regex]::IsMatch(
        $motor,
        'Motor_StopSafe[\s\S]*?Motor1_Brake\s*\(\s*\)' +
        '[\s\S]*?Motor2_Brake\s*\(\s*\)')) `
    'finish uses safe short braking without reverse drive'
Assert-Check `
    (-not [regex]::IsMatch(
        $uart,
        '\b(?:Motor1_SetSpeed|Motor2_SetSpeed|Motor_StopSafe|' +
        'CurveControl_|PID_Update)\s*\(')) `
    'UART cannot control motors, PID or race state'

$allC =
    @(Get-ChildItem -LiteralPath $projectRoot -Recurse `
        -Filter '*.c' -File |
        Where-Object {
            $_.FullName -notmatch '\\Debug\\' -and
            $_.FullName -notmatch '\\tests\\build\\'
        } |
        ForEach-Object {
            Get-Content -LiteralPath $_.FullName `
                -Raw -Encoding UTF8
        }) -join "`n"
Assert-Check `
    ([regex]::Matches(
        $allC,
        '\bGROUP1_IRQHandler\s*\(').Count -eq 1) `
    'GROUP1 encoder IRQ has exactly one definition'
Assert-Check `
    ([regex]::Matches(
        $allC,
        '\bTIMER_PID_INST_IRQHandler\s*\(').Count -eq 1) `
    'TIMER_PID IRQ has exactly one definition'

& (Join-Path $projectRoot 'tests\run_host_tests.ps1')
Assert-Check ($LASTEXITCODE -eq 0) `
    'stop-precision host tests pass'
& (Join-Path $projectRoot 'tests\run_target_syntax_check.ps1')
Assert-Check ($LASTEXITCODE -eq 0) `
    'target-source stub syntax check passes'

if ($failures -ne 0)
{
    throw "Stop-precision static audit failed: $failures check(s)"
}

Write-Host 'STOP-PRECISION STATIC AUDIT: PASS'
