[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$projectRoot = Split-Path -Parent $PSScriptRoot
$failures = 0

function Assert-Check
{
    param(
        [bool]$Condition,
        [string]$Message
    )

    if ($Condition)
    {
        Write-Host "PASS: $Message"
    }
    else
    {
        Write-Host "FAIL: $Message"
        $script:failures++
    }
}

$provinceRoot =
    Split-Path -Parent (
        Split-Path -Parent (
            Split-Path -Parent $projectRoot))
$originZip =
    @(Get-ChildItem -LiteralPath $provinceRoot -Recurse -File `
        -Filter 'balance_car_v1.2.zip' |
        Where-Object { $_.Directory.Name -eq 'Origin' })[0].FullName
$pinWorkbook =
    @(Get-ChildItem -LiteralPath $provinceRoot -Recurse -File `
        -Filter '*.xlsx' |
        Where-Object {
            (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash -eq
            '3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61'
        })[0].FullName

Assert-Check `
    ((Get-FileHash -Algorithm SHA256 -LiteralPath $originZip).Hash -eq
        '3DEBC6D4D1279209CD606419204B592F264D5112125681E7BB3ADD09E88BE20E') `
    'balance_car_v1.2.zip SHA-256 is unchanged'
Assert-Check `
    ((Get-FileHash -Algorithm SHA256 -LiteralPath $pinWorkbook).Hash -eq
        '3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61') `
    'authoritative pin workbook SHA-256 is unchanged'

$protected = [ordered]@{
    'empty.syscfg' =
        'D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66'
    'Debug\ti_msp_dl_config.h' =
        '219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0'
    'Debug\ti_msp_dl_config.c' =
        '8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6'
    'driver\uart.c' =
        '35036AA5EC1ED315DDCE5B138C481F17CF9354AC61D9509B001A591B6C3DEDFB'
    'driver\uart.h' =
        '37546411CA0CA64D2AF0870BCAB9947C3CEFF75BE9C8077A53A440D193BC657C'
}
foreach ($entry in $protected.GetEnumerator())
{
    $actual =
        (Get-FileHash -Algorithm SHA256 `
            -LiteralPath (Join-Path $projectRoot $entry.Key)).Hash
    Assert-Check ($actual -eq $entry.Value) `
        "protected file unchanged: $($entry.Key)"
}

$params =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_params.h') `
        -Raw -Encoding UTF8
$control =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_control.c') `
        -Raw -Encoding UTF8
$graySource =
    Get-Content -LiteralPath (Join-Path $projectRoot 'huidu.c') `
        -Raw -Encoding UTF8
$pidSource =
    Get-Content -LiteralPath (Join-Path $projectRoot 'pid.c') `
        -Raw -Encoding UTF8
$main =
    Get-Content -LiteralPath (Join-Path $projectRoot 'main.c') `
        -Raw -Encoding UTF8

Assert-Check ($params -match '#define\s+CURVE_TARGET_STRAIGHT\s+60') `
    'straight encoder target is reduced from 100 to 60'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_TRACK_RADIUS_MM\s+500[\s\S]*?' +
        'CURVE_WHEEL_TRACK_MM\s+180[\s\S]*?' +
        'CURVE_WHEEL_DIAMETER_MM\s+65')) `
    'course radius, wheel track and wheel diameter facts are recorded'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_TARGET_SLIGHT_INNER\s+48[\s\S]*?' +
        'CURVE_TARGET_SLIGHT_OUTER\s+69')) `
    'nominal arc targets approximate the 410/590 wheel-radius ratio'
Assert-Check ($params -match '#define\s+CURVE_SPEED_PID_KI\s+0\.0f') `
    'unmeasured speed-loop integral is disabled'
Assert-Check ($params -match '#define\s+CURVE_PWM_LIMIT\s+80\.0f') `
    'motor PWM output is capped at 80 percent'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_PWM_RISE_PER_5MS\s+4\.0f[\s\S]*?' +
        'CURVE_PWM_FALL_PER_5MS\s+20\.0f')) `
    'acceleration is slower than curve-entry deceleration'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'case\s+0x00U:[\s\S]*?CURVE_MODE_HOLD[\s\S]*?' +
        'case\s+0x1FU:[\s\S]*?CURVE_MODE_STOP')) `
    '00000 is gap hold while 11111 remains the wide-line stop'
Assert-Check `
    ([regex]::IsMatch(
        $graySource,
        'CurveControl_ShouldUpdateTargets\s*\(\s*targets\.mode\s*\)' +
        '[\s\S]*?PID_SetTarget\s*\(\s*left[\s\S]*?' +
        'PID_SetTarget\s*\(\s*right')) `
    'gap hold skips both PID target updates'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'case\s+0x01U:[\s\S]*?CURVE_TARGET_EXTREME_INNER[\s\S]*?' +
        'CURVE_TARGET_EXTREME_OUTER')) `
    'left outer sensor commands the extreme turn profile'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'case\s+0x10U:[\s\S]*?CURVE_TARGET_EXTREME_OUTER[\s\S]*?' +
        'CURVE_TARGET_EXTREME_INNER')) `
    'right outer sensor mirrors the extreme turn profile'
Assert-Check `
    ([regex]::IsMatch(
        $pidSource,
        'PID_SetTarget[\s\S]*?ErrorInt\s*=\s*0\.0f')) `
    'target transitions clear stale integral state'
Assert-Check `
    ([regex]::IsMatch(
        $pidSource,
        'PID_SetActualMagnitude[\s\S]*?encoder_delta\s*<\s*0[\s\S]*?' +
        'p->Actual\s*=\s*-\(float\)encoder_delta')) `
    'encoder polarity is normalized to positive speed magnitude'
Assert-Check `
    ([regex]::IsMatch(
        $main,
        'PID_SetActualMagnitude\s*\(\s*&Speed1PID[\s\S]*?' +
        'PID_SetActualMagnitude\s*\(\s*&Speed2PID')) `
    'both wheel speed loops use encoder magnitude'
Assert-Check `
    ([regex]::IsMatch(
        $main,
        'curveMode\s*==\s*CURVE_MODE_STOP[\s\S]*?' +
        'Motor1_SetSpeed\s*\(\s*0\s*\)[\s\S]*?' +
        'Motor2_SetSpeed\s*\(\s*0\s*\)')) `
    'wide-line stop mode forces immediate zero motor output'

$isrMatch =
    [regex]::Match(
        $main,
        'void\s+TIMER_PID_INST_IRQHandler\s*\(\s*\)[\s\S]*$')
Assert-Check $isrMatch.Success 'timer ISR is present'
if ($isrMatch.Success)
{
    Assert-Check `
        (-not [regex]::IsMatch(
            $isrMatch.Value,
            '\b(?:OLED_|UART|printf|sprintf|delay_)[A-Za-z0-9_]*\s*\(')) `
        'timer ISR contains no OLED, UART, formatting or delay calls'
}

$allC =
    @(Get-ChildItem -LiteralPath $projectRoot -Recurse -Filter '*.c' -File |
        Where-Object {
            $_.FullName -notmatch '\\Debug\\' -and
            $_.FullName -notmatch '\\tests\\build\\'
        } |
        ForEach-Object {
            Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8
        }) -join "`n"
Assert-Check `
    ([regex]::Matches($allC, '\bGROUP1_IRQHandler\s*\(').Count -eq 1) `
    'GROUP1 encoder IRQ has exactly one definition'
Assert-Check `
    ([regex]::Matches(
        $allC,
        '\bTIMER_PID_INST_IRQHandler\s*\(').Count -eq 1) `
    'TIMER_PID IRQ has exactly one definition'

& (Join-Path $projectRoot 'tests\run_host_tests.ps1')
Assert-Check ($LASTEXITCODE -eq 0) 'host curve-control and PID tests pass'

if ($failures -ne 0)
{
    throw "Curve tuning static audit failed: $failures check(s)"
}

Write-Host 'CURVE TUNING STATIC AUDIT: PASS'
