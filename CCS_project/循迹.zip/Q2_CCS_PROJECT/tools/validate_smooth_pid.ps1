[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$projectRoot = Split-Path -Parent $PSScriptRoot
$failures = 0

function Assert-Check
{
    param(
        [bool]$Condition,
        [string]$Message
    )

    if ($Condition)
    {
        Write-Host "PASS: $Message"
    }
    else
    {
        Write-Host "FAIL: $Message"
        $script:failures++
    }
}

$provinceRoot =
    Split-Path -Parent (
        Split-Path -Parent (
            Split-Path -Parent $projectRoot))
$codeDateRoot = Split-Path -Parent $projectRoot
$deliveryZip = Join-Path $codeDateRoot `
    'deliverables\H_Q2_v12_gap_hold_20260729_50226ef.zip'
$originZip =
    @(Get-ChildItem -LiteralPath $provinceRoot -Recurse -File `
        -Filter 'balance_car_v1.2.zip' |
        Where-Object {
            (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash -eq
            '3DEBC6D4D1279209CD606419204B592F264D5112125681E7BB3ADD09E88BE20E'
        })[0].FullName
$pinWorkbook =
    @(Get-ChildItem -LiteralPath $provinceRoot -Recurse -File `
        -Filter '*.xlsx' |
        Where-Object {
            (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash -eq
            '3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61'
        })[0].FullName

Assert-Check `
    ((Get-FileHash -Algorithm SHA256 -LiteralPath $deliveryZip).Hash -eq
        '684AA7BF9B9764B98F192ECC40490C4C471413BD5869C07C5A427ED965658644') `
    'input gap-hold delivery ZIP is unchanged'
Assert-Check `
    ((Get-FileHash -Algorithm SHA256 -LiteralPath $originZip).Hash -eq
        '3DEBC6D4D1279209CD606419204B592F264D5112125681E7BB3ADD09E88BE20E') `
    'balance_car_v1.2.zip is unchanged'
Assert-Check `
    ((Get-FileHash -Algorithm SHA256 -LiteralPath $pinWorkbook).Hash -eq
        '3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61') `
    'authoritative pin workbook is unchanged'

$protected = [ordered]@{
    'empty.syscfg' =
        'D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66'
    'Debug\ti_msp_dl_config.h' =
        '219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0'
    'Debug\ti_msp_dl_config.c' =
        '8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6'
    'driver\uart.c' =
        '35036AA5EC1ED315DDCE5B138C481F17CF9354AC61D9509B001A591B6C3DEDFB'
    'driver\uart.h' =
        '37546411CA0CA64D2AF0870BCAB9947C3CEFF75BE9C8077A53A440D193BC657C'
}
foreach ($entry in $protected.GetEnumerator())
{
    $actual =
        (Get-FileHash -Algorithm SHA256 -LiteralPath (
            Join-Path $projectRoot $entry.Key)).Hash
    Assert-Check ($actual -eq $entry.Value) `
        "protected file unchanged: $($entry.Key)"
}

$params =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_params.h') `
        -Raw -Encoding UTF8
$controlHeader =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_control.h') `
        -Raw -Encoding UTF8
$control =
    Get-Content -LiteralPath (Join-Path $projectRoot 'curve_control.c') `
        -Raw -Encoding UTF8
$pidSource =
    Get-Content -LiteralPath (Join-Path $projectRoot 'pid.c') `
        -Raw -Encoding UTF8
$main =
    Get-Content -LiteralPath (Join-Path $projectRoot 'main.c') `
        -Raw -Encoding UTF8
$motor =
    Get-Content -LiteralPath (Join-Path $projectRoot 'driver\motor.c') `
        -Raw -Encoding UTF8
$motorHeader =
    Get-Content -LiteralPath (Join-Path $projectRoot 'driver\motor.h') `
        -Raw -Encoding UTF8
$uart =
    (Get-Content -LiteralPath (Join-Path $projectRoot 'driver\uart.c') `
        -Raw -Encoding UTF8) + "`n" +
    (Get-Content -LiteralPath (Join-Path $projectRoot 'driver\uart.h') `
        -Raw -Encoding UTF8)

Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_SENSOR_A_MM\s+\(-45\)[\s\S]*?' +
        'CURVE_SENSOR_B_MM\s+\(-15\)[\s\S]*?' +
        'CURVE_SENSOR_C_MM\s+0[\s\S]*?' +
        'CURVE_SENSOR_D_MM\s+15[\s\S]*?' +
        'CURVE_SENSOR_E_MM\s+45')) `
    'real A/B/C/D/E sensor positions are encoded'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_TRACK_RADIUS_MM\s+500[\s\S]*?' +
        'CURVE_WHEEL_TRACK_MM\s+180[\s\S]*?' +
        'CURVE_WHEEL_DIAMETER_MM\s+65[\s\S]*?' +
        'CURVE_SENSOR_LOOKAHEAD_MM\s+265')) `
    'course radius and measured car geometry are encoded'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_LINE_PID_KP\s+0\.55f[\s\S]*?' +
        'CURVE_LINE_PID_KI\s+0\.03f[\s\S]*?' +
        'CURVE_LINE_PID_KD\s+0\.10f[\s\S]*?' +
        'CURVE_LINE_PID_I_OUT_LIMIT\s+11\.0f')) `
    'geometry-derived line PID constants are centralized'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_BASE_STRAIGHT_PWM\s+60[\s\S]*?' +
        'CURVE_BASE_MID_PWM\s+54[\s\S]*?' +
        'CURVE_BASE_OUTER_PWM\s+46[\s\S]*?' +
        'CURVE_PWM_LIMIT\s+80')) `
    'dynamic speed schedule and PWM ceiling are centralized'
Assert-Check `
    ([regex]::IsMatch(
        $params,
        'CURVE_PWM_RISE_PER_5MS\s+2[\s\S]*?' +
        'CURVE_PWM_FALL_PER_5MS\s+4')) `
    'smooth final PWM slew is configured'

foreach ($api in @(
        'CurveControl_Init',
        'CurveControl_Start',
        'CurveControl_PushSample1ms',
        'CurveControl_Step5ms',
        'CurveControl_StopImmediate'))
{
    Assert-Check ($controlHeader -match "\b$api\s*\(") `
        "public control API exists: $api"
}

Assert-Check `
    ([regex]::IsMatch(
        $control,
        'filtered_mask\s*==\s*0U[\s\S]*?' +
        'gap_hold\s*=\s*1U[\s\S]*?return\s*;')) `
    '00000 holds the complete previous control state'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'CURVE_FINISH_BCD_MASK[\s\S]*?' +
        'CURVE_FINISH_CONFIRM_CYCLES[\s\S]*?' +
        'CurveControl_StopImmediate')) `
    'central BCD x3 finish path reaches immediate stop'
Assert-Check `
    ([regex]::IsMatch(
        $control,
        'CURVE_START_CLEAR_CYCLES[\s\S]*?' +
        'start_line_cleared\s*=\s*1U[\s\S]*?' +
        'CURVE_FINISH_ARM_MIN_MS')) `
    'start-line clear and two-second finish arming are implemented'
Assert-Check `
    ([regex]::IsMatch(
        $pidSource,
        'ErrorIntMax[\s\S]*?ErrorIntMin')) `
    'PID implements explicit integral limits'

Assert-Check `
    (-not [regex]::IsMatch(
        $main,
        '\bSpeed[12]PID\b|PID_SetActualMagnitude\s*\(')) `
    'unverified encoder speed loops are absent from runtime control'
Assert-Check `
    ([regex]::IsMatch(
        $main,
        'Motor1_SetSpeed\s*\(\s*output\.right_pwm\s*\)[\s\S]*?' +
        'Motor2_SetSpeed\s*\(\s*output\.left_pwm\s*\)')) `
    'Motor1 receives right PWM and Motor2 receives left PWM'
Assert-Check `
    ([regex]::IsMatch(
        $main,
        'Key_IsPressed\s*\(\s*CURVE_KEY_EMERGENCY_STOP\s*\)' +
        '[\s\S]*?CurveControl_StopImmediate[\s\S]*?' +
        'Motor_StopSafe')) `
    'K4 has an immediate safety-stop path'
Assert-Check `
    (-not [regex]::IsMatch(
        $main,
        'key_num\s*==\s*[23U]+')) `
    'K2 and K3 do not participate in race control'

Assert-Check `
    ([regex]::IsMatch(
        $motorHeader,
        'Motor1_SetSpeed\s*\(\s*int16_t[\s\S]*?' +
        'Motor2_SetSpeed\s*\(\s*int16_t[\s\S]*?' +
        'Motor_StopSafe')) `
    'motor API is signed int16_t and exposes safe stop'
Assert-Check `
    ([regex]::IsMatch(
        $motor,
        'Motor1_SetSpeed[\s\S]*?' +
        'DL_GPIO_clearPins\s*\(\s*DC_MOTOR_AIN1_PORT[\s\S]*?' +
        'DL_GPIO_setPins\s*\(\s*DC_MOTOR_AIN2_PORT')) `
    'Motor1 verified reversed-forward electrical direction is preserved'
Assert-Check `
    ([regex]::IsMatch(
        $motor,
        'Motor_StopSafe[\s\S]*?Motor1_Brake\s*\(\s*\)' +
        '[\s\S]*?Motor2_Brake\s*\(\s*\)')) `
    'safe stop brakes both motors'

$isrMatch =
    [regex]::Match(
        $main,
        'void\s+TIMER_PID_INST_IRQHandler\s*\(\s*void\s*\)[\s\S]*$')
Assert-Check $isrMatch.Success '1 ms timer ISR is present'
if ($isrMatch.Success)
{
    Assert-Check `
        (-not [regex]::IsMatch(
            $isrMatch.Value,
            '\b(?:OLED_|UART|printf|sprintf|delay_)[A-Za-z0-9_]*\s*\(')) `
        'ISR contains no OLED, UART, formatting or delay calls'
}

Assert-Check `
    (-not [regex]::IsMatch(
        $uart,
        '\b(?:Motor1_SetSpeed|Motor2_SetSpeed|Motor_StopSafe|' +
        'CurveControl_|PID_Update)\s*\(')) `
    'UART cannot control motors, PID or race state'

$allC =
    @(Get-ChildItem -LiteralPath $projectRoot -Recurse -Filter '*.c' -File |
        Where-Object {
            $_.FullName -notmatch '\\Debug\\' -and
            $_.FullName -notmatch '\\tests\\build\\'
        } |
        ForEach-Object {
            Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8
        }) -join "`n"
Assert-Check `
    ([regex]::Matches($allC, '\bGROUP1_IRQHandler\s*\(').Count -eq 1) `
    'GROUP1 encoder IRQ has exactly one definition'
Assert-Check `
    ([regex]::Matches(
        $allC,
        '\bTIMER_PID_INST_IRQHandler\s*\(').Count -eq 1) `
    'TIMER_PID IRQ has exactly one definition'

& (Join-Path $projectRoot 'tests\run_host_tests.ps1')
Assert-Check ($LASTEXITCODE -eq 0) 'host control tests pass'
& (Join-Path $projectRoot 'tests\run_target_syntax_check.ps1')
Assert-Check ($LASTEXITCODE -eq 0) 'target-source stub syntax check passes'

if ($failures -ne 0)
{
    throw "Smooth PID static audit failed: $failures check(s)"
}

Write-Host 'SMOOTH PID STATIC AUDIT: PASS'
