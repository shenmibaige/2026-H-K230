#ifndef __UART_H
#define __UART_H

#include <stdio.h>
#include "ti_msp_dl_config.h"   /* 图形化配置生成的头文件 */



/* ================================================================
 * 全局变量（改用 UART_ 前缀）
 * ================================================================ */
extern char UART_RxPacket[];    // 接收数据包缓冲区
extern uint8_t UART_RxFlag;     // 接收完成标志

/* ================================================================
 * 函数声明（改用 UART_ 前缀）
 * ================================================================ */
void UART_SendByte(uint8_t Byte);
void UART_SendArray(uint8_t *Array, uint16_t Length);
void UART_SendString(char *String);
void UART_SendNumber(uint32_t Number, uint8_t Length);
void UART_Printf(char *format, ...);

#endif