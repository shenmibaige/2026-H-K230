################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
OUT_SRCS += \
../firmware_stop_precision/05_OLED.out 

OUT_SRCS__QUOTED += \
"../firmware_stop_precision/05_OLED.out" 


