################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../tests/test_curve_tuning.c 

C_DEPS += \
./tests/test_curve_tuning.d 

OBJS += \
./tests/test_curve_tuning.o 

OBJS__QUOTED += \
"tests\test_curve_tuning.o" 

C_DEPS__QUOTED += \
"tests\test_curve_tuning.d" 

C_SRCS__QUOTED += \
"../tests/test_curve_tuning.c" 


