# balance_car_v1.2 五路传感器间隙保持版构建报告

## 1. 结论

- 实车问题复现依据：五路数字灰度均未检测到窄黑线时，旧逻辑把 `00000`
  判为 STOP，车辆误停。
- 代码实现：PASS
- 主机行为测试：PASS
- 静态审计：PASS
- CCS Clean：返回 0，0 errors，0 warnings
- CCS Full Build：返回 0，0 errors，1 warning
- 新 OUT/MAP 生成：PASS
- 新固件下载和赛道复测：NOT RUN

唯一 warning 为工程元数据 CCS 20.5.0 与当前 CCS 20.4.1 的版本提示，
没有新增编译器或链接器代码 warning。

## 2. 派生关系

- 父工程：`balance_car_v1.2_curve_tuned_work`
- 父提交：`ada104fc58805602f56f7129abb63e53889802e1`
- 当前工程：`balance_car_v1.2_gap_hold_work`
- 当前分支：`gap-hold-ready`
- 纯 ASCII 工程：
  `X:\TI_MSPM0_Toolchain\workspace\H_v12_gap_hold_20260729\q2_gap_hold`
- 独立 CCS workspace：
  `X:\TI_MSPM0_Toolchain\workspace\H_v12_gap_hold_20260729\ccs_ws`
- 工作副本与 ASCII 构建输入：57/57 文件，`DIFF_COUNT=0`

原 v1.2 ZIP、新版 XLSX、父工作副本均未修改。

## 3. 新控制逻辑

| 灰度掩码 | 新行为 |
|---|---|
| `00000` | `CURVE_MODE_HOLD`，不调用 `PID_SetTarget()` |
| 任一有效窄线模式 | 立即按新模式更新左右目标 |
| `11111` | `CURVE_MODE_STOP`，两路目标清零并立即写电机 0 |

HOLD 保留的不只是名义方向，还包括左右 PID 目标和输出斜坡状态。因此：

```text
左转模式 -> 00000 -> 继续左转 -> 右侧重新检测 -> 改为右转
直线模式 -> 00000 -> 继续直线 -> 任一路重新检测 -> 按新模式纠偏
```

未改变 0.5 m 圆弧参数、65 mm 轮径/180 mm 轮距参数、速度 PID、PWM 上限、
编码器幅值、电机映射、K1 启停和宽黑线终点停止。

## 4. 主机与静态测试

新增覆盖：

- `00000` 返回 HOLD 而非 STOP；
- HOLD 不覆盖上一组左右目标；
- 左转目标跨越 `00000` 保持；
- 重新检测右路后立即覆盖为右转目标；
- 第二次 `00000` 保持最新右转目标；
- `11111` 仍把左右目标清零；
- `huidu.c` 的 HOLD 路径跳过两次 `PID_SetTarget()`；
- ISR 仍无 OLED、UART、格式化和延时调用；
- IRQ 定义唯一；
- 五个受保护文件哈希未变。

证据：

- `verification_gap_hold/host_tests.log`
- `verification_gap_hold/static_audit.log`

## 5. CCS 构建

工具：

- TI Arm Clang 4.0.4.LTS
- MSPM0 SDK 2.10.00.04
- SysConfig 1.26.2+4477
- MSPM0G3507 device support

Clean：

- 时间：2026-07-29 22:45:25 至 22:45:27（UTC+8）
- 返回值：0
- 0 errors，0 warnings

Full Build：

- 时间：2026-07-29 22:45:41 至 22:45:46（UTC+8）
- 返回值：0
- 0 errors，1 warning
- 日志确认 `curve_control.c`、`huidu.c`、`pid.c`、`main.c` 均重新编译，
  `curve_control.o` 被链接到 `05_OLED.out`。

构建日志：

- `verification_gap_hold/ccs_clean.log`
- `verification_gap_hold/ccs_full_build.log`
- `verification_gap_hold/toolchain_verify.log`

## 6. 新固件

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| `firmware_gap_hold/05_OLED.out` | 241392 | `6E8484E27F024E93B2B1EAB1B05E08E5D0C3A2BBE4AFDFE76CC6CB2AAA2299A6` |
| `firmware_gap_hold/05_OLED.map` | 48876 | `3220483B8038C57592F56D4B2E7A6808D5B55FDF9A5EC8426CD90B147AF6EA68` |
| `firmware_gap_hold/05_OLED_linkInfo.xml` | 262485 | `1F3E36B846355C86E8E504ECFF7F247A4AF4C1B1C8DED5A57AB2502E5FFFA643` |

新 OUT 与父版本
`86601C6547E45A9533649B888847E1422A1DC1A05B2797FB55D4619503602D1D`
不同。

## 7. 受保护文件

| 文件 | SHA-256 |
|---|---|
| `empty.syscfg` | `D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66` |
| `Debug/ti_msp_dl_config.h` | `219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0` |
| `Debug/ti_msp_dl_config.c` | `8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6` |
| `driver/uart.c` | `35036AA5EC1ED315DDCE5B138C481F17CF9354AC61D9509B001A591B6C3DEDFB` |
| `driver/uart.h` | `37546411CA0CA64D2AF0870BCAB9947C3CEFF75BE9C8077A53A440D193BC657C` |

## 8. 风险与待测

`00000` 无法区分“窄线位于传感器间隙”和“车辆真正完全脱线”。按本轮要求，
两种情况都会保持上一方向。因此必须重新测试：

1. 直线间隙；
2. 左弯间隙；
3. 右弯间隙；
4. 间隙后反方向传感器重新捕获；
5. `11111` 宽线终点立即停车；
6. 完整赛道至少 10 轮；
7. 电流、温升、整圈时间和停车偏差。

只能烧录 `firmware_gap_hold/05_OLED.out`，不能继续使用父版本 OUT。
