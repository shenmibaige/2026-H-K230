/*
 * 2026 辽宁 H 题第 2 项：几何建模平滑循迹版。
 *
 * 1 ms：按键、五路灰度采样和运行计时；
 * 5 ms：五点多数滤波、灰度位置 PID、起终点状态机和电机更新；
 * 100 ms：主循环单次 OLED 刷新。
 */

#include "ti_msp_dl_config.h"

#include <stdint.h>

#include "curve_control.h"
#include "curve_params.h"
#include "encoder.h"
#include "huidu.h"
#include "key.h"
#include "motor.h"
#include "oled.h"

typedef struct
{
    CurveControlOutput curve;
    int32_t encoder1_delta;
    int32_t encoder2_delta;
    uint32_t uptime_ms;
} ControlTelemetry;

static CurveControl g_curve;
static volatile ControlTelemetry g_telemetry;
static volatile uint32_t g_uptime_ms;
static uint8_t g_control_divider;

static uint8_t Main_IsRunState(CurveRaceState state)
{
    return ((state == CURVE_STATE_STARTING) ||
            (state == CURVE_STATE_RUNNING) ||
            (state == CURVE_STATE_FINISH_ARMED))
               ? 1U
               : 0U;
}

static uint32_t Main_Abs32(int32_t value)
{
    return (value < 0L)
               ? (uint32_t)(-(value + 1L)) + 1U
               : (uint32_t)value;
}

static void Main_ShowSigned(
    uint8_t x,
    uint8_t y,
    int32_t value,
    uint8_t digits)
{
    OLED_ShowChar(x, y, (value < 0L) ? '-' : '+', 16U);
    OLED_ShowNum(
        (uint8_t)(x + 8U),
        y,
        Main_Abs32(value),
        digits,
        16U);
}

static ControlTelemetry Main_ReadTelemetry(void)
{
    ControlTelemetry snapshot;
    uint32_t primask = __get_PRIMASK();

    __disable_irq();
    snapshot.curve = g_telemetry.curve;
    snapshot.encoder1_delta = g_telemetry.encoder1_delta;
    snapshot.encoder2_delta = g_telemetry.encoder2_delta;
    snapshot.uptime_ms = g_telemetry.uptime_ms;
    if ((primask & 1U) == 0U)
    {
        __enable_irq();
    }
    return snapshot;
}

static void Main_PublishTelemetry(
    CurveControlOutput output,
    int32_t encoder1_delta,
    int32_t encoder2_delta)
{
    g_telemetry.curve = output;
    g_telemetry.encoder1_delta = encoder1_delta;
    g_telemetry.encoder2_delta = encoder2_delta;
    g_telemetry.uptime_ms = g_uptime_ms;
}

static void Main_RenderOled(const ControlTelemetry *snapshot)
{
    int32_t error_mm;

    if (snapshot == 0)
    {
        return;
    }

    error_mm =
        (int32_t)snapshot->curve.error_mm_q8 / CURVE_Q8_SCALE;

    OLED_ShowString(
        0U,
        0U,
        (u8 *)CurveControl_StateName(snapshot->curve.state),
        16U);
    OLED_ShowString(64U, 0U, (u8 *)"T", 16U);
    OLED_ShowNum(
        72U,
        0U,
        snapshot->curve.elapsed_ms / 1000U,
        2U,
        16U);
    OLED_ShowChar(88U, 0U, '.', 16U);
    OLED_ShowNum(
        96U,
        0U,
        (snapshot->curve.elapsed_ms % 1000U) / 100U,
        1U,
        16U);

    OLED_ShowString(0U, 16U, (u8 *)"M", 16U);
    OLED_ShowNum(
        8U,
        16U,
        snapshot->curve.raw_mask,
        2U,
        16U);
    OLED_ShowString(32U, 16U, (u8 *)"F", 16U);
    OLED_ShowNum(
        40U,
        16U,
        snapshot->curve.filtered_mask,
        2U,
        16U);
    OLED_ShowString(64U, 16U, (u8 *)"A", 16U);
    OLED_ShowNum(
        72U,
        16U,
        snapshot->curve.approach_stage,
        1U,
        16U);
    OLED_ShowString(88U, 16U, (u8 *)"G", 16U);
    OLED_ShowNum(
        96U,
        16U,
        snapshot->curve.gap_hold,
        1U,
        16U);
    OLED_ShowString(112U, 16U, (u8 *)"X", 16U);
    OLED_ShowNum(
        120U,
        16U,
        (uint32_t)snapshot->curve.fault,
        1U,
        16U);

    OLED_ShowString(0U, 32U, (u8 *)"E", 16U);
    Main_ShowSigned(8U, 32U, error_mm, 3U);
    OLED_ShowString(48U, 32U, (u8 *)"U", 16U);
    Main_ShowSigned(
        56U,
        32U,
        snapshot->curve.turn_pwm,
        2U);
    OLED_ShowString(88U, 32U, (u8 *)"C", 16U);
    OLED_ShowNum(
        96U,
        32U,
        (snapshot->curve.raw_finish_count != 0U)
            ? snapshot->curve.raw_finish_count
            : snapshot->curve.finish_confirm_count,
        1U,
        16U);
    OLED_ShowString(112U, 32U, (u8 *)"S", 16U);
    OLED_ShowNum(
        120U,
        32U,
        (uint32_t)snapshot->curve.finish_trigger,
        1U,
        16U);

    if (((snapshot->uptime_ms / 500U) & 1U) == 0U)
    {
        OLED_ShowString(0U, 48U, (u8 *)"L", 16U);
        Main_ShowSigned(
            8U,
            48U,
            snapshot->curve.left_pwm,
            2U);
        OLED_ShowString(48U, 48U, (u8 *)"R", 16U);
        Main_ShowSigned(
            56U,
            48U,
            snapshot->curve.right_pwm,
            2U);
        OLED_ShowString(88U, 48U, (u8 *)"PWM ", 16U);
    }
    else
    {
        OLED_ShowString(0U, 48U, (u8 *)"1", 16U);
        Main_ShowSigned(
            8U,
            48U,
            snapshot->encoder1_delta,
            3U);
        OLED_ShowString(48U, 48U, (u8 *)"2", 16U);
        Main_ShowSigned(
            56U,
            48U,
            snapshot->encoder2_delta,
            3U);
    }

    OLED_Refresh();
}

int main(void)
{
    uint32_t last_oled_ms = UINT32_MAX;

    SYSCFG_DL_init();
    OLED_Init();
    OLED_ColorTurn(0U);
    OLED_DisplayTurn(0U);
    OLED_Clear();

    CurveControl_Init(&g_curve);
    g_uptime_ms = 0U;
    g_control_divider = 0U;

    DL_Timer_startCounter(MOTOR_INST);
    Motor_StopSafe();
    Encoder_Init();

    NVIC_EnableIRQ(Serial_INST_INT_IRQN);
    DL_Timer_startCounter(TIMER_PID_INST);
    NVIC_EnableIRQ(TIMER_PID_INST_INT_IRQN);
    DL_Timer_startCounter(SERVO_INST);

    Main_PublishTelemetry(
        CurveControl_GetOutput(&g_curve),
        0L,
        0L);

    while (1)
    {
        ControlTelemetry snapshot = Main_ReadTelemetry();

        if ((last_oled_ms == UINT32_MAX) ||
            ((snapshot.uptime_ms - last_oled_ms) >=
             CURVE_OLED_REFRESH_MS))
        {
            last_oled_ms = snapshot.uptime_ms;
            Main_RenderOled(&snapshot);
        }
    }
}

void TIMER_PID_INST_IRQHandler(void)
{
    if (DL_TimerA_getPendingInterrupt(TIMER_PID_INST) ==
        DL_TIMER_IIDX_LOAD)
    {
        CurveControlOutput output;
        CurveRaceState state_before_sample;
        uint8_t key_num;

        Key_Tick();
        g_uptime_ms++;
        key_num = Key_GetNum();

        /* K4 has priority over both the finish event and K1 restart. */
        if ((Key_IsPressed(CURVE_KEY_EMERGENCY_STOP) != 0U) ||
            (key_num == CURVE_KEY_EMERGENCY_STOP))
        {
            CurveControl_StopImmediate(
                &g_curve,
                CURVE_FAULT_EMERGENCY_STOP);
            Motor_StopSafe();
            g_control_divider = 0U;
            Main_PublishTelemetry(
                CurveControl_GetOutput(&g_curve),
                0L,
                0L);
            return;
        }

        huidu_get_value();
        state_before_sample =
            CurveControl_GetOutput(&g_curve).state;
        CurveControl_PushSample1ms(
            &g_curve,
            huidu_get_mask());
        output = CurveControl_GetOutput(&g_curve);

        /*
         * A raw B/C/D finish event transitions to STOPPED inside the 1 ms
         * sample path.  Apply the hardware short brake in this same ISR,
         * without waiting for the next 5 ms control step.
         */
        if ((state_before_sample ==
             CURVE_STATE_FINISH_ARMED) &&
            (output.state == CURVE_STATE_STOPPED) &&
            (output.finish_trigger ==
             CURVE_FINISH_TRIGGER_RAW_FAST))
        {
            Motor_StopSafe();
            g_control_divider = 0U;
            Main_PublishTelemetry(
                output,
                0L,
                0L);
            return;
        }

        if (key_num == CURVE_KEY_START)
        {
            if (CurveControl_Start(&g_curve) != 0U)
            {
                Encoder_Reset();
            }
        }

        g_control_divider++;
        if (g_control_divider >= CURVE_CONTROL_PERIOD_MS)
        {
            int32_t encoder1_delta;
            int32_t encoder2_delta;

            g_control_divider = 0U;
            output = CurveControl_Step5ms(&g_curve);
            encoder1_delta = Encoder_ReadDelta1();
            encoder2_delta = Encoder_ReadDelta2();

            if (Main_IsRunState(output.state) != 0U)
            {
                /*
                 * Motor1=右轮、Motor2=左轮。Motor1 的镜像安装反向已经
                 * 封装在 motor.c 中，控制层仍以正 PWM 表示整车前进。
                 */
                Motor1_SetSpeed(output.right_pwm);
                Motor2_SetSpeed(output.left_pwm);
            }
            else
            {
                Motor_StopSafe();
            }

            Main_PublishTelemetry(
                output,
                encoder1_delta,
                encoder2_delta);
        }
        else if (key_num != 0U)
        {
            Main_PublishTelemetry(
                CurveControl_GetOutput(&g_curve),
                g_telemetry.encoder1_delta,
                g_telemetry.encoder2_delta);
        }
    }
}
