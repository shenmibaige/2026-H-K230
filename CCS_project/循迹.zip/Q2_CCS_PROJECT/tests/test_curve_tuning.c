#if !defined(CURVE_TUNING_HOST_TEST)

/*
 * CCS Managed Build recursively discovers C sources.  Keep this test inert
 * in target firmware while compiling it as a host executable with
 * CURVE_TUNING_HOST_TEST.
 */
typedef int smooth_pid_host_tests_excluded_from_target_build;

#else

#include <stdio.h>
#include <stdlib.h>

#include "curve_control.h"
#include "curve_params.h"

static int failures;

#define CHECK(condition, message)                                      \
    do                                                                 \
    {                                                                  \
        if (!(condition))                                              \
        {                                                              \
            printf("FAIL: %s (line %d)\n", (message), __LINE__);       \
            failures++;                                                \
        }                                                              \
    } while (0)

static CurveControlOutput push_ms(
    CurveControl *control,
    uint8_t mask,
    uint32_t milliseconds)
{
    uint32_t index;

    for (index = 0U; index < milliseconds; index++)
    {
        CurveControl_PushSample1ms(control, mask);
        if (((index + 1U) % CURVE_CONTROL_PERIOD_MS) == 0U)
        {
            (void)CurveControl_Step5ms(control);
        }
    }
    return CurveControl_GetOutput(control);
}

static CurveControlOutput push_filtered_bcd_without_raw_bcd(
    CurveControl *control)
{
    static const uint8_t masks[5] = {
        0x06U,
        0x0CU,
        0x0AU,
        0x06U,
        0x0CU};
    uint8_t index;

    for (index = 0U; index < 5U; index++)
    {
        CurveControl_PushSample1ms(
            control,
            masks[index]);
    }
    return CurveControl_Step5ms(control);
}

static void prepare_running(
    CurveControl *control,
    uint8_t initial_mask)
{
    CurveControlOutput output;

    CurveControl_Init(control);
    (void)push_ms(
        control,
        initial_mask,
        CURVE_HISTORY_SAMPLES);
    CHECK(
        CurveControl_Start(control) != 0U,
        "K1 start accepted after five samples");

    output = push_ms(control, 0x04U, 15U);
    CHECK(
        output.state == CURVE_STATE_RUNNING,
        "three clear control cycles enter RUNNING");
    (void)push_ms(
        control,
        0x04U,
        CURVE_START_RAMP_MS);
}

static void test_geometry_and_filter(void)
{
    CurveControl control;

    CHECK(
        CurveControl_ErrorMmQ8(0x04U) == 0,
        "C is zero millimetres");
    CHECK(
        CurveControl_ErrorMmQ8(0x06U) ==
            (-15 * CURVE_Q8_SCALE / 2),
        "BC centroid is -7.5 mm");
    CHECK(
        CurveControl_ErrorMmQ8(0x02U) ==
            (-15 * CURVE_Q8_SCALE),
        "B is -15 mm");
    CHECK(
        CurveControl_ErrorMmQ8(0x03U) ==
            (-30 * CURVE_Q8_SCALE),
        "AB centroid is -30 mm");
    CHECK(
        CurveControl_ErrorMmQ8(0x01U) ==
            (-45 * CURVE_Q8_SCALE),
        "A is -45 mm");
    CHECK(
        CurveControl_ErrorMmQ8(0x0CU) ==
            (15 * CURVE_Q8_SCALE / 2),
        "CD centroid mirrors BC");
    CHECK(
        CurveControl_ErrorMmQ8(0x10U) ==
            (45 * CURVE_Q8_SCALE),
        "E mirrors A");

    CurveControl_Init(&control);
    CurveControl_PushSample1ms(&control, 0x08U);
    CurveControl_PushSample1ms(&control, 0x00U);
    CurveControl_PushSample1ms(&control, 0x08U);
    CurveControl_PushSample1ms(&control, 0x00U);
    CurveControl_PushSample1ms(&control, 0x08U);
    CHECK(
        CurveControl_FilteredMask(&control) == 0x08U,
        "five-point majority accepts three D samples");

    CurveControl_Init(&control);
    CurveControl_PushSample1ms(&control, 0x08U);
    CurveControl_PushSample1ms(&control, 0x00U);
    CurveControl_PushSample1ms(&control, 0x00U);
    CurveControl_PushSample1ms(&control, 0x08U);
    CurveControl_PushSample1ms(&control, 0x00U);
    CHECK(
        CurveControl_FilteredMask(&control) == 0x00U,
        "five-point majority rejects two D samples");
}

static void test_start_and_finish_state_machine(void)
{
    CurveControl control;
    CurveControlOutput output;

    CurveControl_Init(&control);
    CHECK(
        CurveControl_GetOutput(&control).state ==
            CURVE_STATE_WAIT,
        "power-on state is WAIT");
    CHECK(
        CurveControl_GetOutput(&control).left_pwm == 0 &&
            CurveControl_GetOutput(&control).right_pwm == 0,
        "power-on motor commands are zero");
    CHECK(
        CurveControl_Start(&control) == 0U,
        "K1 before filter history is ignored");

    (void)push_ms(&control, 0x0EU, 5U);
    CHECK(
        CurveControl_Start(&control) != 0U,
        "one K1 on BCD start line starts the race");

    output = push_ms(&control, 0x0EU, 15U);
    CHECK(
        output.state == CURVE_STATE_STARTING,
        "initial BCD line cannot trigger the finish");

    output = push_ms(&control, 0x04U, 5U);
    CHECK(
        output.state == CURVE_STATE_STARTING,
        "first clear cycle remains STARTING");
    output = push_ms(&control, 0x04U, 5U);
    CHECK(
        output.state == CURVE_STATE_STARTING,
        "second clear cycle remains STARTING");
    output = push_ms(&control, 0x04U, 5U);
    CHECK(
        output.state == CURVE_STATE_RUNNING &&
            output.start_line_cleared != 0U,
        "third clear cycle enters RUNNING");

    output = push_ms(&control, 0x0EU, 15U);
    CHECK(
        output.state == CURVE_STATE_RUNNING,
        "BCD before two seconds cannot stop the car");

    while (output.elapsed_ms < CURVE_FINISH_ARM_MIN_MS)
    {
        output = push_ms(&control, 0x04U, 5U);
    }
    if (output.state == CURVE_STATE_RUNNING)
    {
        output = push_ms(&control, 0x04U, 5U);
    }
    CHECK(
        output.state == CURVE_STATE_FINISH_ARMED,
        "start clear plus two seconds arms the finish");

    output = push_ms(&control, 0x04U, 15U);
    CHECK(
        output.state == CURVE_STATE_FINISH_ARMED,
        "ordinary narrow C line cannot trigger finish");

    output = push_ms(&control, 0x06U, 10U);
    CHECK(
        output.state == CURVE_STATE_FINISH_ARMED,
        "two adjacent sensors cannot trigger finish");

    output = push_ms(&control, 0x0EU, 1U);
    CHECK(
        output.state == CURVE_STATE_FINISH_ARMED &&
            output.raw_finish_count == 1U,
        "first raw BCD millisecond does not stop");
    output = push_ms(&control, 0x0EU, 1U);
    CHECK(
        output.state == CURVE_STATE_STOPPED &&
            output.finish_trigger ==
                CURVE_FINISH_TRIGGER_RAW_FAST &&
            output.raw_finish_count ==
                CURVE_FINISH_RAW_CONFIRM_SAMPLES,
        "second raw BCD millisecond stops immediately");
    CHECK(
        output.left_pwm == 0 && output.right_pwm == 0 &&
            output.left_target_pwm == 0 &&
            output.right_target_pwm == 0,
        "STOPPED clears targets and PWM");

    output = push_ms(&control, 0x0EU, 25U);
    CHECK(
        output.state == CURVE_STATE_STOPPED,
        "finish can trigger only once");
    CHECK(
        CurveControl_Start(&control) != 0U,
        "K1 can restart from STOPPED");
}

static void test_filtered_finish_fallback(void)
{
    CurveControl control;
    CurveControlOutput output;

    prepare_running(&control, 0x04U);
    output = CurveControl_GetOutput(&control);
    while (output.elapsed_ms < CURVE_FINISH_ARM_MIN_MS)
    {
        output = push_ms(&control, 0x04U, 5U);
    }
    if (output.state == CURVE_STATE_RUNNING)
    {
        output = push_ms(&control, 0x04U, 5U);
    }

    output =
        push_filtered_bcd_without_raw_bcd(&control);
    CHECK(
        output.state == CURVE_STATE_FINISH_ARMED &&
            output.finish_confirm_count == 1U &&
            output.raw_finish_count == 0U,
        "filtered fallback count one does not stop");
    output =
        push_filtered_bcd_without_raw_bcd(&control);
    CHECK(
        output.state == CURVE_STATE_FINISH_ARMED &&
            output.finish_confirm_count == 2U,
        "filtered fallback count two does not stop");
    output =
        push_filtered_bcd_without_raw_bcd(&control);
    CHECK(
        output.state == CURVE_STATE_STOPPED &&
            output.finish_trigger ==
                CURVE_FINISH_TRIGGER_FILTERED_FALLBACK,
        "third filtered BCD fallback stops safely");
    CHECK(
        output.left_pwm == 0 && output.right_pwm == 0,
        "filtered fallback clears both PWM");
}

static void test_smooth_pid_and_geometry_ratio(void)
{
    CurveControl left_control;
    CurveControl right_control;
    CurveControl outer_control;
    CurveControlOutput left;
    CurveControlOutput right;
    CurveControlOutput outer;
    int16_t previous_left;
    int16_t previous_right;

    prepare_running(&left_control, 0x04U);
    prepare_running(&right_control, 0x04U);
    prepare_running(&outer_control, 0x04U);

    previous_left =
        CurveControl_GetOutput(&left_control).left_pwm;
    previous_right =
        CurveControl_GetOutput(&left_control).right_pwm;
    left = push_ms(&left_control, 0x02U, 5U);
    CHECK(
        left.error_mm_q8 == (-15 * CURVE_Q8_SCALE),
        "B detection produces -15 mm error");
    CHECK(
        left.turn_pwm >= 9,
        "B detection immediately produces useful turn PWM");
    CHECK(
        left.right_target_pwm > left.left_target_pwm,
        "B detection slows left wheel and accelerates right wheel");
    CHECK(
        (left.left_pwm >= previous_left - CURVE_PWM_FALL_PER_5MS) &&
            (left.right_pwm <=
             previous_right + CURVE_PWM_RISE_PER_5MS),
        "first B correction obeys final PWM slew limits");

    right = push_ms(&right_control, 0x08U, 5U);
    CHECK(
        right.error_mm_q8 == (15 * CURVE_Q8_SCALE),
        "D detection produces +15 mm error");
    CHECK(
        right.turn_pwm <= -9,
        "D detection mirrors B turn magnitude");
    CHECK(
        right.left_target_pwm > right.right_target_pwm,
        "D detection slows right wheel and accelerates left wheel");

    outer = push_ms(&outer_control, 0x01U, 5U);
    CHECK(
        outer.turn_pwm > left.turn_pwm,
        "A correction is stronger than B correction");
    CHECK(
        outer.left_target_pwm >= 0 &&
            outer.right_target_pwm <= CURVE_PWM_LIMIT,
        "outer correction neither reverses inner wheel nor exceeds limit");

    /*
     * Repeated B error fills the v1.3 15 PWM integral term.  Once C is
     * recovered, the proportional term becomes zero while the bounded
     * integral preserves smooth curve authority at the normal base 98.
     */
    (void)push_ms(&left_control, 0x02U, 600U);
    (void)push_ms(&left_control, 0x04U, 5U);
    left = push_ms(&left_control, 0x04U, 5U);
    CHECK(
        left.turn_pwm >= 14 && left.turn_pwm <= 15,
        "v1.3 integral limit persists after C recovery");
    CHECK(
        left.left_target_pwm >= 83 &&
            left.left_target_pwm <= 84 &&
            left.right_target_pwm == CURVE_PWM_LIMIT,
        "v1.3 base 98 and integral produce bounded centre targets");
    CHECK(
        (CURVE_THEORY_INNER_RADIUS_MM * 1000 /
         CURVE_THEORY_OUTER_RADIUS_MM) == 694,
        "410/590 geometry ratio is recorded");
}

static void test_final_approach_speed_schedule(void)
{
    CurveControl control;
    CurveControlOutput output;

    prepare_running(&control, 0x04U);
    output = CurveControl_GetOutput(&control);

    while (output.elapsed_ms <
           (CURVE_FINISH_APPROACH_STAGE1_MS - 5U))
    {
        output = push_ms(&control, 0x04U, 5U);
    }
    CHECK(
        output.elapsed_ms ==
                (CURVE_FINISH_APPROACH_STAGE1_MS - 5U) &&
            output.approach_stage == 0U &&
            output.left_target_pwm ==
                CURVE_BASE_STRAIGHT_PWM &&
            output.right_target_pwm ==
                CURVE_BASE_STRAIGHT_PWM,
        "normal v1.3 speed remains unchanged before 12 seconds");

    output = push_ms(&control, 0x04U, 5U);
    CHECK(
        output.elapsed_ms ==
                CURVE_FINISH_APPROACH_STAGE1_MS &&
            output.approach_stage == 1U &&
            output.left_target_pwm ==
                CURVE_APPROACH1_STRAIGHT_PWM &&
            output.right_target_pwm ==
                CURVE_APPROACH1_STRAIGHT_PWM,
        "12 seconds enters first approach speed stage");

    while (output.elapsed_ms <
           (CURVE_FINISH_APPROACH_STAGE2_MS - 5U))
    {
        output = push_ms(&control, 0x04U, 5U);
    }
    CHECK(
        output.approach_stage == 1U &&
            output.left_target_pwm ==
                CURVE_APPROACH1_STRAIGHT_PWM,
        "first approach stage remains active before 14 seconds");

    output = push_ms(&control, 0x04U, 5U);
    CHECK(
        output.elapsed_ms ==
                CURVE_FINISH_APPROACH_STAGE2_MS &&
            output.approach_stage == 2U &&
            output.left_target_pwm ==
                CURVE_APPROACH2_STRAIGHT_PWM &&
            output.right_target_pwm ==
                CURVE_APPROACH2_STRAIGHT_PWM,
        "14 seconds enters final approach speed stage");
    CHECK(
        (CURVE_APPROACH2_STRAIGHT_PWM * 1000 /
         CURVE_BASE_STRAIGHT_PWM) == 612,
        "final straight command is 61.2 percent of v1.3 speed");
}

static void test_gap_hold_and_recovery(void)
{
    CurveControl control;
    CurveControlOutput before_gap;
    CurveControlOutput in_gap;
    CurveControlOutput recovered;

    prepare_running(&control, 0x04U);
    before_gap = push_ms(&control, 0x02U, 25U);
    in_gap = push_ms(&control, 0x00U, 5U);

    CHECK(
        in_gap.gap_hold != 0U,
        "00000 enters explicit gap hold");
    CHECK(
        in_gap.error_mm_q8 == before_gap.error_mm_q8 &&
            in_gap.turn_pwm == before_gap.turn_pwm,
        "gap preserves error and PID turn state");
    CHECK(
        in_gap.left_target_pwm == before_gap.left_target_pwm &&
            in_gap.right_target_pwm == before_gap.right_target_pwm &&
            in_gap.left_pwm == before_gap.left_pwm &&
            in_gap.right_pwm == before_gap.right_pwm,
        "gap preserves targets and current PWM exactly");

    recovered = push_ms(&control, 0x08U, 10U);
    CHECK(
        recovered.gap_hold == 0U &&
            recovered.turn_pwm < before_gap.turn_pwm,
        "opposite sensor reacquisition replaces held direction smoothly");
}

static void test_emergency_and_timeout(void)
{
    CurveControl control;
    CurveControlOutput output;

    prepare_running(&control, 0x04U);
    CurveControl_StopImmediate(
        &control,
        CURVE_FAULT_EMERGENCY_STOP);
    output = CurveControl_GetOutput(&control);
    CHECK(
        output.state == CURVE_STATE_FAULT &&
            output.fault == CURVE_FAULT_EMERGENCY_STOP &&
            output.finish_trigger ==
                CURVE_FINISH_TRIGGER_NONE,
        "K4 path enters emergency FAULT");
    CHECK(
        output.left_pwm == 0 && output.right_pwm == 0,
        "K4 path clears both PWM immediately");
    CHECK(
        CurveControl_Start(&control) != 0U,
        "K1 can rearm after emergency release");

    prepare_running(&control, 0x04U);
    output = CurveControl_GetOutput(&control);
    while (output.state != CURVE_STATE_FAULT)
    {
        output = push_ms(&control, 0x04U, 5U);
    }
    CHECK(
        output.fault == CURVE_FAULT_HARD_TIMEOUT &&
            output.elapsed_ms >= CURVE_HARD_TIMEOUT_MS,
        "configured hard timeout enters FAULT");
    CHECK(
        output.left_pwm == 0 && output.right_pwm == 0,
        "hard timeout stops both motors");
}

int main(void)
{
    test_geometry_and_filter();
    test_start_and_finish_state_machine();
    test_filtered_finish_fallback();
    test_smooth_pid_and_geometry_ratio();
    test_final_approach_speed_schedule();
    test_gap_hold_and_recovery();
    test_emergency_and_timeout();

    if (failures != 0)
    {
        printf(
            "v1.3 stop-precision host tests: %d failure(s)\n",
            failures);
        return EXIT_FAILURE;
    }

    printf("v1.3 stop-precision host tests: PASS\n");
    printf(
        "Covered: real -45/-15/0/15/45 mm sensor geometry, "
        "five-sample majority, B/D early correction, mirrored turns, "
        "v1.3 PID integral limit, 5/8 PWM slew, 100 PWM limit, "
        "12/14 s final-approach speed stages, raw BCD x2 1 ms stop, "
        "filtered BCD x3 fallback, "
        "00000 full-state hold and recovery, start-line clear, "
        "2 s finish arm, K4 emergency stop and configured hard timeout.\n");
    return EXIT_SUCCESS;
}

#endif
