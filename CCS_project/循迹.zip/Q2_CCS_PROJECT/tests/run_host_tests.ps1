[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$projectRoot = Split-Path -Parent $PSScriptRoot
$buildDirectory = Join-Path $PSScriptRoot 'build'
$executable = Join-Path $buildDirectory 'test_curve_tuning.exe'

New-Item -ItemType Directory -Path $buildDirectory -Force | Out-Null

$compiler = Get-Command gcc -ErrorAction Stop
& $compiler.Source `
    '-std=c11' '-Wall' '-Wextra' '-Werror' `
    '-DCURVE_TUNING_HOST_TEST' `
    "-I$projectRoot" `
    (Join-Path $projectRoot 'curve_control.c') `
    (Join-Path $projectRoot 'pid.c') `
    (Join-Path $PSScriptRoot 'test_curve_tuning.c') `
    '-o' $executable
if ($LASTEXITCODE -ne 0)
{
    exit $LASTEXITCODE
}

& $executable
exit $LASTEXITCODE
