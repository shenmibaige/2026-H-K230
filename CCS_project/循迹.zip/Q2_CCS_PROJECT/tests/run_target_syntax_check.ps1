[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$projectRoot = Split-Path -Parent $PSScriptRoot
$stubRoot = Join-Path $PSScriptRoot 'target_stubs'
$gcc = Get-Command gcc -ErrorAction Stop

$sources = @(
    (Join-Path $projectRoot 'main.c'),
    (Join-Path $projectRoot 'curve_control.c'),
    (Join-Path $projectRoot 'pid.c'),
    (Join-Path $projectRoot 'huidu.c'),
    (Join-Path $projectRoot 'driver\motor.c'),
    (Join-Path $projectRoot 'driver\encoder.c'),
    (Join-Path $projectRoot 'driver\key.c')
)

$arguments = @(
    '-std=c11',
    '-Wall',
    '-Wextra',
    '-Werror',
    '-fsyntax-only',
    ('-I' + $stubRoot),
    ('-I' + $projectRoot),
    ('-I' + (Join-Path $projectRoot 'driver'))
) + $sources

& $gcc.Source @arguments
if ($LASTEXITCODE -ne 0)
{
    throw "Target-source stub syntax check failed: $LASTEXITCODE"
}

Write-Output 'Target-source stub syntax check: PASS'
Write-Output 'Boundary: this is not a TI Arm Clang/SDK/SysConfig build.'
