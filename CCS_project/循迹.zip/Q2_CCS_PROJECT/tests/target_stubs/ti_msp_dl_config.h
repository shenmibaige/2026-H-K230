#ifndef TI_MSP_DL_CONFIG_H
#define TI_MSP_DL_CONFIG_H

/*
 * Host GCC -fsyntax-only stub.  It is never part of the CCS target build and
 * does not simulate MSPM0 hardware.
 */

#include <stdint.h>

typedef struct
{
    uint32_t unused;
} GPIO_Regs;

static GPIO_Regs smooth_stub_gpio_a;
static GPIO_Regs smooth_stub_gpio_b;

#define GPIOA (&smooth_stub_gpio_a)
#define GPIOB (&smooth_stub_gpio_b)

#define Serial_INST_INT_IRQN             1
#define TIMER_PID_INST_INT_IRQN          2
#define ENCODER_GPIOA_INT_IRQN           3
#define ENCODER_GPIOB_INT_IRQN           4

#define TIMER_PID_INST                   ((void *)0)
#define SERVO_INST                       ((void *)0)
#define MOTOR_INST                       ((void *)0)

#define DL_TIMER_IIDX_LOAD               1U

#define HUIDU_PORT                       GPIOA
#define HUIDU_L2_PIN                     (1UL << 14)
#define HUIDU_L1_PIN                     (1UL << 24)
#define HUIDU_M_PIN                      (1UL << 17)
#define HUIDU_R1_PIN                     (1UL << 16)
#define HUIDU_R2_PIN                     (1UL << 2)

#define KEY_PORT                         GPIOB
#define KEY_PIN_B6_PIN                   (1UL << 6)
#define KEY_PIN_B7_PIN                   (1UL << 7)
#define KEY_PIN_B8_PIN                   (1UL << 8)
#define KEY_PIN_B9_PIN                   (1UL << 9)

#define DC_MOTOR_AIN1_PORT               GPIOA
#define DC_MOTOR_AIN1_PIN                (1UL << 8)
#define DC_MOTOR_AIN2_PORT               GPIOA
#define DC_MOTOR_AIN2_PIN                (1UL << 9)
#define DC_MOTOR_BIN1_PORT               GPIOB
#define DC_MOTOR_BIN1_PIN                (1UL << 18)
#define DC_MOTOR_BIN2_PORT               GPIOA
#define DC_MOTOR_BIN2_PIN                (1UL << 7)
#define GPIO_MOTOR_C0_IDX                0U
#define GPIO_MOTOR_C1_IDX                1U

#define ENCODER_A1_IIDX                  1U
#define ENCODER_B1_IIDX                  2U
#define ENCODER_A2_IIDX                  3U
#define ENCODER_B2_IIDX                  4U
#define ENCODER_A1_PORT                  GPIOB
#define ENCODER_A1_PIN                   (1UL << 19)
#define ENCODER_B1_PORT                  GPIOB
#define ENCODER_B1_PIN                   (1UL << 20)
#define ENCODER_A2_PORT                  GPIOA
#define ENCODER_A2_PIN                   (1UL << 21)
#define ENCODER_B2_PORT                  GPIOA
#define ENCODER_B2_PIN                   (1UL << 22)

static inline void SYSCFG_DL_init(void)
{
}

static inline void NVIC_EnableIRQ(int irq)
{
    (void)irq;
}

static inline void DL_Timer_startCounter(void *timer)
{
    (void)timer;
}

static inline uint32_t DL_TimerA_getPendingInterrupt(void *timer)
{
    (void)timer;
    return DL_TIMER_IIDX_LOAD;
}

static inline void DL_Timer_setCaptureCompareValue(
    void *timer,
    uint32_t value,
    uint32_t channel)
{
    (void)timer;
    (void)value;
    (void)channel;
}

static inline uint32_t DL_GPIO_readPins(
    GPIO_Regs *port,
    uint32_t pins)
{
    (void)port;
    (void)pins;
    return 0U;
}

static inline void DL_GPIO_setPins(
    GPIO_Regs *port,
    uint32_t pins)
{
    (void)port;
    (void)pins;
}

static inline void DL_GPIO_clearPins(
    GPIO_Regs *port,
    uint32_t pins)
{
    (void)port;
    (void)pins;
}

static inline uint32_t DL_GPIO_getPendingInterrupt(
    GPIO_Regs *port)
{
    (void)port;
    return 0U;
}

static inline uint32_t __get_PRIMASK(void)
{
    return 0U;
}

static inline void __disable_irq(void)
{
}

static inline void __enable_irq(void)
{
}

#endif
