# H 题 Q2 几何建模平滑循迹版构建报告

## 1. 验证结论

- 代码实现：PASS。
- 主机控制测试：PASS。
- 目标源码桩语法检查：PASS。
- 静态安全审计：PASS。
- 工作副本与ASCII构建输入：39/39文件，差异0。
- CCS Clean：返回0，0 errors、0 warnings。
- CCS Full Build：返回0，0 errors、1 warning。
- OUT/MAP/linkInfo生成：PASS。
- 固件下载：NOT RUN。
- 赛道、电流、温升、圈时和停车偏差：NOT RUN。

唯一warning为工程元数据由CCS 20.5.0创建，而本机CCS为20.4.1；没有
编译器或链接器代码warning。

## 2. 输入与保护

| 对象 | SHA-256 |
|---|---|
| `H_Q2_v12_gap_hold_20260729_50226ef.zip` | `684AA7BF9B9764B98F192ECC40490C4C471413BD5869C07C5A427ED965658644` |
| `balance_car_v1.2.zip` | `3DEBC6D4D1279209CD606419204B592F264D5112125681E7BB3ADD09E88BE20E` |
| `NEW电赛引脚分配方案.xlsx` | `3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61` |
| `empty.syscfg` | `D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66` |
| `Debug/ti_msp_dl_config.h` | `219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0` |
| `Debug/ti_msp_dl_config.c` | `8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6` |
| `driver/uart.c` | `35036AA5EC1ED315DDCE5B138C481F17CF9354AC61D9509B001A591B6C3DEDFB` |
| `driver/uart.h` | `37546411CA0CA64D2AF0870BCAB9947C3CEFF75BE9C8077A53A440D193BC657C` |

受保护文件均未修改。ASCII构建时SysConfig只在ASCII工程的Debug目录生成
构建输出，没有回写中文路径工作副本。

## 3. CCS构建

- ASCII工程：
  `X:\TI_MSPM0_Toolchain\workspace\H_v12_smooth_pid_20260729\q2_smooth_pid`
- CCS workspace：
  `X:\TI_MSPM0_Toolchain\workspace\H_v12_smooth_pid_20260729\ccs_ws`
- TI Arm Clang：4.0.4.LTS。
- MSPM0 SDK：2.10.00.04。
- SysConfig：1.26.2+4477。

Clean：

- 2026-07-29 23:45:26 至 23:45:29（UTC+8）。
- 返回0。
- 0 errors、0 warnings。

Full Build：

- 2026-07-29 23:56:22 至 23:56:27（UTC+8）。
- 返回0。
- 0 errors、1个CCS版本元数据warning。
- 日志确认 `curve_control.c`、`pid.c`、`main.c`、`huidu.c`、
  `driver/motor.c`、`driver/encoder.c` 和 `driver/key.c`均重新编译。
- 链接命令明确包含 `./curve_control.o`。

## 4. 固件

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| `firmware_smooth_pid/05_OLED.out` | 253740 | `C50EEA0B0767BB32F529C770F96F190777461420AF1F7FC1759AC51C31333A7F` |
| `firmware_smooth_pid/05_OLED.map` | 51263 | `718285E8CD4D5A341277F39BB5F12F483F8DB3FAE535D64114773E26EACE0B7D` |
| `firmware_smooth_pid/05_OLED_linkInfo.xml` | 273847 | `7C1072298BE45866BDBD207E24C151707EA699C81357DDF49386625D35D3DDE5` |

## 5. 证据文件

- `verification_smooth_pid/toolchain_verify.log`
- `verification_smooth_pid/ccs_initialize.log`
- `verification_smooth_pid/ccs_import.log`
- `verification_smooth_pid/ccs_clean.log`
- `verification_smooth_pid/ccs_full_build.log`
- `verification_smooth_pid/host_tests.log`
- `verification_smooth_pid/target_syntax.log`
- `verification_smooth_pid/static_audit.log`
- `verification_smooth_pid/source_match.log`

## 6. 修改范围

- `curve_params.h`：实测几何、PID、动态速度、终点和安全参数。
- `curve_control.c/.h`：五点多数滤波、毫米质心位置PID、状态机及间隙保持。
- `main.c`：1/5/100 ms调度、K1/K4、PWM映射、遥测和OLED。
- `pid.c/.h`：显式积分上下限。
- `huidu.c/.h`：只读五路掩码，不再设置双轮速度目标。
- `driver/motor.c/.h`：`int16_t`限幅和安全制动，保留Motor1反向。
- `driver/encoder.c/.h`：原子化32位增量读取，只作遥测。
- `driver/key.c/.h`：增加K4实时按下查询。
- 测试、静态审计、文档和打包脚本。

## 7. 未验证与回滚

新固件尚未下载，不能声称轮向、电流、温升、500 mm圆弧、完整圈时或停车
偏差已经通过。首次必须架空限流测试。

回滚优先切回本工程Git基线提交，或重新使用未修改的
`H_Q2_v12_gap_hold_20260729_50226ef.zip`。不得修改SysConfig或新版引脚表
来消除实车控制问题。
