# balance_car_v1.2 转弯灵敏度修正版构建报告

> 历史父版本报告：本报告对应提交 `ada104f` 的
> `firmware_curve_tuned/05_OLED.out`。当前 gap-hold 派生版的新构建结果
> 以 `GAP_HOLD_BUILD_REPORT.md` 和 `firmware_gap_hold/` 为准。

## 1. 结论

- 代码实现：PASS
- 主机测试：PASS
- 静态审计：PASS
- CCS Clean：PASS，返回 0，0 errors，0 warnings
- CCS Full Build：PASS，返回 0，0 errors，1 warning
- 烧录文件生成：PASS
- 下载到开发板：NOT RUN
- 轮向、电流、温升、圆弧和整圈测试：NOT RUN

唯一 warning 为工程元数据由 CCS 20.5.0 创建，而本机 CCS 为 20.4.1；
没有编译器或链接器代码 warning。

## 2. 基线与事实源

| 文件 | SHA-256 |
|---|---|
| `Origin/balance_car_v1.2.zip` | `3DEBC6D4D1279209CD606419204B592F264D5112125681E7BB3ADD09E88BE20E` |
| `NEW电赛引脚分配方案.xlsx` | `3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61` |
| 辽宁赛区 H 题 PDF | `78FAAED3DCCC0F34AF3879AC53F046FB7D57920A2982FECB798B2C24826E25E3` |

工作副本：

`balance_car_v1.2_curve_tuned_work`

纯 ASCII 构建工程：

`X:\TI_MSPM0_Toolchain\workspace\H_v12_curve_tuned_20260729\q2_curve_tuned`

CCS workspace：

`X:\TI_MSPM0_Toolchain\workspace\H_v12_curve_tuned_20260729\ccs_ws`

工作副本与 ASCII 构建输入逐文件 SHA-256 比较：
`55/55` 文件，`DIFF_COUNT=0`。

## 3. 根因与修复

原 v1.2 的直线速度目标为 100，弯道外轮目标为 110-130，但速度 PID 输出
最大只有 100；`Ki=0.15` 又会保留直行积分。实车高速时两路输出容易同时
饱和，虽然目标值差很大，硬件 PWM 差仍建立不出来。

修复内容：

1. 直线目标降为 60，PWM 上限降为 80%。
2. 官方圆弧半径 500 mm、轮距 180 mm 对应内/外轮半径 410/590 mm；
   正常圆弧目标使用 48/69，比例 0.6957。
3. 偏差增大时依次使用 30/70、12/72、0/72，增强恢复转向。
4. `Ki` 设为 0；目标变化时清除积分和微分历史。
5. PWM 每 5 ms 最大上升 4、最大下降 20，内轮可更快减速。
6. 编码器反馈取幅值，兼容两个电机镜像安装造成的计数符号相反。
7. 保留 v1.2 原灰度模式、K1 启停和 Motor1=右轮、Motor2=左轮映射。
8. `00000`、`11111` 模式仍立即把两路电机写 0。

参数集中在 `curve_params.h`。

## 4. 测试

主机测试覆盖：

- v1.2 原灰度模式路由；
- 左右弯镜像；
- 410/590 圆弧理论比；
- 分级差速与极限内轮零速；
- PID 目标切换复位；
- 慢加速、快减速和 PWM 限幅；
- 编码器正负极性归一化；
- 停止模式目标为零。

静态审计还验证：

- 原始 ZIP、XLSX 哈希未变；
- 五个受保护文件未变；
- ISR 无 OLED、UART、格式化和延时调用；
- `GROUP1_IRQHandler` 和 TIMER_PID IRQ 定义唯一；
- 两轮均使用编码器幅值；
- 停止模式直接写两路电机 0。

日志：

- `verification_curve_tuned/host_tests_final.log`
- `verification_curve_tuned/static_audit_final.log`
- `verification_curve_tuned/source_match_final.log`

## 5. CCS 构建

工具链自检：

- TI Arm Clang 4.0.4.LTS：PASS
- SysConfig 1.26.2+4477：PASS
- MSPM0 SDK 2.10.00.04：PASS
- MSPM0G3507 device：PASS

最终 Clean：

- 时间：2026-07-29 21:01:39 至 21:01:42（UTC+8）
- 返回值：0
- Problems：0 errors，0 warnings

最终 Full Build：

- 时间：2026-07-29 21:01:57 至 21:02:06（UTC+8）
- 返回值：0
- Problems：0 errors，1 warning
- 日志证明 `curve_control.c`、`pid.c`、`huidu.c`、`main.c` 均被编译，
  并生成、链接 `05_OLED.out`。

第一次 Full Build 曾因 Managed Build 递归发现主机测试中的第二个 `main`
而得到 2 errors；已把测试源改为目标构建默认 inert、主机测试宏启用，
随后重新 Clean/Full Build 通过。失败证据保留在
`ccs_full_build_attempt1_failed.log`，不得把该次 CLI 返回 0 误写成构建成功。

最终日志：

- `verification_curve_tuned/toolchain_verify.log`
- `verification_curve_tuned/ccs_clean_final.log`
- `verification_curve_tuned/ccs_full_build_final.log`

## 6. 固件产物

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| `firmware_curve_tuned/05_OLED.out` | 241036 | `86601C6547E45A9533649B888847E1422A1DC1A05B2797FB55D4619503602D1D` |
| `firmware_curve_tuned/05_OLED.map` | 48677 | `C23A0030D2262408A1D664BB82EA64F986AFCC8F87983905ACA9A33BB59AEB2F` |
| `firmware_curve_tuned/05_OLED_linkInfo.xml` | 261639 | `40EDDFE968B504685850AF6C5D3120BB25F465B04CD55043F595296961EB1E0C` |

## 7. 受保护文件

| 文件 | SHA-256 |
|---|---|
| `empty.syscfg` | `D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66` |
| `Debug/ti_msp_dl_config.h` | `219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0` |
| `Debug/ti_msp_dl_config.c` | `8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6` |
| `driver/uart.c` | `35036AA5EC1ED315DDCE5B138C481F17CF9354AC61D9509B001A591B6C3DEDFB` |
| `driver/uart.h` | `37546411CA0CA64D2AF0870BCAB9947C3CEFF75BE9C8077A53A440D193BC657C` |

未修改 SysConfig、生成配置和 UART。

## 8. 尚未验证

- 固件尚未下载；
- 编码器版本和输出轴每圈实际计数未测；
- 目标 60 对应的真实 rpm 未测；
- 左右轮方向和编码器幅值未在架空条件复核；
- 5 V 供电下电流、压降和温升未测；
- 0.5 m 半圆、完整一圈、≤20 s 和停车偏差≤2 cm 未测。

上板顺序见 `docs/CURVE_TUNING_BOARD_TEST.md`。回滚可切回本工程 Git 基线
提交，或从未改动的 v1.2 ZIP 重新解压。
