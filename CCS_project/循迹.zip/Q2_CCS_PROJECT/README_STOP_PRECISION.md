# H 题 Q2 v1.3 停车精度优化版

## 唯一应选固件

本工程本轮新生成、可供 CCS 下载器选择的文件为：

`firmware_stop_precision/05_OLED.out`

SHA-256：

`FE91656C0483A038000880C203DD585BAC759741B2FCADE508E8D1F2E09E7593`

工程内 `Debug`、`firmware_smooth_pid` 等目录中的 OUT 均为历史产物，
只作追溯，禁止误选。生成 OUT 只证明真实 CCS 构建成功，不代表已经下载或
通过实车停车精度验收。

## 本轮改动

- 保持 v1.3 已实测可正常循迹的 PID、传感器坐标、左右轮映射、
  Motor1 反向电气配置、灰度间隙保持、K4 急停和 25 s 硬超时不变。
- 运行时间小于 12 s 时继续使用 v1.3 的 `98/80/65` PWM。
- 12 s 至 14 s 使用 `82/70/58` PWM。
- 14 s 后使用 `60/54/46` PWM，直到检测终点。
- 仅在 `FINISH_ARMED` 状态下，未滤波的中央 B/C/D 连续 2 个 1 ms
  采样均为黑线时，立即清零 PID、目标 PWM 和当前 PWM，并在同一 ISR
  调用 `Motor_StopSafe()`。
- 原有“5 点多数滤波后的 B/C/D 连续 3 个 5 ms 控制周期”仍保留为
  回退停车通路。
- 不使用反向驱动制动，继续使用 TB6612 安全短路制动。

参数集中在 `curve_params.h`。诊断输出新增：

- `approach_stage`：0 为正常、1 为一级降速、2 为二级降速；
- `raw_finish_count`：raw B/C/D 连续计数；
- `finish_trigger`：0 无触发、1 raw 快速通路、2 滤波回退通路。

## 验证状态

| 层级 | 状态 | 证据 |
|---|---|---|
| 源码实现 | PASS | Git 差异、静态审计 |
| 主机算法测试 | PASS | `verification_stop_precision/host_tests.log` |
| 目标源桩语法 | PASS | `verification_stop_precision/target_syntax_check.log` |
| 静态审计 | PASS | `verification_stop_precision/static_audit.log` |
| 未修改 v1.3 基线 CCS Full Build | PASS | 返回 0、0 errors、1 个已知元数据 warning |
| 优化版 CCS Full Build | PASS | 返回 0、0 errors、1 个已知元数据 warning |
| 新 OUT 生成 | PASS | 本文所列 SHA-256 |
| 下载到开发板 | NOT RUN | 本机未执行下载 |
| 实车十轮停车误差 | NOT RUN | 必须上板记录 |
| 圈时、电流、温升 | NOT RUN | 必须上板记录 |

唯一 warning 是工程由 CCS 20.5.0 创建，而本次实际构建使用 CCS
20.4.1；未出现新增的编译器或链接器 warning。

## 烧录后操作

1. 车轮架空，确认 TB6612 `VM=5 V`、`STBY=3.3 V`、全系统共地并限流。
2. 只选择 `firmware_stop_precision/05_OLED.out`。
3. 下载后先架空验证 Motor1 为右轮、Motor2 为左轮及两轮前进方向。
4. 将灰度 C 的横截面放在起点/终点横线上，点按 K1 启动。
5. K4 随时急停。
6. 连续完成至少 10 轮，记录圈时和以灰度 C 横截面为基准的有符号停车偏差。
7. 验收要求：每轮绝对偏差 `<2 cm`，平均绝对偏差目标 `<=1 cm`，
   圈时 `<=19.5 s`。

参数后续调整规则见 `docs/STOP_PRECISION_ENGINEERING.md`，空白记录表见
`docs/STOP_PRECISION_BOARD_TEST.md`。

## 回滚

- 当前优化分支：`stop-precision-ready`。
- v1.3 导入基线提交：
  `49e0e3b0b807da7583ebb7c5965851c01d1eaf3d`。
- 原始 `balance_car_v1.3.zip` 保持未修改，可重新解压到新目录恢复。
- 不要覆盖或删除本工程中的历史固件；若需回滚，优先切换 Git 提交或从
  原 ZIP 新建副本。

