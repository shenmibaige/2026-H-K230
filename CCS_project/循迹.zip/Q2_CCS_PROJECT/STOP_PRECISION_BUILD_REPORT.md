# v1.3 停车精度优化版构建报告

## 输入与保护

- 原始 ZIP：
  `省赛/吕佳俊原始代码/balance_car_v1.3.zip`
- ZIP SHA-256：
  `799A72B54C33F1E3978712380EC146B4702F4090488F1086A75913980E7F5B8B`
- 最新引脚表 SHA-256：
  `3AEB6FE8554CAA555E5472FABC956EA6394D47C4EEDEF7D4C26A42FDC29CCA61`
- 官方 H 题 PDF SHA-256：
  `78FAAED3DCCC0F34AF3879AC53F046FB7D57920A2982FECB798B2C24826E25E3`
- 工作副本：
  `省赛/Code/2026.7.30/balance_car_v1.3_stop_precision_work`
- 未修改 ASCII 基线：
  `X:/TI_MSPM0_Toolchain/workspace/H_v13_stop_precision_20260730/baseline_v13`
- 优化版 ASCII 工程：
  `X:/TI_MSPM0_Toolchain/workspace/H_v13_stop_precision_20260730/q2_stop_precision`

原 ZIP、XLSX 和 PDF 均未修改。以下文件与 v1.3 导入基线 SHA-256
完全一致：

| 文件 | SHA-256 |
|---|---|
| `empty.syscfg` | `D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66` |
| `Debug/ti_msp_dl_config.h` | `219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0` |
| `Debug/ti_msp_dl_config.c` | `8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6` |
| `driver/uart.c` | `35036AA5EC1ED315DDCE5B138C481F17CF9354AC61D9509B001A591B6C3DEDFB` |
| `driver/uart.h` | `37546411CA0CA64D2AF0870BCAB9947C3CEFF75BE9C8077A53A440D193BC657C` |

## 实际工具

- CCS：20.4.1
- CCS CLI：
  `X:/TI_MSPM0_Toolchain/ccs2041/ccs/eclipse/ccs-server-cli.bat`
- TI Arm Clang：4.0.4.LTS
- MSPM0 SDK：2.10.00.04
- SysConfig：1.26.2+4477
- 目标器件：MSPM0G3507

产品发现和工具自检均返回 0。初始化日志证明 CCS 实际发现了上述编译器、
SDK 和 SysConfig。

## 真实 CCS 结果

| 工程 | 操作 | CLI 返回值 | Errors | Warnings | OUT |
|---|---:|---:|---:|---:|---|
| 未修改 v1.3 ASCII 基线 | Clean | 0 | 0 | 0 | 不适用 |
| 未修改 v1.3 ASCII 基线 | Full Build | 0 | 0 | 1 | 已生成 |
| 停车精度优化版 | Clean | 0 | 0 | 0 | 不适用 |
| 停车精度优化版 | Full Build | 0 | 0 | 1 | 已生成 |

两次 Full Build 的唯一 warning 均为：

> 工程元数据由 CCS 20.5.0 创建，当前 CCS 为 20.4.1。

没有新增编译器或链接器 warning。优化版完整日志明确包含
`curve_control.c`、`main.c`、`pid.c`、`driver/motor.c` 的重新编译和最终
链接命令。

## 产物哈希

| 工程 | 文件 | 字节 | SHA-256 |
|---|---|---:|---|
| 未修改基线 | `05_OLED.out` | 253792 | `2E025F6523A6181934A092AF92AD86167ED5AA64C448065EFD8D6E0D9E710F79` |
| 未修改基线 | `05_OLED.map` | 51327 | `35619B3458178477CB26FAF51CBA23C1811A164697220FE8CE26E00822885F7C` |
| 未修改基线 | `05_OLED_linkInfo.xml` | 273913 | `3792C0B44B0FC6EB5B5628566CDC7ADC6B39BD83073C5A4FA93A3FB6A1BE4CEE` |
| 优化版 | `05_OLED.out` | 256724 | `FE91656C0483A038000880C203DD585BAC759741B2FCADE508E8D1F2E09E7593` |
| 优化版 | `05_OLED.map` | 51827 | `563F6363BECC1BB4913F6D1F5228F9BAA662EAE9D5FADD1B8EC668B19C2BD77D` |
| 优化版 | `05_OLED_linkInfo.xml` | 275735 | `5D78C71FA8BDE085AC0447AB4045986988116792263D4BF473295863FBACCDB8` |

优化版与 ASCII 构建输入核对：

- 工作副本输入：40；
- ASCII 构建输入：40；
- 缺失：0；
- 额外：0；
- SHA-256 差异：0。

## 本机测试

| 检查 | 结果 |
|---|---|
| 主机算法测试 | PASS |
| 目标源桩语法检查 | PASS |
| ISR 无 OLED/UART/格式化/延时 | PASS |
| K4 先于终点采样 | PASS |
| raw BCD 第二个 1 ms 样本同 ISR 安全停车 | PASS |
| UART 无电机/PID/状态控制通路 | PASS |
| IRQ 定义唯一 | PASS |
| Motor1 反向电气配置保持 | PASS |
| 受保护文件哈希 | PASS |

日志目录：`verification_stop_precision`。

## 证据边界

- 已完成：代码实现、主机测试、目标源语法检查、静态审计、真实 CCS
  Clean/Full Build、OUT/MAP/linkInfo 生成。
- 尚未执行：开发板下载、轮向复核、电流、温升、圈时和停车偏差实测。
- `0.75–1.5 cm` 仅为基于原 2–4 cm 越线与速度平方近似的设计估算，
  不能写作硬件结果。

