#ifndef __PID_H
#define __PID_H

#include <stdint.h>

typedef struct {
	float Target;
	float Actual;
	float Out;
	
	float Kp;
	float Ki;
	float Kd;
	
	float Error0;
	float Error1;
	float ErrorInt;
	float ErrorIntMax;
	float ErrorIntMin;

	float OutMax;
	float OutMin;

	float OutRiseMax;
	float OutFallMax;
} PID_t;

void PID_Reset(PID_t *p);
void PID_SetTarget(PID_t *p, float target);
void PID_SetActualMagnitude(PID_t *p, int16_t encoder_delta);
void PID_Update(PID_t *p);

#endif
