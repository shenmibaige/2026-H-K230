#include "uart.h"
#include <stdarg.h>
#include "ti_msp_dl_config.h"   /* 图形化配置生成的头文件 */
volatile char UART_RxPacket[100];   // 接收数据包缓冲区，格式: "@MSG\r\n"
volatile uint8_t UART_RxFlag; // 接收完成标志，0-未就绪，1-新数据包就绪

/* 内部使用的幂函数 */
static uint32_t UART_Pow(uint32_t X, uint32_t Y)
{
    uint32_t Result = 1;
    while (Y--)
    {
        Result *= X;
    }
    return Result;
}

/**
 * 函    数：UART 发送一个字节（阻塞式）
 * 参    数：Byte 要发送的一个字节
 * 返 回 值：无
 */
void UART_SendByte(uint8_t Byte)
{
    DL_UART_Main_transmitDataBlocking(Serial_INST, Byte);
}

/**
 * 函    数：UART 发送一个数组
 * 参    数：Array 数组首地址
 * 参    数：Length 数组长度
 * 返 回 值：无
 */
void UART_SendArray(uint8_t *Array, uint16_t Length)
{
    uint16_t i;
    for (i = 0; i < Length; i++)
    {
        UART_SendByte(Array[i]);
    }
}

/**
 * 函    数：UART 发送一个字符串
 * 参    数：String 字符串首地址（以 '\0' 结尾）
 * 返 回 值：无
 */
void UART_SendString(char *String)
{
    uint8_t i;
    for (i = 0; String[i] != '\0'; i++)
    {
        UART_SendByte((uint8_t)String[i]);
    }
}

/**
 * 函    数：UART 发送数字（固定位数，不足补前导零）
 * 参    数：Number 要发送的数字，范围：0~4294967295
 * 参    数：Length 要发送数字的长度，范围：1~10
 * 返 回 值：无
 */
void UART_SendNumber(uint32_t Number, uint8_t Length)
{
    uint8_t i;
    for (i = 0; i < Length; i++)
    {
        UART_SendByte((uint8_t)((Number / UART_Pow(10, Length - i - 1) % 10) + '0'));
    }
}

/**
 * 函    数：printf 重定向底层函数（可配合标准库 printf 使用）
 * 参    数：ch 要输出的字符
 * 返 回 值：输出的字符
 */
int fputc(int ch, FILE *f)
{
    UART_SendByte((uint8_t)ch);
    return ch;
}

/**
 * 函    数：自封装的格式化输出函数
 * 参    数：format 格式化字符串
 * 参    数：... 可变参数列表
 * 返 回 值：无
 */
void UART_Printf(char *format, ...)
{
    char String[100];
    va_list arg;
    va_start(arg, format);
    vsprintf(String, format, arg);
    va_end(arg);
    UART_SendString(String);
}

/**
 * 函    数：UART 中断服务函数
 * 功    能：状态机解析 "@...\r\n" 格式的数据包
 * 注    意：函数名由宏 Serial_INST_IRQHandler 自动展开为 UARTO_IRQHandler
 *           必须与启动文件中的中断向量表名称一致
 */
void Serial_INST_IRQHandler(void)
{
    static uint8_t RxState = 0;      // 状态机状态 0-等待包头 1-接收数据 2-等待包尾
    static uint8_t pRxPacket = 0;    // 当前数据包写入位置

    /* 检查接收中断标志 */
    if (DL_UART_Main_getPendingInterrupt(Serial_INST) == DL_UART_IIDX_RX)
    {
        uint8_t RxData = DL_UART_Main_receiveData(Serial_INST);

        /* 状态机处理 */
        if (RxState == 0)
        {
            if (RxData == '@' && UART_RxFlag == 0)
            {
                RxState = 1;
                pRxPacket = 0;
            }
        }
        else if (RxState == 1)
        {
            if (RxData == '\r')
            {
                RxState = 2;
            }
            else
            {
                /* 缓冲区溢出保护 */
                if (pRxPacket < sizeof(UART_RxPacket) - 1)
                {
                    UART_RxPacket[pRxPacket] = (char)RxData;
                    pRxPacket++;
                }
            }
        }
        else if (RxState == 2)
        {
            if (RxData == '\n')
            {
                RxState = 0;
                UART_RxPacket[pRxPacket] = '\0';
                UART_RxFlag = 1;
            }
        }

        
    }
}
