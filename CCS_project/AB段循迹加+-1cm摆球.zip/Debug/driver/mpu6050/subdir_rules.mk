################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
driver/mpu6050/%.o: ../driver/mpu6050/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"F:/MCU/11_TI_MSP/CCS_ide/install/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"F:/MCU/11_TI_MSP/CCS_project/2026project/balance_car_v4.0/driver/mpu6050" -I"F:/MCU/11_TI_MSP/CCS_project/2026project/balance_car_v4.0/driver" -I"F:/MCU/11_TI_MSP/CCS_project/2026project/balance_car_v4.0" -I"F:/MCU/11_TI_MSP/CCS_project/2026project/balance_car_v4.0/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"driver/mpu6050/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


