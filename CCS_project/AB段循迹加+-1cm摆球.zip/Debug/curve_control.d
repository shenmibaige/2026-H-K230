# FIXED

curve_control.o: ../curve_control.c ../curve_control.h ../curve_params.h \
 ../curve_pid.h
../curve_control.h:
../curve_params.h:
../curve_pid.h:
