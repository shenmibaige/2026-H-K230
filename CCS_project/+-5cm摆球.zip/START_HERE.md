# H题第三问 v3.3.1：最短导入与启动

## 已有固件时直接烧录

1. 用CCS或UniFlash烧录`firmware/H_Q3_V331_QHOLD.out`。
2. 保持当前已验证的K230程序运行，并确保K230与M0共地。
3. 将钢球放在O点。
4. 复位M0后按K1一次。

## 需要在新电脑重新编译时

1. 解压ZIP；不要在压缩包内直接打开工程。
2. 建议使用新的CCS workspace。若旧workspace中已有`H_Q3_V33_QHOLD`，可只从workspace移除旧工程记录，不要勾选删除磁盘文件。
3. 在CCS中选择`File -> Import -> CCS Projects`，选择解压后的根目录，导入工程`H_Q3_V331_QHOLD`。
4. 执行`Project -> Clean`，再执行`Project -> Build Project`。
5. 生成文件应为`Debug/H_Q3_V331_QHOLD.out`；也可直接使用随包提供的`firmware/H_Q3_V331_QHOLD.out`烧录。

OLED显示`ARM/WAIT`时表示K1已锁存；中心资格满足后会自动进入`DRVA`，无需再次按键。K2可随时中止并使舵机回85度。

日常启动不要求舵机方向测试、分阶段试跑或手动PID标定。请确认文件名包含`V331`，不要误烧旧的`H_Q3_V33_QHOLD.out`。

