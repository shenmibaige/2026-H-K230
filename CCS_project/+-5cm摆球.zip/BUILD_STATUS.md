# BUILD STATUS — H题第三问 v3.3.1

## 结论

状态：`TARGET BUILT / PORTABLE REBUILD PASSED / HOST TESTS PASSED / NOT FLASHED / HARDWARE 5 s NOT ACCEPTED`

工程`H_Q3_V331_QHOLD`已在两个独立纯英文ASCII镜像完成CCS Clean/Full Build，均为0错误。携带文档、固件、两套构建证据和用户错误日志的最终交付结构又在第三个ASCII目录完成Clean/Full Build，同样为0错误；这专门验证了`build_logs`不会再次被CCS当作源码。这些结果证明工程可生成固件，不代表用户硬件烧录、K1运行、5秒指标或B点稳定性已经验收。

## 工具链

- CCS Server CLI：20.4.1
- TI Arm Clang：4.0.4.LTS
- MSPM0 SDK：2.10.0.04
- SysConfig：1.26.2
- 目标：MSPM0G3507，Debug配置

两套构建证据：

- `build_logs/mirror_a/ccs_clean.log`
- `build_logs/mirror_a/ccs_full.log`
- `build_logs/mirror_b/ccs_clean.log`
- `build_logs/mirror_b/ccs_full.log`
- `build_logs/final_package_rebuild/ccs_clean.log`
- `build_logs/final_package_rebuild/ccs_full.log`

两份Full Build日志均包含`ball_quiet_observer.c`、`ball_controller.c`、`ball_fast_estimator.c`、`ball_estimator.c`、`ball_pid_bank.c`和`main.c`，且只链接一份工程生成的`ti_msp_dl_config.o`和一份`device_linker.cmd`。没有`build_logs`输入，没有`#10263/#10264/#10010`错误。唯一警告是工程元数据来自CCS 20.5、当前CLI为20.4.1，不影响本次成功构建。

第三次最终包结构重建同样只链接上述单份输入。其原始OUT SHA-256为`4A3F99ED17864235B05610B140EC68678DB2270218B60152968FAD837E44D583`；stripped OUT仍为`267FC34225BE5307B822B30C3402657DC2946DEA9D251533AA775BD5815EBEAF`。

## 固件和迁移一致性

镜像A原始OUT：

- SHA-256：`3800DF90A94EA78376D2F2ABD39E8119A1DDAF0720587C64A559681CDF192A85`

镜像B原始OUT：

- SHA-256：`5538C7FC9666E26769830949DF8AC85C6FAC0F10EF8C0D9B3141483873851FEB`

原始OUT包含不同的DWARF绝对调试路径。分别运行TI`tiarmstrip --postlink`后，两文件以及v3.3基线stripped OUT三者字节一致：

- SHA-256：`267FC34225BE5307B822B30C3402657DC2946DEA9D251533AA775BD5815EBEAF`

正式烧录固件为镜像A原始可调试输出：

`firmware/H_Q3_V331_QHOLD.out`

- SHA-256：`3800DF90A94EA78376D2F2ABD39E8119A1DDAF0720587C64A559681CDF192A85`

两套原始OUT、MAP、linkInfo、stripped OUT及日志保存在`build_logs/mirror_a`和`build_logs/mirror_b`。为避免旧故障，证据目录不含`.c/.cmd/.opt`文件。

## SRAM与FLASH

| 项目 | 字节 | 十六进制 |
|---|---:|---:|
| `.bss` | 16825 | 0x41B9 |
| `.data` | 46 | 0x002E |
| stack | 512 | 0x0200 |
| heap / `.sysmem` | 0 | 0x0000 |
| SRAM总占用 | 17383 | 0x43E7 |
| SRAM容量 | 32768 | 0x8000 |
| SRAM剩余 | 15385（46.95%） | 0x3C19 |
| FLASH占用 | 53520 | 0xD110 |
| FLASH容量 | 131072 | 0x20000 |

SRAM剩余高于20%要求。

## 受保护文件

- `empty.syscfg`内容SHA-256：`D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66`
- `ti_msp_dl_config.c`：`8891B33F75C8F42927D6F86F5ECBC17FA8F4EF0A96C15F69317C1770928ECFF6`
- `ti_msp_dl_config.h`：`219A7830380003C431D6CAE0AEF6577A424112000FFE3E72B22D9F942B1BB6C0`

`empty.syscfg`仅规范化文件时间戳以触发SysConfig，内容未改变；生成配置的内容哈希与v3.3一致。

## 主机软件验收

- M0测试：56 passed，0 failed。
- K230兼容检查：6 passed，0 failed。
- 新增静态检查：`.cproject`排除交付证据/固件/主机测试/K230目录；`build_logs`不含重复生成输入。
- 静止噪声10秒：QHLD后非85度命令0、新动作事件0、退出0、任意1秒最大动作0。
- 10/15/20度死区模型`tDone`为4.280、3.600、4.260秒。
- 联合模型`tDone=4.429 s`。
- 43个控制源码头文件与v3.3逐项哈希一致；stripped固件一致。

详见`host_tests/results.txt`、`host_tests/static_checks.txt`和`PORTABLE_BUILD_FIX.md`。这些是主机模型和构建结果，不是实物成绩。

## 尚未完成

- 未将v3.3.1固件烧录到用户MSPM0G3507。
- 未执行v3.3.1的K1实物运行。
- 未取得本版本K3实物CSV和视频。
- 未验证实物`tDone<=5 s`、静默后舵机动作次数、最终误差、过冲、穿越次数及连续20次通过率。
