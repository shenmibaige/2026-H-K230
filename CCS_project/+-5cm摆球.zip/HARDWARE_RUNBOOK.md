# H题第三问 v3.3.1 实物运行手册

## 日常直接启动

1. 烧录 `firmware/H_Q3_V331_QHOLD.out`。
2. 保持当前K230程序运行，并确保K230与M0共地。
3. 将钢球放在O点。
4. 复位M0后按K1一次。

OLED显示`ARM/WAIT`时表示K1已锁存；中心资格满足后会自动启动，无需再次按键。K2可随时中止并立即回85度。日常运行不要求复杂前测或手动PID标定。

## OLED状态

- `WAIT/RDY/ARM`：中心资格采集、已就绪、启动锁存。
- `DRVA/BRKA/ACAP`：A段驱动、提前制动、转折捕获。
- `DRVB/BAPR/BRKB/BSET`：B段驱动、分级接近、固定主制动、末端稳定。
- `QHLD`：B点静默保持，舵机默认85度。
- `QPUL`：经确认的一次静默修正脉冲。
- `QOBS`：脉冲后强制观察和限频。
- `QREC`：真实漂移已经确认，正在只重捕获B。
- `DONE`：完成后继续监控B。
- `VISN`：80 ms视觉故障或`-999`，舵机已回85度。
- `TOUT`：5秒未完成，但仍继续稳定B；结果保持TIMEOUT。

B末端页面显示`quiet_error`、5点位置极差、静默年龄、舵机动作计数和退出/脉冲计数，刷新仍不超过4 Hz。

## K3日志

任务结束后按K3，通过PA28导出CSV。原34列顺序保持不变，末尾追加：

`quiet_error100,quiet_flags,servo_event_count`

任务摘要追加：

- `tQuiet`
- `quietExit`
- `quietPulse`
- `servoEvents`
- `quietReason`
- `maxQuietErr100`
- `maxServo1s`

活动记录的`pidmask`应为63（`0x3F`）。没有连接反向串口不影响控制。

## 首轮必须回传

- `tA`
- `tB_approach`
- `tB_brake`
- `tB_band`
- `tQuiet`
- `tDone`
- `quiet_exit_count`
- `quiet_pulse_count`
- `servo_event_count`
- 首次过冲
- B穿越次数
- 最终误差
- 完整K3 CSV
- 从按K1到DONE后至少1秒的完整视频

## 正式验收

正式验收不是日常启动前置条件：

- 每次只执行一次O到A到B。
- A转折误差不超过0.8 cm。
- 内部目标不超过4.5秒，官方最迟不得超过5秒。
- B完成误差不超过0.6 cm。
- DONE后1秒最大误差不超过0.8 cm。
- 首次满足稳定条件后1秒内非中心动作段不超过1次，不出现正负方向反复切换。
- 无持续振荡，视觉停止后不继续使用旧位置。
- 正式照明、独立稳压5 V并共地，连续测试20次。

软件测试、CCS构建和预编译固件不能替代这些实物证据。
