#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "ball_config.h"
#include "ball_controller.h"
#include "ball_estimator.h"
#include "ball_ui.h"
#include "oled.h"
#include "uart.h"

volatile uint32_t system_ms = 0u;
uint8_t g_host_uart_rx_byte = 0u;
uint32_t g_host_i2c_transfer_count = 0u;

void delay_ms(uint32_t ms)
{
    system_ms += ms;
}

static int g_failures = 0;
static int g_tests_run = 0;

#define CHECK(condition, message) \
    do { \
        if (!(condition)) { \
            printf("    CHECK FAILED: %s (line %d)\n", message, __LINE__); \
            return 0; \
        } \
    } while (0)

typedef struct {
    BallController controller;
    float x_cm;
    float velocity_cm_s;
    float history_cm[4];
    uint32_t now_ms;
    float deadzone_deg;
    uint8_t lag_frames;
    uint8_t noise_enabled;
    uint8_t drop_enabled;
    uint8_t servo_lag_enabled;
    uint32_t tick;
    float actual_servo_offset_deg;
    float k230_filtered_px;
    float k230_jump_min_px;
    float k230_jump_max_px;
    uint8_t k230_jump_count;
    float a_brake_x_cm;
    float b_brake_x_cm;
    uint32_t observed_t_a_ms;
    uint32_t observed_t_b_ms;
    uint32_t observed_t_done_ms;
    float first_drive_b_servo_deg;
    uint8_t saw_a_brake;
    uint8_t saw_drive_b;
    uint8_t saw_b_brake;
    uint8_t saw_pulse_below_20;
    uint32_t prefix_hash;
    uint16_t prefix_cycles;
    uint8_t prefix_complete;
} BallSimulation;

static float absf_local(float value)
{
    return (value < 0.0f) ? -value : value;
}

static uint32_t fnv1a_u32(uint32_t hash, uint32_t value)
{
    uint8_t i;
    for (i = 0u; i < 4u; ++i) {
        hash ^= (uint8_t)(value & 0xFFu);
        hash *= 16777619u;
        value >>= 8;
    }
    return hash;
}

static int16_t position_to_dx(float position_cm, int noise_px)
{
    float raw = -position_cm * BALL_PX_PER_CM + (float)noise_px;
    if (raw > 32767.0f) {
        raw = 32767.0f;
    }
    if (raw < -32768.0f) {
        raw = -32768.0f;
    }
    return (int16_t)((raw >= 0.0f) ? (raw + 0.5f) : (raw - 0.5f));
}

static uint32_t prime_ready_controller(BallController *controller,
                                       uint32_t now_ms,
                                       uint32_t frame_ms)
{
    uint8_t i;
    for (i = 0u; i < BALL_CENTER_SAMPLE_COUNT; ++i) {
        now_ms += frame_ms;
        BallController_OnMeasurement(controller, 0, now_ms);
    }
    return now_ms;
}

static void simulation_init(BallSimulation *simulation,
                            float deadzone_deg,
                            uint8_t lag_frames,
                            uint8_t noise_enabled,
                            uint8_t drop_enabled)
{
    uint8_t i;
    memset(simulation, 0, sizeof(*simulation));
    simulation->deadzone_deg = deadzone_deg;
    simulation->lag_frames = lag_frames;
    simulation->noise_enabled = noise_enabled;
    simulation->drop_enabled = drop_enabled;
    simulation->prefix_hash = 2166136261u;
    BallController_Init(&simulation->controller, 0u);
    simulation->now_ms = prime_ready_controller(&simulation->controller, 0u, 20u);
    BallController_RequestStart(&simulation->controller, simulation->now_ms);
    for (i = 0u; i < 4u; ++i) {
        simulation->history_cm[i] = 0.0f;
    }
}

static uint32_t simulation_interval_ms(const BallSimulation *simulation)
{
    static const uint8_t jitter_ms[] = {17u, 22u, 16u, 21u, 18u, 20u};
    if ((simulation->noise_enabled != 0u) || (simulation->drop_enabled != 0u)) {
        return jitter_ms[simulation->tick %
                         (sizeof(jitter_ms) / sizeof(jitter_ms[0]))];
    }
    return 20u;
}

static int simulation_noise_px(const BallSimulation *simulation)
{
    static const int8_t noise_px[] = {-5, 5, -5, 5, -5, 5, -5, 5};
    static const int8_t correlated_noise_px[] = {
        -2, -2, 2, 2
    };
    if (simulation->noise_enabled == 0u) {
        return 0;
    }
    if (simulation->noise_enabled >= 2u) {
        return correlated_noise_px[simulation->tick %
            (sizeof(correlated_noise_px) /
             sizeof(correlated_noise_px[0]))];
    }
    return noise_px[simulation->tick %
                    (sizeof(noise_px) / sizeof(noise_px[0]))];
}

static int16_t simulation_measurement_dx(BallSimulation *simulation,
                                         float measured_cm,
                                         uint32_t dt_ms)
{
    float raw_px = -measured_cm * BALL_PX_PER_CM +
        (float)simulation_noise_px(simulation);

    (void)dt_ms;
    if (raw_px > 32767.0f) {
        raw_px = 32767.0f;
    } else if (raw_px < -32768.0f) {
        raw_px = -32768.0f;
    }

    /* Exact K230 origin behavior: 300 px jump gate, ten-frame accept,
     * fixed 0.7 old + 0.3 new low-pass, then Python int() truncation. */
    if (absf_local(raw_px - simulation->k230_filtered_px) > 300.0f) {
        if (simulation->k230_jump_count == 0u) {
            simulation->k230_jump_min_px = raw_px;
            simulation->k230_jump_max_px = raw_px;
        } else {
            if (raw_px < simulation->k230_jump_min_px) {
                simulation->k230_jump_min_px = raw_px;
            }
            if (raw_px > simulation->k230_jump_max_px) {
                simulation->k230_jump_max_px = raw_px;
            }
        }
        if (simulation->k230_jump_count < 255u) {
            simulation->k230_jump_count++;
        }
        if (simulation->k230_jump_count >= 10u) {
            if ((simulation->k230_jump_max_px -
                 simulation->k230_jump_min_px) <= 300.0f) {
                simulation->k230_filtered_px = raw_px;
            }
            simulation->k230_jump_count = 0u;
        }
    } else {
        simulation->k230_jump_count = 0u;
        simulation->k230_filtered_px =
            0.7f * simulation->k230_filtered_px + 0.3f * raw_px;
    }
    return (int16_t)simulation->k230_filtered_px;
}

static void simulation_plant_step(BallSimulation *simulation, uint32_t dt_ms)
{
    float dt_s = (float)dt_ms * 0.001f;
    float offset_deg = simulation->controller.servo_command_deg -
                       BALL_SERVO_CENTER_DEG;
    float effective_deg = 0.0f;
    float acceleration_cm_s2;
    uint8_t i;

    if (simulation->servo_lag_enabled != 0u) {
        /* One visual-cycle actuator response lag. */
        float blend = dt_s / 0.020f;
        if (blend > 1.0f) {
            blend = 1.0f;
        }
        simulation->actual_servo_offset_deg +=
            blend * (offset_deg - simulation->actual_servo_offset_deg);
    } else {
        simulation->actual_servo_offset_deg = offset_deg;
    }
    offset_deg = simulation->actual_servo_offset_deg;

    if (offset_deg > simulation->deadzone_deg) {
        effective_deg = offset_deg - simulation->deadzone_deg;
    } else if (offset_deg == simulation->deadzone_deg) {
        effective_deg = 1.0f;
    } else if (offset_deg < -simulation->deadzone_deg) {
        effective_deg = offset_deg + simulation->deadzone_deg;
    } else if (offset_deg == -simulation->deadzone_deg) {
        effective_deg = -1.0f;
    }

    acceleration_cm_s2 = 2.75f * effective_deg -
                          1.05f * simulation->velocity_cm_s;
    simulation->velocity_cm_s += acceleration_cm_s2 * dt_s;
    simulation->x_cm += simulation->velocity_cm_s * dt_s;

    for (i = 3u; i > 0u; --i) {
        simulation->history_cm[i] = simulation->history_cm[i - 1u];
    }
    simulation->history_cm[0] = simulation->x_cm;
}

static void simulation_note_transition(BallSimulation *simulation,
                                       BallState old_state)
{
    BallState new_state = simulation->controller.state;
    uint32_t elapsed_ms = BallController_TaskElapsedMs(&simulation->controller,
                                                       simulation->now_ms);
    if ((old_state != BALL_STATE_BRAKE_A) &&
        (new_state == BALL_STATE_BRAKE_A)) {
        simulation->saw_a_brake = 1u;
        simulation->a_brake_x_cm = simulation->controller.position_cm;
    }
    if ((old_state != BALL_STATE_DRIVE_B) &&
        (new_state == BALL_STATE_DRIVE_B)) {
        simulation->saw_drive_b = 1u;
        simulation->first_drive_b_servo_deg =
            simulation->controller.servo_command_deg;
        simulation->observed_t_a_ms = elapsed_ms;
    }
    if ((old_state != BALL_STATE_BRAKE_B) &&
        (new_state == BALL_STATE_BRAKE_B)) {
        simulation->saw_b_brake = 1u;
        simulation->b_brake_x_cm = simulation->controller.position_cm;
        simulation->observed_t_b_ms = elapsed_ms;
    }
    if ((old_state != BALL_STATE_DONE_HOLD) &&
        (new_state == BALL_STATE_DONE_HOLD)) {
        simulation->observed_t_done_ms = elapsed_ms;
    }
    if ((new_state == BALL_STATE_B_SETTLE) ||
        (new_state == BALL_STATE_TIMEOUT)) {
        float offset = absf_local(simulation->controller.servo_command_deg -
                                  BALL_SERVO_CENTER_DEG);
        if ((offset > 0.1f) && (offset < 19.9f)) {
            simulation->saw_pulse_below_20 = 1u;
        }
    }
}

static void simulation_step(BallSimulation *simulation)
{
    uint32_t dt_ms = simulation_interval_ms(simulation);
    uint8_t drop;
    uint8_t lag_index;
    float measured_cm;
    int16_t filtered_dx;
    BallState old_state;

    simulation_plant_step(simulation, dt_ms);
    simulation->now_ms += dt_ms;
    simulation->tick++;

    drop = (simulation->drop_enabled != 0u) &&
           ((simulation->tick % 19u) == 0u);
    lag_index = simulation->lag_frames;
    if (lag_index > 3u) {
        lag_index = 3u;
    }
    measured_cm = simulation->history_cm[lag_index];
    filtered_dx = simulation_measurement_dx(simulation,
                                             measured_cm,
                                             dt_ms);
    /* A UART packet loss does not stop the K230 from updating its own 0.7/0.3
     * filter.  Detection failure (-999) is tested as a distinct fault path. */
    if (drop != 0u) {
        return;
    }
    old_state = simulation->controller.state;
    BallController_OnMeasurement(&simulation->controller,
                                 filtered_dx,
                                 simulation->now_ms);
    simulation_note_transition(simulation, old_state);
    if (simulation->prefix_complete == 0u) {
        uint16_t servo10 = (uint16_t)(
            simulation->controller.servo_command_deg * 10.0f + 0.5f);
        simulation->prefix_hash = fnv1a_u32(simulation->prefix_hash,
            BallController_TaskElapsedMs(&simulation->controller,
                                          simulation->now_ms));
        simulation->prefix_hash = fnv1a_u32(simulation->prefix_hash,
            (uint16_t)filtered_dx);
        simulation->prefix_hash = fnv1a_u32(simulation->prefix_hash,
            (uint8_t)simulation->controller.state);
        simulation->prefix_hash = fnv1a_u32(simulation->prefix_hash,
                                            servo10);
        simulation->prefix_cycles++;
        if (simulation->controller.state == BALL_STATE_B_SETTLE) {
            simulation->prefix_complete = 1u;
        }
    }
}

static uint8_t simulation_run(BallSimulation *simulation, uint32_t max_task_ms)
{
    uint32_t guard = 0u;
    while ((simulation->controller.state != BALL_STATE_DONE_HOLD) &&
           (simulation->controller.state != BALL_STATE_VISION_FAULT) &&
           (guard < 1000u)) {
        simulation_step(simulation);
        guard++;
        if (BallController_TaskElapsedMs(&simulation->controller,
                                         simulation->now_ms) > max_task_ms) {
            break;
        }
    }
    return (simulation->controller.state == BALL_STATE_DONE_HOLD) ? 1u : 0u;
}

static uint32_t prepare_done_quiet_controller(BallController *controller,
                                              uint32_t now_ms)
{
    uint8_t i;

    BallController_Init(controller, 0u);
    controller->state = BALL_STATE_B_SETTLE;
    controller->task_started = 1u;
    controller->task_start_ms = 0u;
    controller->dx_zero_px = 0;
    for (i = 0u; i < 30u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(controller,
                                     position_to_dx(-5.0f, 0), now_ms);
        if (controller->state == BALL_STATE_DONE_HOLD) {
            break;
        }
    }
    return now_ms;
}

static int16_t k230_origin_filter_step(float position_cm,
                                       int noise_px,
                                       float *filtered_px)
{
    float raw_px = -position_cm * BALL_PX_PER_CM + (float)noise_px;

    /* The jump is below 300 px, so the original script follows this exact
     * 0.7-old/0.3-new branch and Python int() truncates toward zero. */
    *filtered_px = 0.7f * (*filtered_px) + 0.3f * raw_px;
    return (int16_t)(*filtered_px);
}

static int test_01_a_predictive_brake_and_turn(void)
{
    BallSimulation simulation;
    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&simulation, 4500u) != 0u,
          "nominal simulation must complete");
    CHECK(simulation.saw_a_brake != 0u, "A brake transition missing");
    CHECK(simulation.a_brake_x_cm < 5.0f,
          "A braking must begin before actual +5 cm");
    CHECK(simulation.controller.diagnostics.a_turn_cm >= BALL_A_TURN_MIN_CM,
          "A turn is before 4.2 cm");
    CHECK(simulation.controller.diagnostics.a_turn_cm <= BALL_A_TURN_MAX_CM,
          "A turn is after 5.8 cm");
    CHECK(simulation.controller.diagnostics.t_a_ms <= BALL_BUDGET_A_TURN_MS,
          "tA exceeds 1.5 s");
    CHECK(simulation.controller.diagnostics.t_done_ms <= 4000u,
          "typical software model exceeds the 4.0 s target");
    return 1;
}

static int test_02_active_drive_b_no_coast(void)
{
    BallSimulation simulation;
    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&simulation, 4500u) != 0u,
          "nominal simulation must complete");
    CHECK(simulation.saw_drive_b != 0u, "DRIVE_B was never entered");
    CHECK(simulation.first_drive_b_servo_deg <= 55.1f,
          "A to B must immediately command active negative drive");
    CHECK(simulation.first_drive_b_servo_deg < BALL_SERVO_CENTER_DEG,
          "A to B command cannot be centre/coast");
    return 1;
}

static int test_03_b_predictive_brake_before_endpoint(void)
{
    BallSimulation simulation;
    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&simulation, 4500u) != 0u,
          "nominal simulation must complete");
    CHECK(simulation.saw_b_brake != 0u, "B brake transition missing");
    CHECK(simulation.b_brake_x_cm > BALL_TARGET_B_CM,
          "B braking waited until/after -5 cm");
    CHECK(simulation.controller.diagnostics.t_b_enter_ms <=
          BALL_BUDGET_B_BRAKE_MS,
          "B braking begins after 3.2 s");
    CHECK(simulation.controller.diagnostics.b_first_overshoot_cm <= 0.80f,
          "first B overshoot exceeds 0.8 cm in the nominal model");
    return 1;
}

static int test_04_deadzone_10_15_20(void)
{
    const float deadzones[] = {10.0f, 15.0f, 20.0f};
    uint8_t i;
    for (i = 0u; i < 3u; ++i) {
        BallSimulation simulation;
        uint8_t completed;
        simulation_init(&simulation, deadzones[i], 0u, 0u, 0u);
        completed = simulation_run(&simulation, 4500u);
        printf("    deadzone=%.0f state=%s t=%lu x=%.2f v=%.2f "
               "tA=%lu tApr=%lu tBrk=%lu tBand=%lu vB=%.2f "
               "tSet=%lu tDone=%lu tQuiet=%lu over=%.2f cross=%u "
               "qmode=%u qactive=%u qp=%u se=%u\n",
               (double)deadzones[i],
               BallController_StateShort(simulation.controller.state),
               (unsigned long)BallController_TaskElapsedMs(&simulation.controller,
                                                            simulation.now_ms),
               (double)simulation.x_cm,
               (double)simulation.velocity_cm_s,
               (unsigned long)simulation.controller.diagnostics.t_a_ms,
               (unsigned long)simulation.controller.diagnostics.t_b_approach_ms,
               (unsigned long)simulation.controller.diagnostics.t_b_brake_ms,
               (unsigned long)simulation.controller.diagnostics.t_b_band_ms,
               (double)simulation.controller.diagnostics.b_band_entry_velocity_cm_s,
               (unsigned long)simulation.controller.diagnostics.t_b_settle_ms,
               (unsigned long)simulation.controller.diagnostics.t_done_ms,
               (unsigned long)simulation.controller.diagnostics.t_quiet_enter_ms,
               (double)simulation.controller.diagnostics.b_first_overshoot_cm,
               (unsigned)simulation.controller.diagnostics.b_cross_count,
               (unsigned)simulation.controller.settle_mode,
               (unsigned)simulation.controller.quiet_active,
               (unsigned)simulation.controller.diagnostics.quiet_pulse_count,
               (unsigned)simulation.controller.diagnostics.servo_event_count);
        CHECK(completed != 0u,
              "deadzone simulation did not complete within 4.5 s");
        CHECK(simulation.controller.diagnostics.t_done_ms <=
              BALL_BUDGET_DONE_MS,
              "deadzone simulation missed internal completion budget");
    }
    return 1;
}

static int test_05_effective_pulses_not_12_degrees(void)
{
    BallController controller;
    uint32_t now_ms = 100u;
    float offset;
    uint8_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.task_start_ms = 0u;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 3u; ++i) {
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.0f, 0), now_ms);
        now_ms += 20u;
    }
    offset = absf_local(controller.servo_command_deg - BALL_SERVO_CENTER_DEG);
    CHECK(offset >= 19.9f, "initial static correction must be at least 20 degrees");
    CHECK(absf_local(offset - 12.0f) > 0.5f,
          "12 degree fine output must not return");

    for (i = 0u; i < 16u; ++i) {
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.0f, 0), now_ms);
        now_ms += 20u;
    }
    offset = absf_local(controller.servo_command_deg - BALL_SERVO_CENTER_DEG);
    CHECK(offset >= 21.9f,
          "two ineffective pulses must escalate from 20 to 22 degrees");
    CHECK(offset <= BALL_PULSE_MAX_OFFSET_DEG + 0.1f,
          "pulse exceeds 26 degree maximum");
    return 1;
}

static int test_06_true_time_velocity_45_to_60_fps(void)
{
    const uint32_t intervals[] = {17u, 22u, 8u, 60u, 19u, 16u, 21u, 18u};
    const uint32_t sixty_fps_ms[] = {17u, 17u, 16u};
    BallEstimator estimator;
    BallEstimate estimate;
    BallController controller;
    uint32_t now_ms = 0u;
    uint8_t i;

    BallEstimator_Init(&estimator);
    BallEstimator_Add(&estimator, 0.0f, now_ms, &estimate);
    for (i = 0u; i < 40u; ++i) {
        uint32_t dt_ms = intervals[i %
            (sizeof(intervals) / sizeof(intervals[0]))];
        now_ms += dt_ms;
        BallEstimator_Add(&estimator, (float)now_ms * 0.010f,
                          now_ms, &estimate);
    }
    CHECK(estimate.velocity_valid != 0u, "velocity should be valid");
    CHECK(absf_local(estimate.velocity_cm_s - 10.0f) < 0.08f,
          "velocity is not in cm/s under frame jitter");

    now_ms += 61u;
    BallEstimator_Add(&estimator, (float)now_ms * 0.010f,
                      now_ms, &estimate);
    CHECK(estimate.gap_reset != 0u, "61 ms interval must reset estimator");
    CHECK(estimate.velocity_valid == 0u,
          "first sample after reset cannot report fitted velocity");

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_A_CAPTURE;
    controller.task_started = 1u;
    controller.task_start_ms = 1u;
    controller.dx_zero_px = 0;
    controller.position_cm = 5.0f;
    controller.last_position_cm = 5.0f;
    controller.last_position_ms = now_ms;
    controller.stage_start_ms = now_ms;
    controller.has_last_position = 1u;
    controller.adjacent_velocity_cm_s = 2.0f;
    controller.has_adjacent_velocity = 1u;
    controller.a_peak_cm = 5.0f;
    controller.a_peak_valid = 1u;
    now_ms += 61u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(4.9f, 0), now_ms);
    CHECK(controller.state == BALL_STATE_A_CAPTURE,
          "a rejected frame gap falsely captured the A turning point");
    CHECK(controller.diagnostics.t_a_ms == 0u,
           "A turn interpolation must reset across a gap over 60 ms");
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(4.84f, 0), now_ms);
    CHECK(controller.state == BALL_STATE_A_CAPTURE,
           "A peak fallback must require two consecutive reverse frames");
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(4.78f, 0), now_ms);
    CHECK(controller.state == BALL_STATE_DRIVE_B,
           "A capture did not recover after a 61 ms frame gap");
    CHECK(controller.diagnostics.a_transition_reason ==
          BALL_TRANSITION_A_PEAK_FALLBACK,
          "gap recovery did not use the tracked A peak");

    BallController_Init(&controller, 0u);
    now_ms = 0u;
    for (i = 0u; i < BALL_CENTER_SAMPLE_COUNT; ++i) {
        now_ms += sixty_fps_ms[i % 3u];
        BallController_OnMeasurement(&controller, 0, now_ms);
    }
    CHECK(BallController_IsReady(&controller) != 0u,
           "31 stable samples at 60 FPS must establish RDY");
    CHECK(controller.state == BALL_STATE_WAIT_CENTER,
           "pre-K1 centre qualification must remain in WAIT_CENTER");
    BallController_RequestStart(&controller, now_ms);
    CHECK(BallController_IsArmed(&controller) != 0u,
          "K1 at RDY did not latch the start request");
    now_ms += 17u;
    BallController_OnMeasurement(&controller, 0, now_ms);
    CHECK(controller.state == BALL_STATE_DRIVE_A,
          "latched K1 did not enter DRIVE_A on the next visual cycle");
    CHECK(controller.task_start_ms == now_ms,
          "READY wait must not be included in task time");
    return 1;
}

static int test_07_lag_noise_and_drops(void)
{
    BallSimulation simulation;
    uint8_t completed;
    simulation_init(&simulation, 15.0f, 2u, 1u, 1u);
    completed = simulation_run(&simulation, BALL_BUDGET_DONE_MS);
    printf("    noisy state=%s t=%lu x=%.2f plantV=%.2f measured=%.2f estV=%.2f tA=%lu tB=%lu band=%lu tDone=%lu\n",
           BallController_StateShort(simulation.controller.state),
           (unsigned long)BallController_TaskElapsedMs(&simulation.controller,
                                                        simulation.now_ms),
           (double)simulation.x_cm,
           (double)simulation.velocity_cm_s,
           (double)simulation.controller.position_cm,
           (double)simulation.controller.velocity_cm_s,
           (unsigned long)simulation.controller.diagnostics.t_a_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_enter_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_band_ms,
           (unsigned long)simulation.controller.diagnostics.t_done_ms);
    CHECK(completed != 0u,
          "40 ms lag/noise/drop simulation did not complete by 4.5 s");
    CHECK(simulation.controller.state == BALL_STATE_DONE_HOLD,
          "lag/noise/drop run did not settle at B");
    CHECK(simulation.controller.diagnostics.t_done_ms <=
          BALL_BUDGET_DONE_MS,
          "lag/noise/drop run exceeded the 4.5 s software target");
    return 1;
}

static int test_08_vision_timeout_centres_and_resets(void)
{
    BallController controller;
    uint32_t now_ms;
    BallController_Init(&controller, 0u);
    now_ms = prime_ready_controller(&controller, 0u, 20u);
    CHECK(BallController_IsReady(&controller) != 0u,
          "controller did not prequalify before timeout test");
    BallController_RequestStart(&controller, now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller, 0, now_ms);
    CHECK(controller.state == BALL_STATE_DRIVE_A,
           "ready controller did not start");
    BallController_OnVisionFault(&controller, now_ms + 80u, 80u);
    CHECK(controller.state == BALL_STATE_VISION_FAULT,
          "80 ms timeout must enter VISION_FAULT");
    CHECK(absf_local(controller.servo_command_deg - BALL_SERVO_CENTER_DEG) < 0.01f,
          "vision timeout must command 85 degrees");
    CHECK(controller.estimator.count == 0u,
          "vision timeout must clear estimator history");
    CHECK(controller.fast_estimator.count == 0u,
          "vision timeout must clear fast-estimator history");
    CHECK(controller.velocity_fast_valid == 0u,
          "vision timeout left a valid fast velocity");
    CHECK(controller.pid_bank.update_mask == 0u,
          "vision timeout left stale PID output history");
    CHECK(controller.center_count == 0u,
          "vision timeout must clear centre history");
    return 1;
}

static int test_09_k2_aborts_every_active_state(void)
{
    const BallState active_states[] = {
        BALL_STATE_WAIT_CENTER, BALL_STATE_DRIVE_A, BALL_STATE_BRAKE_A,
        BALL_STATE_A_CAPTURE, BALL_STATE_DRIVE_B, BALL_STATE_B_APPROACH,
        BALL_STATE_BRAKE_B,
        BALL_STATE_B_SETTLE, BALL_STATE_DONE_HOLD, BALL_STATE_TIMEOUT
    };
    uint8_t i;
    for (i = 0u; i < (sizeof(active_states) / sizeof(active_states[0])); ++i) {
        BallController controller;
        BallController_Init(&controller, 0u);
        controller.state = active_states[i];
        controller.task_started = 1u;
        controller.servo_command_deg = 120.0f;
        controller.estimator.count = 5u;
        controller.fast_estimator.count = 3u;
        BallController_RequestAbort(&controller, 123u);
        CHECK(controller.state == BALL_STATE_ABORTED,
              "K2 did not enter ABORTED");
        CHECK(absf_local(controller.servo_command_deg - BALL_SERVO_CENTER_DEG) < 0.01f,
              "K2 did not centre servo");
        CHECK(controller.estimator.count == 0u,
              "K2 did not clear estimator");
        CHECK(controller.fast_estimator.count == 0u,
              "K2 did not clear fast estimator");
    }
    return 1;
}

static int test_10_done_hold_drift_recaptures_b_only(void)
{
    BallController controller;
    float position_cm = -5.0f;
    uint32_t now_ms = 100u;
    uint16_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_DONE_HOLD;
    controller.result_flags = BALL_RESULT_PASS;
    controller.task_started = 1u;
    controller.task_start_ms = 10u;
    controller.dx_zero_px = 0;

    for (i = 0u; i < 12u; ++i) {
        BallController_OnMeasurement(&controller,
                                     position_to_dx(position_cm, 0), now_ms);
        now_ms += 20u;
    }
    CHECK(controller.quiet_active != 0u,
          "DONE_HOLD did not qualify QHLD before drift fixture");

    /* A genuine, slow median displacement is confirmed; one raw frame is no
     * longer sufficient.  Keep speed below the immediate safety threshold so
     * this fixture exercises the 200 ms position-hysteresis path. */
    for (i = 0u; i < 240u; ++i) {
        if (position_cm < -4.18f) {
            position_cm += 0.004f;
        }
        BallController_OnMeasurement(&controller,
                                     position_to_dx(position_cm, 0), now_ms);
        now_ms += 20u;
        if (controller.state == BALL_STATE_B_SETTLE) {
            break;
        }
    }
    CHECK(controller.state == BALL_STATE_B_SETTLE,
          "confirmed DONE_HOLD drift must re-enter B_SETTLE");
    CHECK(controller.state != BALL_STATE_DRIVE_A,
          "DONE_HOLD drift reran A");
    CHECK(absf_local(controller.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "confirmed recapture must hold centre for its first cycle");
    return 1;
}

static int test_11_servo_limits_under_arbitrary_input(void)
{
    BallController controller;
    uint32_t now_ms = 100u;
    uint32_t seed = 0x12345678u;
    uint16_t i;
    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.task_start_ms = now_ms;
    controller.dx_zero_px = 0;

    for (i = 0u; i < 2000u; ++i) {
        int16_t dx;
        seed = seed * 1664525u + 1013904223u;
        dx = (int16_t)(seed >> 16);
        now_ms += (uint32_t)(8u + (seed % 53u));
        BallController_OnMeasurement(&controller, dx, now_ms);
        CHECK(controller.servo_command_deg >= BALL_SERVO_HARD_MIN_DEG,
              "servo crossed hard minimum");
        CHECK(controller.servo_command_deg <= BALL_SERVO_HARD_MAX_DEG,
              "servo crossed hard maximum");
        CHECK(controller.servo_command_deg >= BALL_SERVO_AUTO_MIN_DEG,
              "automatic command crossed 50 degree limit");
    }
    return 1;
}

static int test_12_stage_timestamps_are_consistent(void)
{
    BallSimulation simulation;
    BallController timeout_controller;
    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&simulation, 4500u) != 0u,
          "timing simulation must complete");
    CHECK(simulation.observed_t_a_ms ==
          simulation.controller.diagnostics.t_a_ms,
          "tA does not match DRIVE_B transition time");
    CHECK(simulation.observed_t_b_ms ==
          simulation.controller.diagnostics.t_b_enter_ms,
          "tB_enter does not match BRAKE_B transition time");
    CHECK(simulation.observed_t_done_ms ==
          simulation.controller.diagnostics.t_done_ms,
          "tDone does not match DONE_HOLD transition time");
    CHECK(simulation.controller.diagnostics.t_a_ms <
          simulation.controller.diagnostics.t_b_enter_ms,
          "tA must precede tB_enter");
    CHECK(simulation.controller.diagnostics.t_b_enter_ms <
          simulation.controller.diagnostics.t_done_ms,
          "tB_enter must precede tDone");

    BallController_Init(&timeout_controller, 0u);
    timeout_controller.state = BALL_STATE_DRIVE_B;
    timeout_controller.task_started = 1u;
    timeout_controller.task_start_ms = 100u;
    timeout_controller.last_valid_ms = 5080u;
    timeout_controller.has_valid_measurement = 1u;
    timeout_controller.servo_command_deg = 55.0f;
    BallController_RequestTimeout(&timeout_controller, 5100u);
    CHECK(timeout_controller.state == BALL_STATE_TIMEOUT,
          "5.0 s event did not enter TIMEOUT");
    CHECK(timeout_controller.diagnostics.timeout_phase == BALL_STATE_DRIVE_B,
          "timeout phase was not recorded");
    CHECK((timeout_controller.result_flags & BALL_RESULT_TIMEOUT) != 0u,
          "timeout result flag missing");
    CHECK(absf_local(timeout_controller.servo_command_deg - 55.0f) < 0.01f,
          "timeout event changed servo without a new measurement");
    return 1;
}

static int test_13_oled_throttled_not_per_frame(void)
{
    BallUiThrottle ui;
    uint32_t now_ms;
    uint32_t refreshes = 0u;
    uint32_t last_refresh_ms = 0u;
    BallUiThrottle_Init(&ui, 0u);
    for (now_ms = 16u; now_ms < 1000u; now_ms += 16u) {
        BallUiThrottle_Request(&ui);
        if (BallUiThrottle_TakeRefresh(&ui, now_ms, 1u) != 0u) {
            if (last_refresh_ms != 0u) {
                CHECK((uint32_t)(now_ms - last_refresh_ms) >=
                      BALL_OLED_ACTIVE_PERIOD_MS,
                      "OLED refresh interval is below 250 ms");
            }
            last_refresh_ms = now_ms;
            refreshes++;
        }
    }
    CHECK(refreshes <= 4u, "OLED exceeded 4 Hz while every frame was dirty");
    CHECK(refreshes < 20u, "OLED still refreshes on visual frames");
    return 1;
}

static int test_14_log_and_sram_are_bounded(void)
{
    CHECK(BALL_LOG_CAPACITY <= 256u, "log capacity exceeds 256 records");
    CHECK(sizeof(BallLogRecord) <= 56u, "v3.2 diagnostic log record exceeds 56 bytes");
    CHECK(sizeof(BallController) <= 16384u,
          "controller/log object is too large for reasonable SRAM use");
    return 1;
}

static void host_uart_feed(const char *packet, uint32_t arrival_ms)
{
    uint16_t i;
    system_ms = arrival_ms;
    for (i = 0u; packet[i] != '\0'; ++i) {
        g_host_uart_rx_byte = (uint8_t)packet[i];
        Serial_INST_IRQHandler();
    }
}

static int test_15_uart_latest_timestamp_mailbox(void)
{
    char packet[100];
    uint32_t arrival_ms = 0u;
    uint32_t max_gap_ms = 0u;
    uint32_t time_ms;
    uint8_t i;

    system_ms = 0u;
    UART_ResetRxMailbox();
    for (i = 1u; i <= 8u; ++i) {
        char text[16];
        time_ms = (uint32_t)i * 17u;
        (void)sprintf(text, "@%u\r\n", (unsigned)i);
        host_uart_feed(text, time_ms);
    }
    CHECK(UART_RxOverwriteCount == 7u,
          "continuous frames were not retained as a latest-value mailbox");
    CHECK(UART_TakeLatestPacket(packet, sizeof(packet),
                                &arrival_ms, &max_gap_ms) != 0u,
          "latest UART packet was not available");
    CHECK(strcmp(packet, "8") == 0,
          "mailbox did not return the newest packet after foreground stall");
    CHECK(arrival_ms == 136u,
          "UART packet timestamp was not captured at ISR arrival");
    CHECK(max_gap_ms == 17u,
          "continuous 57 FPS stream was falsely reported as a long gap");

    system_ms = 0u;
    UART_ResetRxMailbox();
    host_uart_feed("@1\r\n", 10u);
    CHECK(UART_TakeLatestPacket(packet, sizeof(packet),
                                &arrival_ms, &max_gap_ms) != 0u,
          "first packet after reset missing");
    host_uart_feed("@2\r\n", 110u);
    CHECK(UART_TakeLatestPacket(packet, sizeof(packet),
                                &arrival_ms, &max_gap_ms) != 0u,
          "packet after true outage missing");
    CHECK(max_gap_ms == 100u,
          "a real 100 ms visual outage was not preserved");

    system_ms = 0u;
    UART_ResetRxMailbox();
    host_uart_feed("@123", 10u);
    host_uart_feed("@-7\r\n", 27u);
    CHECK(UART_TakeLatestPacket(packet, sizeof(packet),
                                &arrival_ms, &max_gap_ms) != 0u,
          "UART parser did not resynchronize at a new header");
    CHECK(strcmp(packet, "-7") == 0,
          "resynchronized UART payload is incorrect");
    return 1;
}

static int test_16_oled_refresh_is_paged(void)
{
    uint8_t page;
    g_host_i2c_transfer_count = 0u;
    OLED_ClearBuffer();
    OLED_RefreshBegin();
    CHECK(OLED_RefreshBusy() != 0u,
          "paged OLED refresh did not start");

    for (page = 0u; page < 8u; ++page) {
        uint32_t before = g_host_i2c_transfer_count;
        uint8_t complete = OLED_RefreshStep();
        CHECK((g_host_i2c_transfer_count - before) == 131u,
              "one OLED service step must transfer exactly one page");
        if (page < 7u) {
            CHECK(complete == 0u,
                  "OLED refresh completed before all eight pages");
        } else {
            CHECK(complete != 0u,
                  "OLED refresh did not complete on page eight");
        }
    }
    CHECK(OLED_RefreshBusy() == 0u,
          "OLED refresh remained busy after page eight");
    CHECK(g_host_i2c_transfer_count == 1048u,
          "paged full-screen transfer count changed unexpectedly");
    return 1;
}

static int test_17_k1_latches_until_prequalified_ready(void)
{
    BallController controller;
    uint32_t now_ms = 0u;
    uint8_t i;

    BallController_Init(&controller, 0u);
    BallController_RequestStart(&controller, now_ms);
    CHECK(controller.state == BALL_STATE_WAIT_CENTER,
          "early K1 must hold WAIT_CENTER");
    CHECK(controller.task_started == 0u,
          "early K1 must not start the competition timer");
    CHECK(BallController_IsArmed(&controller) != 0u,
          "early K1 was not latched");

    for (i = 0u; i < (BALL_CENTER_SAMPLE_COUNT - 1u); ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller, 0, now_ms);
    }
    CHECK(BallController_IsReady(&controller) == 0u,
          "RDY asserted before all 31 samples arrived");
    now_ms += 20u;
    BallController_OnMeasurement(&controller, 0, now_ms);
    CHECK(controller.state == BALL_STATE_DRIVE_A,
          "latched K1 did not auto-start on the 31st stable frame");
    CHECK(BallController_IsArmed(&controller) == 0u,
          "start latch was not consumed at DRIVE_A entry");
    CHECK(controller.task_start_ms == now_ms,
          "task timer includes the pre-start ready wait");
    CHECK((controller.servo_command_deg >= 115.0f) &&
          (controller.servo_command_deg <= 120.0f),
          "six-PID DRIVE_A command is outside the permitted start range");
    return 1;
}

static int test_18_a_capture_watchdog_never_sticks(void)
{
    BallController controller;
    uint32_t now_ms = 100u;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_A_CAPTURE;
    controller.task_started = 1u;
    controller.task_start_ms = 0u;
    controller.stage_start_ms = now_ms;
    controller.dx_zero_px = 0;
    controller.a_peak_cm = 5.0f;
    controller.a_peak_valid = 1u;

    while ((controller.state == BALL_STATE_A_CAPTURE) &&
           (now_ms <= 440u)) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(5.0f, 0), now_ms);
    }
    CHECK(controller.state == BALL_STATE_DRIVE_B,
          "A_CAPTURE remained active beyond its 300 ms watchdog");
    CHECK(controller.diagnostics.a_capture_timed_out != 0u,
          "A_CAPTURE watchdog reason was not recorded");
    CHECK(controller.diagnostics.a_transition_reason ==
          BALL_TRANSITION_A_CAPTURE_TIMEOUT,
          "A_CAPTURE watchdog transition reason is incorrect");
    CHECK(controller.servo_command_deg < BALL_SERVO_CENTER_DEG,
          "A watchdog recovery did not continue directly toward B");
    return 1;
}

static int test_19_b_overshoot_damping_never_adds_outward_energy(void)
{
    BallController controller;
    uint32_t now_ms = 100u;
    float offset;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.task_start_ms = 0u;
    controller.dx_zero_px = 0;
    controller.b_min_cm = -5.70f;
    controller.b_last_side = -1;
    controller.b_side_valid = 1u;

    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.70f, 0), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.86f, 0), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-6.02f, 0), now_ms);

    offset = controller.servo_command_deg - BALL_SERVO_CENTER_DEG;
    CHECK(controller.velocity_cm_s < -0.7f,
          "overshoot fixture did not establish outward velocity");
    CHECK(offset >= BALL_SETTLE_DAMP_BASE_DEG - 0.1f,
          "B overshoot control injected energy in the outward direction");
    CHECK(offset <= BALL_SETTLE_DAMP_MAX_DEG + 0.1f,
          "velocity brake exceeded the 28 degree damping limit");
    CHECK(controller.settle_mode == BALL_SETTLE_DAMP,
          "moving B overshoot was not handled by damping mode");
    return 1;
}

static int test_20_brake_b_rebound_releases_filtered_lag(void)
{
    BallController controller;
    BallEstimate estimate;
    uint32_t now_ms = 0u;
    uint8_t i;
    static const float approach_cm[] = {-4.0f, -4.3f, -4.6f, -4.9f, -5.2f};

    BallController_Init(&controller, 0u);
    for (i = 0u; i < 5u; ++i) {
        now_ms += 20u;
        BallEstimator_Add(&controller.estimator, approach_cm[i], now_ms,
                          &estimate);
    }
    controller.state = BALL_STATE_BRAKE_B;
    controller.task_started = 1u;
    controller.task_start_ms = 0u;
    controller.dx_zero_px = 0;
    controller.position_cm = -5.2f;
    controller.last_position_cm = -5.2f;
    controller.last_position_ms = now_ms;
    controller.has_last_position = 1u;
    controller.adjacent_velocity_cm_s = -15.0f;
    controller.has_adjacent_velocity = 1u;
    controller.b_min_cm = -5.2f;
    controller.b_last_side = -1;
    controller.b_side_valid = 1u;

    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.50f, 0), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.80f, 0), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.71f, 0), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.62f, 0), now_ms);

    CHECK(controller.state == BALL_STATE_B_SETTLE,
          "two-frame rebound did not release BRAKE_B");
    CHECK(controller.diagnostics.b_release_reason == BALL_TRANSITION_B_REBOUND,
          "filtered-lag release did not record the rebound reason");
    CHECK(controller.servo_command_deg < 113.0f - 0.1f,
          "strong 113 degree brake persisted after confirmed rebound");
    return 1;
}

static int test_21_sixty_ms_pulse_can_end_early(void)
{
    BallController controller;
    uint32_t now_ms = 100u;
    uint8_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.task_start_ms = 0u;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 3u; ++i) {
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.0f, 0), now_ms);
        now_ms += 20u;
    }
    CHECK(controller.pulse_phase == BALL_PULSE_ACTIVE,
          "near-static B error did not start a correction pulse");
    CHECK(absf_local(controller.servo_command_deg - BALL_SERVO_CENTER_DEG) >= 19.9f,
          "default correction pulse fell below 20 degrees");

    BallController_OnMeasurement(&controller,
                                 position_to_dx(-4.04f, 0), now_ms);
    CHECK(controller.pulse_phase != BALL_PULSE_ACTIVE,
          "pulse did not terminate early after motion reached 0.7 cm/s");
    CHECK((uint32_t)(now_ms - controller.pulse_phase_start_ms) <
          BALL_PULSE_ACTIVE_MS,
          "early-termination fixture accidentally ran a full pulse");
    CHECK(absf_local(controller.servo_command_deg - BALL_SERVO_CENTER_DEG) < 0.1f,
          "toward-target motion inside +/-1 cm should coast after pulse release");
    return 1;
}

static int test_22_log_covers_ten_seconds_at_40_ms(void)
{
    BallController controller;
    BallLogRecord first;
    BallLogRecord last;
    uint32_t now_ms;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_DONE_HOLD;
    controller.task_started = 1u;
    controller.task_start_ms = 0u;
    controller.dx_zero_px = 0;
    for (now_ms = 20u; now_ms <= 10600u; now_ms += 20u) {
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-5.0f, 0), now_ms);
    }
    CHECK(BallController_LogCount(&controller) == BALL_LOG_CAPACITY,
          "10.6 s run did not fill the bounded ring log");
    CHECK(BallController_GetLog(&controller, 0u, &first) != 0u,
          "oldest log record is unavailable");
    CHECK(BallController_GetLog(&controller,
          (uint16_t)(BALL_LOG_CAPACITY - 1u), &last) != 0u,
          "newest log record is unavailable");
    CHECK((uint32_t)(last.time_ms - first.time_ms) >= 10000u,
          "40 ms ring log does not retain about 10.2 seconds");
    CHECK((last.detail & 0x0Fu) <= BALL_SETTLE_QUIET_RECAPTURE,
          "log detail does not contain a valid B settle submode");
    CHECK(last.pid_update_mask == 0x3Fu,
          "ring log does not prove six-lane parallel execution");
    CHECK(last.pid_dominant < BALL_PID_COUNT,
          "ring log contains an invalid dominant PID index");
    return 1;
}

static int test_23_servo_lag_correlated_noise_combination(void)
{
    BallSimulation simulation;
    uint8_t completed;

    /* Test 07 covers 40 ms lag with raw +/-5 px noise.  This scenario combines
     * one-cycle actuator lag, post-filter correlated residual noise and
     * intermittent frame loss. */
    simulation_init(&simulation, 15.0f, 0u, 3u, 1u);
    simulation.servo_lag_enabled = 1u;
    completed = simulation_run(&simulation, BALL_BUDGET_DONE_MS);
    printf("    combined state=%s t=%lu tA=%lu tB=%lu band=%lu bset=%lu hold=%u/%lu tDone=%lu over=%.2f cross=%u x=%.2f v=%.2f estV=%.2f mode=%s\n",
           BallController_StateShort(simulation.controller.state),
           (unsigned long)BallController_TaskElapsedMs(&simulation.controller,
                                                        simulation.now_ms),
           (unsigned long)simulation.controller.diagnostics.t_a_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_enter_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_band_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_settle_ms,
           (unsigned)simulation.controller.settle_hold_active,
           (unsigned long)simulation.controller.settle_hold_start_ms,
           (unsigned long)simulation.controller.diagnostics.t_done_ms,
           (double)simulation.controller.diagnostics.b_first_overshoot_cm,
           (unsigned)simulation.controller.diagnostics.b_cross_count,
           (double)simulation.x_cm,
           (double)simulation.velocity_cm_s,
           (double)simulation.controller.velocity_cm_s,
           BallController_SettleModeShort(simulation.controller.settle_mode));
    CHECK(completed != 0u,
          "servo lag/correlated-noise/drop model did not complete by 4.5 s");
    CHECK(simulation.controller.diagnostics.t_done_ms <= BALL_BUDGET_DONE_MS,
          "combined disturbance model missed the 4.5 s software target");
    CHECK(simulation.controller.diagnostics.b_first_overshoot_cm <= 0.80f,
          "combined disturbance first B overshoot exceeds 0.8 cm");
    CHECK(simulation.controller.diagnostics.b_cross_count <= 4u,
          "combined disturbance caused sustained B crossings");
    return 1;
}

static int test_24_six_pid_lanes_update_and_fuse(void)
{
    BallPidBank bank;
    float weight_sum = 0.0f;
    float raw_sum = 0.0f;
    uint8_t i;

    BallPidBank_Init(&bank);
    BallPidBank_Update(&bank, 0.0f, -5.0f, 0.0f, 20u, 0u);
    CHECK(bank.update_mask == 0x3Fu,
          "one valid update did not execute all six PID lanes");
    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        CHECK(bank.lane[i].update_count == 1u,
              "parallel PID update counters differ");
        weight_sum += bank.lane[i].weight;
        raw_sum += bank.lane[i].output_deg;
    }
    CHECK(absf_local(weight_sum - 1.0f) < 0.0001f,
          "six PID weights are not normalized");
    CHECK(absf_local(bank.fused_output_deg) <= BALL_PID_FUSED_MAX_DEG,
          "fused PID output exceeds its physical bound");
    CHECK(absf_local(raw_sum) > absf_local(bank.fused_output_deg) * 3.0f,
          "fusion appears to be an unsafe direct sum");
    return 1;
}

static int test_25_pid_region_crossfades_are_continuous(void)
{
    static const float boundaries_cm[5] = {
        0.17f, 0.50f, 1.00f, 1.67f, 2.67f
    };
    BallPidBank bank;
    uint32_t now_ms = 20u;
    uint8_t boundary;

    BallPidBank_Init(&bank);
    for (boundary = 0u; boundary < 5u; ++boundary) {
        float left_output;
        float right_output;
        float weight_sum = 0.0f;
        uint8_t i;

        BallPidBank_Update(&bank, 0.0f,
                           -(boundaries_cm[boundary] - 0.001f),
                           0.0f, now_ms, 0u);
        left_output = bank.fused_output_deg;
        now_ms += 20u;
        BallPidBank_Update(&bank, 0.0f,
                           -(boundaries_cm[boundary] + 0.001f),
                           0.0f, now_ms, 0u);
        right_output = bank.fused_output_deg;
        for (i = 0u; i < BALL_PID_COUNT; ++i) {
            weight_sum += bank.lane[i].weight;
        }
        CHECK(absf_local(weight_sum - 1.0f) < 0.0001f,
              "crossfade weights are not normalized");
        CHECK(absf_local(right_output - left_output) < 0.20f,
              "PID region boundary causes an output discontinuity");
        CHECK(bank.update_mask == 0x3Fu,
              "a crossfade update skipped a PID lane");
        now_ms += 20u;
    }
    return 1;
}

static int test_26_pid_true_dt_integral_and_reset(void)
{
    BallPidBank bank;
    uint32_t count_before_reset;
    uint8_t i;

    BallPidBank_Init(&bank);
    BallPidBank_Update(&bank, 0.0f, -0.10f, 0.0f, 20u, 1u);
    BallPidBank_Update(&bank, 0.0f, -0.10f, 0.0f, 40u, 1u);
    CHECK(absf_local(bank.lane[0].integral_cm_s - 0.002f) < 0.0001f,
          "PID integral is not scaled by true 20 ms dt");
    BallPidBank_Update(&bank, 0.0f, -0.10f, 0.0f, 101u, 1u);
    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        CHECK(absf_local(bank.lane[i].integral_cm_s) < 0.0001f,
              "61 ms measurement gap did not clear PID integral history");
    }
    count_before_reset = bank.lane[0].update_count;
    BallPidBank_ResetDynamics(&bank);
    CHECK(bank.lane[0].update_count == count_before_reset,
          "dynamic reset destroyed parallel execution diagnostics");
    CHECK(bank.update_mask == 0u,
          "dynamic reset left a stale PID update mask");
    return 1;
}

static void prepare_drive_b_controller(BallController *controller,
                                       float position_cm,
                                       uint32_t now_ms)
{
    BallEstimate estimate;

    BallController_Init(controller, 0u);
    controller->state = BALL_STATE_DRIVE_B;
    controller->task_started = 1u;
    controller->task_start_ms = 0u;
    controller->stage_start_ms = now_ms;
    controller->dx_zero_px = 0;
    controller->position_cm = position_cm;
    controller->last_position_cm = position_cm;
    controller->last_position_ms = now_ms;
    controller->has_last_position = 1u;
    controller->last_valid_ms = now_ms;
    controller->has_valid_measurement = 1u;
    controller->drive_reference_cm = position_cm;
    controller->b_min_cm = position_cm;
    controller->diagnostics.b_min_cm = position_cm;
    BallEstimator_Reset(&controller->estimator);
    BallEstimator_Add(&controller->estimator, position_cm, now_ms, &estimate);
    BallFastEstimator_Seed(&controller->fast_estimator,
                           position_cm, now_ms);
    BallPidBank_Reset(&controller->pid_bank);
    BallPidBank_Update(&controller->pid_bank, BALL_TARGET_B_CM,
                       position_cm, 0.0f, now_ms, 0u);
}

static int test_27_fast_estimator_true_time_and_gap_reset(void)
{
    BallFastEstimator estimator;
    BallFastEstimate estimate;

    BallFastEstimator_Init(&estimator);
    BallFastEstimator_Seed(&estimator, 0.0f, 0u);
    BallFastEstimator_Add(&estimator, -0.20f, 20u, &estimate);
    CHECK(estimate.velocity_valid == 0u,
          "fast estimator became valid before three samples");
    BallFastEstimator_Add(&estimator, -0.40f, 40u, &estimate);
    CHECK(estimate.velocity_valid != 0u,
          "three-point fast estimator did not become valid");
    CHECK(absf_local(estimate.velocity_cm_s + 10.0f) < 0.02f,
          "three-point fast estimator has incorrect cm/s units");
    BallFastEstimator_Add(&estimator, -0.61f, 61u, &estimate);
    CHECK(estimate.velocity_cm_s <= -9.8f,
          "alpha=0.65 fast filter did not follow a constant slope");
    BallFastEstimator_Add(&estimator, -1.22f, 122u, &estimate);
    CHECK(estimate.gap_reset != 0u,
          "61 ms interval did not reset the fast estimator");
    CHECK(estimate.velocity_valid == 0u,
          "fast velocity remained valid after a 61 ms reset");
    CHECK(estimator.count == 1u,
          "gap reset did not reseed with the current sample");
    return 1;
}

static int test_28_origin_k230_filter_is_in_closed_loop(void)
{
    BallSimulation filter;
    BallSimulation closed_loop;
    int16_t first;
    int16_t second;
    uint8_t i;

    memset(&filter, 0, sizeof(filter));
    first = simulation_measurement_dx(&filter,
        -100.0f / BALL_PX_PER_CM, 20u);
    second = simulation_measurement_dx(&filter,
        -100.0f / BALL_PX_PER_CM, 20u);
    CHECK(first == 30, "first K230 0.3 step output is incorrect");
    CHECK(second == 51, "second K230 fixed 0.7/0.3 output is incorrect");

    memset(&filter, 0, sizeof(filter));
    for (i = 0u; i < 9u; ++i) {
        CHECK(simulation_measurement_dx(&filter,
            -350.0f / BALL_PX_PER_CM, 20u) == 0,
            "300 px jump gate accepted before ten frames");
    }
    CHECK(simulation_measurement_dx(&filter,
        -350.0f / BALL_PX_PER_CM, 20u) == 350,
        "ten-frame stable jump was not accepted");

    simulation_init(&closed_loop, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&closed_loop, BALL_BUDGET_DONE_MS) != 0u,
          "closed loop with the origin K230 filter did not complete");
    CHECK(absf_local(closed_loop.k230_filtered_px) > 1.0f,
          "closed-loop K230 filter state was never exercised");
    return 1;
}

static int test_29_fast_velocity_leads_slow_velocity(void)
{
    BallEstimator slow;
    BallFastEstimator fast;
    BallEstimate slow_estimate;
    BallFastEstimate fast_estimate;
    BallSimulation vision;
    uint8_t slow_cross = 0u;
    uint8_t fast_cross = 0u;
    uint8_t i;

    BallEstimator_Init(&slow);
    BallFastEstimator_Init(&fast);
    memset(&vision, 0, sizeof(vision));
    for (i = 1u; i <= 50u; ++i) {
        uint32_t time_ms = (uint32_t)i * 20u;
        float time_s = (float)time_ms * 0.001f;
        float true_position_cm = -0.5f * 32.0f * time_s * time_s;
        int16_t dx_px;
        float measured_cm;

        vision.tick = i;
        dx_px = simulation_measurement_dx(&vision, true_position_cm, 20u);
        measured_cm = -(float)dx_px / BALL_PX_PER_CM;
        BallEstimator_Add(&slow, measured_cm, time_ms, &slow_estimate);
        BallFastEstimator_Add(&fast, measured_cm, time_ms, &fast_estimate);
        if ((fast_cross == 0u) && (fast_estimate.velocity_valid != 0u) &&
            (fast_estimate.velocity_cm_s <=
             -BALL_B_APPROACH_HIGH_SPEED_CM_S)) {
            fast_cross = i;
        }
        if ((slow_cross == 0u) && (slow_estimate.velocity_valid != 0u) &&
            (slow_estimate.velocity_cm_s <=
             -BALL_B_APPROACH_HIGH_SPEED_CM_S)) {
            slow_cross = i;
        }
    }
    CHECK((fast_cross != 0u) && (slow_cross != 0u),
          "acceleration fixture never crossed the high-speed threshold");
    CHECK((uint8_t)(fast_cross + 1u) <= slow_cross,
          "v_fast did not lead v_slow by at least one valid cycle");
    return 1;
}

static int test_30_approach_requires_two_frames(void)
{
    BallController single;
    BallController confirmed;

    prepare_drive_b_controller(&single, 0.0f, 0u);
    BallController_OnMeasurement(&single, position_to_dx(-0.60f, 0), 20u);
    CHECK(single.state == BALL_STATE_DRIVE_B,
          "one velocity spike switched out of DRIVE_B");
    CHECK(single.b_approach_confirm_frames == 1u,
          "one approach candidate was not counted exactly once");

    prepare_drive_b_controller(&confirmed, 0.0f, 0u);
    BallController_OnMeasurement(&confirmed,
                                 position_to_dx(-0.60f, 0), 20u);
    BallController_OnMeasurement(&confirmed,
                                 position_to_dx(-1.20f, 0), 40u);
    CHECK(confirmed.state != BALL_STATE_DRIVE_B,
          "two consecutive high-speed frames did not enter B approach/brake");
    CHECK(confirmed.diagnostics.t_b_approach_ms == 40u,
          "B_APPROACH timestamp was not captured on the confirmed frame");
    return 1;
}

static int test_31_bapproach_log_precedes_hard_brake(void)
{
    BallSimulation simulation;
    BallController direct;
    uint16_t approach_index = 0xFFFFu;
    uint16_t brake_index = 0xFFFFu;
    uint16_t i;

    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&simulation, BALL_BUDGET_DONE_MS) != 0u,
          "nominal trace did not complete for BAPR ordering test");
    for (i = 0u; i < BallController_LogCount(&simulation.controller); ++i) {
        BallLogRecord record;
        CHECK(BallController_GetLog(&simulation.controller, i, &record) != 0u,
              "failed to read chronological log record");
        if ((approach_index == 0xFFFFu) &&
            (record.state == (uint8_t)BALL_STATE_B_APPROACH)) {
            approach_index = i;
        }
        if ((brake_index == 0xFFFFu) &&
            (record.state == (uint8_t)BALL_STATE_BRAKE_B)) {
            brake_index = i;
        }
    }
    CHECK((approach_index != 0xFFFFu) && (brake_index != 0xFFFFu),
          "BAPR or BRKB state-change record is missing");
    CHECK(approach_index < brake_index,
          "BAPR record does not precede BRKB");

    prepare_drive_b_controller(&direct, -3.60f, 0u);
    direct.state = BALL_STATE_B_APPROACH;
    direct.diagnostics.t_b_approach_ms = 1u;
    BallController_OnMeasurement(&direct,
                                 position_to_dx(-4.00f, 0), 20u);
    CHECK(direct.state == BALL_STATE_BRAKE_B,
          "same-cycle hard predicate did not enter BRAKE_B");
    CHECK(direct.servo_command_deg >= 112.9f,
          "same-cycle hard predicate did not finish at 113 degrees");
    return 1;
}

static int test_32_v32_brakes_before_frozen_v31_predicate(void)
{
    BallController controller;
    BallSimulation vision;
    uint32_t baseline_time_ms = 0u;
    float baseline_position_cm = 0.0f;
    uint8_t i;

    prepare_drive_b_controller(&controller, 5.0f, 0u);
    memset(&vision, 0, sizeof(vision));
    vision.k230_filtered_px = -5.0f * BALL_PX_PER_CM;
    for (i = 1u; i <= 70u; ++i) {
        uint32_t time_ms = (uint32_t)i * 20u;
        float time_s = (float)time_ms * 0.001f;
        float true_position_cm = 5.0f - 0.5f * 30.0f * time_s * time_s;
        int16_t dx_px;

        vision.tick = i;
        dx_px = simulation_measurement_dx(&vision, true_position_cm, 20u);
        BallController_OnMeasurement(&controller, dx_px, time_ms);
        if ((baseline_time_ms == 0u) &&
            ((controller.position_cm + BALL_BRAKE_B_LEAD_S *
              ((controller.velocity_cm_s < 0.0f) ?
               controller.velocity_cm_s : 0.0f)) <=
             BALL_BRAKE_B_TRIGGER_CM)) {
            baseline_time_ms = time_ms;
            baseline_position_cm = controller.position_cm;
        }
    }
    CHECK(controller.diagnostics.t_b_brake_ms != 0u,
          "v3.2 trace never issued the 113 degree brake");
    CHECK(baseline_time_ms != 0u,
          "frozen v3.1 phase predicate never fired on the same trace");
    CHECK((baseline_time_ms >= controller.diagnostics.t_b_brake_ms) &&
          (((baseline_time_ms - controller.diagnostics.t_b_brake_ms) >= 80u) ||
           ((controller.diagnostics.b_brake_start_cm -
             baseline_position_cm) >= 0.50f)),
          "v3.2 did not lead v3.1 by 80 ms or 0.5 cm");
    return 1;
}

static int test_33_brake_b_cannot_be_weakened_by_pid(void)
{
    BallController controller;
    uint32_t counts_before[BALL_PID_COUNT];
    uint8_t i;

    prepare_drive_b_controller(&controller, -4.00f, 0u);
    controller.state = BALL_STATE_BRAKE_B;
    controller.diagnostics.t_b_brake_ms = 1u;
    controller.diagnostics.t_b_enter_ms = 1u;
    controller.diagnostics.b_brake_reason = BALL_BRAKE_REASON_STOP_DISTANCE;
    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        counts_before[i] = controller.pid_bank.lane[i].update_count;
    }
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-4.00f, 0), 20u);
    CHECK(controller.state == BALL_STATE_BRAKE_B,
          "fixture did not reach BRAKE_B");
    CHECK(controller.pid_bank.fused_output_deg < 0.0f,
          "fixture did not produce the adverse negative PID trim");
    CHECK(controller.servo_command_deg >= 112.9f,
          "negative fused PID weakened the +28 degree brake");
    CHECK(controller.pid_bank.update_mask == 0x3Fu,
          "BRAKE_B measurement did not update all six PID lanes");
    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        CHECK(controller.pid_bank.lane[i].update_count ==
              counts_before[i] + 1u,
              "a PID lane skipped the BRAKE_B measurement");
    }
    return 1;
}

static int test_34_nominal_v32_metrics(void)
{
    BallSimulation simulation;
    float final_error_cm;

    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&simulation, BALL_BUDGET_DONE_MS) != 0u,
          "nominal v3.2 metric trace did not complete");
    final_error_cm = absf_local(simulation.x_cm - BALL_TARGET_B_CM);
    printf("    v32_metrics tA=%lu tB_approach=%lu tB_brake=%lu "
           "tB_band=%lu vB=%.2f tDone=%lu over=%.2f cross=%u err=%.2f\n",
           (unsigned long)simulation.controller.diagnostics.t_a_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_approach_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_brake_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_band_ms,
           (double)simulation.controller.diagnostics.b_band_entry_velocity_cm_s,
           (unsigned long)simulation.controller.diagnostics.t_done_ms,
           (double)simulation.controller.diagnostics.b_first_overshoot_cm,
           (unsigned)simulation.controller.diagnostics.b_cross_count,
           (double)final_error_cm);
    CHECK(simulation.controller.diagnostics.t_b_approach_ms <=
          BALL_BUDGET_B_APPROACH_MS,
          "B_APPROACH missed the 2.8 s budget");
    CHECK(simulation.controller.diagnostics.t_b_brake_ms <=
          BALL_BUDGET_B_BRAKE_MS,
          "BRAKE_B missed the 3.2 s budget");
    CHECK(simulation.controller.diagnostics.t_b_band_ms <=
          BALL_BUDGET_B_BAND_MS,
          "first B band entry missed the 3.8 s budget");
    CHECK(absf_local(simulation.controller.diagnostics.
                     b_band_entry_velocity_cm_s) <=
          BALL_B_FIRST_BAND_SPEED_TARGET_CM_S,
          "first B band entry speed exceeds 1.5 cm/s");
    CHECK(simulation.controller.diagnostics.b_first_overshoot_cm <=
          BALL_B_FIRST_OVERSHOOT_TARGET_CM,
          "first B overshoot exceeds 0.6 cm");
    CHECK(simulation.controller.diagnostics.b_cross_count <=
          BALL_B_CROSS_COUNT_TARGET,
          "B crossing count exceeds two");
    CHECK((simulation.controller.diagnostics.t_done_ms -
           simulation.controller.diagnostics.t_b_band_ms) <=
          BALL_B_BAND_TO_DONE_TARGET_MS,
          "nominal B band-to-done time exceeds 0.7 s");
    CHECK(final_error_cm <= BALL_DONE_POSITION_TOL_CM,
          "nominal final physical position is outside +/-0.6 cm");
    return 1;
}

static int test_35_joint_lag_noise_deadzone_and_servo_delay(void)
{
    BallSimulation simulation;
    uint8_t completed;

    simulation_init(&simulation, 15.0f, 2u, 3u, 1u);
    simulation.servo_lag_enabled = 1u;
    completed = simulation_run(&simulation, BALL_BUDGET_DONE_MS);
    printf("    joint_metrics tA=%lu tApr=%lu tBrk=%lu tSet=%lu tBand=%lu "
           "vB=%.2f tDone=%lu over=%.2f cross=%u reason=%u xBrk=%.2f "
           "state=%s t=%lu x=%.2f v=%.2f mx=%.2f mv=%.2f adj=%.2f "
           "qerr=%.2f qspread=%.2f "
           "qmode=%u qactive=%u\n",
           (unsigned long)simulation.controller.diagnostics.t_a_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_approach_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_brake_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_settle_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_band_ms,
           (double)simulation.controller.diagnostics.b_band_entry_velocity_cm_s,
           (unsigned long)simulation.controller.diagnostics.t_done_ms,
           (double)simulation.controller.diagnostics.b_first_overshoot_cm,
           (unsigned)simulation.controller.diagnostics.b_cross_count,
           (unsigned)simulation.controller.diagnostics.b_brake_reason,
           (double)simulation.controller.diagnostics.b_brake_start_cm,
           BallController_StateShort(simulation.controller.state),
           (unsigned long)BallController_TaskElapsedMs(&simulation.controller,
                                                        simulation.now_ms),
           (double)simulation.x_cm,
           (double)simulation.velocity_cm_s,
           (double)simulation.controller.position_cm,
           (double)simulation.controller.velocity_cm_s,
           (double)simulation.controller.adjacent_velocity_cm_s,
           (double)simulation.controller.quiet_error_cm,
           (double)simulation.controller.quiet_spread_cm,
           (unsigned)simulation.controller.settle_mode,
           (unsigned)simulation.controller.quiet_active);
    CHECK(completed != 0u,
          "joint K230/40 ms/servo/noise/drop model missed 4.5 s");
    CHECK(simulation.controller.diagnostics.t_done_ms <=
          BALL_BUDGET_DONE_MS,
          "joint disturbance tDone exceeds 4.5 s");
    CHECK(absf_local(simulation.controller.diagnostics.
                     b_band_entry_velocity_cm_s) <=
          BALL_B_FIRST_BAND_SPEED_TARGET_CM_S,
          "joint disturbance enters the B band above 1.5 cm/s");
    CHECK(simulation.controller.diagnostics.b_first_overshoot_cm <=
          BALL_B_FIRST_OVERSHOOT_TARGET_CM,
          "joint disturbance first overshoot exceeds 0.6 cm");
    CHECK(simulation.controller.diagnostics.b_cross_count <=
          BALL_B_CROSS_COUNT_TARGET,
          "joint disturbance crosses B more than twice");
    return 1;
}

static int test_36_fast_gap_reset_does_not_stall_state_machine(void)
{
    BallController controller;

    prepare_drive_b_controller(&controller, 0.0f, 0u);
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-0.10f, 0), 20u);
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-0.20f, 0), 40u);
    CHECK(controller.velocity_fast_valid != 0u,
          "fast estimator was not valid before gap fixture");
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-0.30f, 0), 101u);
    CHECK(controller.velocity_fast_valid == 0u,
          "61 ms gap did not invalidate v_fast");
    CHECK(controller.state == BALL_STATE_DRIVE_B,
          "61 ms gap stalled or faulted the B state machine");
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-0.40f, 0), 121u);
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-0.50f, 0), 141u);
    CHECK(controller.velocity_fast_valid != 0u,
          "fast estimator did not recover after reseeding");
    CHECK(controller.servo_command_deg >= BALL_SERVO_AUTO_MIN_DEG &&
          controller.servo_command_deg <= BALL_SERVO_AUTO_MAX_DEG,
          "gap recovery produced an unsafe servo command");
    return 1;
}

static int test_37_extended_log_fields_and_state_ids(void)
{
    BallSimulation simulation;
    uint16_t i;
    uint8_t found_approach = 0u;
    uint8_t found_brake = 0u;

    CHECK(BALL_STATE_TIMEOUT == 11,
          "legacy state ID 11 no longer maps to TIMEOUT");
    CHECK(BALL_STATE_B_APPROACH == 12,
          "B_APPROACH was not appended as state 12");
    CHECK(sizeof(BallLogRecord) <= 56u,
          "extended log record exceeds the 56-byte cap");
    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    CHECK(simulation_run(&simulation, BALL_BUDGET_DONE_MS) != 0u,
          "log-field fixture did not complete");
    for (i = 0u; i < BallController_LogCount(&simulation.controller); ++i) {
        BallLogRecord record;
        CHECK(BallController_GetLog(&simulation.controller, i, &record) != 0u,
              "could not read extended log record");
        if (record.state == (uint8_t)BALL_STATE_B_APPROACH) {
            found_approach = 1u;
            CHECK(record.approach_reason != BALL_APPROACH_REASON_NONE,
                  "BAPR log did not capture its entry reason");
            CHECK(record.pid_update_mask == 0x3Fu,
                  "BAPR log does not show all six PID updates");
        }
        if (record.state == (uint8_t)BALL_STATE_BRAKE_B) {
            found_brake = 1u;
            CHECK(record.brake_reason != BALL_BRAKE_REASON_NONE,
                  "BRKB log did not capture its entry reason");
            CHECK(record.servo10 >= 1130u,
                  "BRKB log contains a command below 113 degrees");
        }
    }
    CHECK((found_approach != 0u) && (found_brake != 0u),
          "extended log omitted BAPR or BRKB");
    return 1;
}

static int test_38_timeout_in_bapproach_keeps_b_control_alive(void)
{
    BallController controller;

    prepare_drive_b_controller(&controller, -3.5f, 0u);
    controller.state = BALL_STATE_B_APPROACH;
    controller.servo_command_deg = 63.0f;
    BallController_RequestTimeout(&controller, BALL_OFFICIAL_TIMEOUT_MS);
    CHECK(controller.state == BALL_STATE_TIMEOUT,
          "timeout in B_APPROACH did not record TIMEOUT");
    CHECK(controller.diagnostics.timeout_phase == BALL_STATE_B_APPROACH,
          "timeout did not record B_APPROACH as its phase");
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-4.0f, 0),
                                 BALL_OFFICIAL_TIMEOUT_MS + 20u);
    CHECK(controller.servo_command_deg >= BALL_SERVO_AUTO_MIN_DEG &&
          controller.servo_command_deg <= BALL_SERVO_AUTO_MAX_DEG,
          "post-timeout B control produced an unsafe command");
    CHECK(controller.state == BALL_STATE_TIMEOUT,
          "post-timeout stabilization erased TIMEOUT status");
    return 1;
}

static int test_39_qhld_stationary_k230_noise_is_silent(void)
{
    static const int8_t noise_px[] = {-5, 5, -5, 5, -5, 5, -5, 5};
    static const uint8_t dt_ms[] = {17u, 22u, 16u, 21u, 18u, 20u};
    BallController controller;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    uint16_t baseline_events = controller.diagnostics.servo_event_count;
    uint16_t noncenter_count = 0u;
    float filtered_px = -BALL_TARGET_B_CM * BALL_PX_PER_CM;
    uint32_t start_ms = now_ms;
    uint16_t i = 0u;

    CHECK(controller.state == BALL_STATE_DONE_HOLD,
          "stationary fixture did not reach DONE_HOLD");
    CHECK(controller.quiet_active != 0u,
          "DONE_HOLD did not establish QHLD");
    while ((uint32_t)(now_ms - start_ms) < 10000u) {
        uint32_t dt = dt_ms[i % (sizeof(dt_ms) / sizeof(dt_ms[0]))];
        int16_t dx;
        now_ms += dt;
        dx = k230_origin_filter_step(-5.0f,
            noise_px[i % (sizeof(noise_px) / sizeof(noise_px[0]))],
            &filtered_px);
        BallController_OnMeasurement(&controller, dx, now_ms);
        if (absf_local(controller.servo_command_deg -
                       BALL_SERVO_CENTER_DEG) > 0.1f) {
            noncenter_count++;
        }
        CHECK(controller.state == BALL_STATE_DONE_HOLD,
              "stationary K230 noise left DONE_HOLD");
        ++i;
    }
    printf("    qhld_noise_10s noncenter=%u new_events=%u exits=%u "
           "max1s=%u qerr100=%d\n",
           (unsigned)noncenter_count,
           (unsigned)(controller.diagnostics.servo_event_count -
                      baseline_events),
           (unsigned)controller.diagnostics.quiet_exit_count,
           (unsigned)controller.diagnostics.max_servo_events_in_1s,
           (int)(controller.quiet_error_cm * 100.0f));
    CHECK(noncenter_count == 0u,
          "QHLD issued a non-centre command under 10 s stationary noise");
    CHECK(controller.diagnostics.servo_event_count == baseline_events,
          "stationary QHLD noise created a servo event");
    CHECK(controller.diagnostics.quiet_exit_count == 0u,
          "stationary QHLD noise created a false drift exit");
    return 1;
}

static int test_40_one_two_position_spikes_stay_quiet(void)
{
    BallController controller;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    uint16_t exits_before = controller.diagnostics.quiet_exit_count;

    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, 5), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, 0), now_ms);
    CHECK(controller.state == BALL_STATE_DONE_HOLD,
          "one position spike left QHLD");

    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, -5), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, -5), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, 0), now_ms);
    CHECK(controller.state == BALL_STATE_DONE_HOLD,
          "two ordinary position spikes left QHLD");
    CHECK(controller.diagnostics.quiet_exit_count == exits_before,
          "position spikes incremented the quiet-exit counter");
    CHECK(absf_local(controller.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "position spikes moved the servo");

    now_ms += 61u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, 0), now_ms);
    CHECK(controller.quiet_observer.count == 1u,
          "61 ms interval did not reset and reseed the quiet observer");
    CHECK(controller.quiet_warmup_hold != 0u,
          "quiet gap reset did not enter centre-only warm-up");
    CHECK(controller.state == BALL_STATE_DONE_HOLD &&
          absf_local(controller.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "quiet gap reset did not safely hold DONE at centre");
    return 1;
}

static int test_41_one_two_velocity_spikes_do_not_recapture(void)
{
    BallController controller;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);

    /* These two positive slopes move from B toward O but do not satisfy the
     * three-frame confirmation.  They are not the separate beyond-B outward
     * prediction safety case covered by test 45. */
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-4.90f, 0), now_ms);
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-4.82f, 0), now_ms);
    CHECK(controller.state == BALL_STATE_DONE_HOLD,
          "two non-outward velocity spikes caused DONE recapture");
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, 0), now_ms);
    CHECK(controller.state == BALL_STATE_DONE_HOLD,
          "velocity-spike recovery left DONE_HOLD");
    CHECK(absf_local(controller.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "non-outward speed spikes moved the DONE servo");
    return 1;
}

static int test_42_correlated_centroid_drift_never_alternates_pulses(void)
{
    static const int8_t correlated_px[] = {-3, -3, -1, 1, 3, 3, 1, -1};
    BallController controller;
    float filtered_px = 4.35f * BALL_PX_PER_CM;
    uint32_t now_ms = 0u;
    int8_t last_direction = 0;
    uint16_t direction_changes = 0u;
    uint16_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 160u; ++i) {
        int16_t dx;
        int8_t direction = 0;
        now_ms += 20u;
        dx = k230_origin_filter_step(-4.35f,
            correlated_px[i % (sizeof(correlated_px) /
                                sizeof(correlated_px[0]))],
            &filtered_px);
        BallController_OnMeasurement(&controller, dx, now_ms);
        if (controller.quiet_active != 0u) {
            if (controller.servo_command_deg > BALL_SERVO_CENTER_DEG + 0.1f) {
                direction = 1;
            } else if (controller.servo_command_deg <
                       BALL_SERVO_CENTER_DEG - 0.1f) {
                direction = -1;
            }
            if ((direction != 0) && (last_direction != 0) &&
                (direction != last_direction)) {
                direction_changes++;
            }
            if (direction != 0) {
                last_direction = direction;
            }
        }
    }
    printf("    correlated_drift pulses=%u events=%u dir_changes=%u\n",
           (unsigned)controller.diagnostics.quiet_pulse_count,
           (unsigned)controller.diagnostics.servo_event_count,
           (unsigned)direction_changes);
    CHECK(direction_changes == 0u,
          "correlated centroid drift produced alternating pulse directions");
    return 1;
}

static int test_43_latest_raw_outside_done_band_never_passes(void)
{
    BallController controller;
    uint32_t now_ms = 0u;
    uint16_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 100u; ++i) {
        float position_cm = ((i % 5u) == 4u) ? -4.35f : -5.0f;
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(position_cm, 0), now_ms);
    }
    CHECK(controller.state != BALL_STATE_DONE_HOLD,
          "median observer falsely completed with raw out-of-band frames");
    CHECK(controller.diagnostics.t_done_ms == 0u,
          "out-of-band latest x falsely recorded tDone");
    CHECK((controller.result_flags & BALL_RESULT_PASS) == 0u,
          "out-of-band latest x falsely recorded PASS");
    return 1;
}

static int test_44_real_drift_recaptures_and_recovers_within_800ms(void)
{
    BallController controller;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    uint32_t recapture_ms = 0u;
    float position_cm = -5.0f;
    uint16_t i;

    for (i = 0u; i < 260u; ++i) {
        if (position_cm < -4.18f) {
            position_cm += 0.004f;
        }
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(position_cm, 0), now_ms);
        if (controller.state == BALL_STATE_B_SETTLE) {
            recapture_ms = now_ms;
            break;
        }
    }
    CHECK(recapture_ms != 0u,
          "sustained >0.8 cm drift was not confirmed");
    CHECK(absf_local(controller.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "drift recapture issued a pulse in its transition cycle");
    for (i = 0u; i < 40u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-5.0f, 0), now_ms);
        if (controller.state == BALL_STATE_DONE_HOLD) {
            break;
        }
    }
    CHECK(controller.state == BALL_STATE_DONE_HOLD,
          "B-only recapture did not recover within 0.8 s");
    CHECK((uint32_t)(now_ms - recapture_ms) <= 800u,
          "drift recovery exceeded 0.8 s");
    CHECK(controller.diagnostics.quiet_exit_count == 1u,
          "confirmed drift did not record exactly one quiet exit");
    return 1;
}

static int test_45_outward_motion_still_gets_energy_brake(void)
{
    BallController controller;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    const float positions[] = {-5.04f, -5.09f, -5.14f};
    uint8_t i;

    for (i = 0u; i < 3u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(positions[i], 0), now_ms);
        if (controller.state == BALL_STATE_B_SETTLE) {
            break;
        }
    }
    CHECK(controller.state == BALL_STATE_B_SETTLE,
          "three-frame outward motion did not leave DONE_HOLD");
    CHECK(controller.servo_command_deg > BALL_SERVO_CENTER_DEG,
          "outward B motion did not receive opposing positive brake");
    CHECK(controller.state != BALL_STATE_DRIVE_A,
          "outward safety response reran A");
    return 1;
}

static int test_46_static_060_075_bias_waits_then_one_40ms_pulse(void)
{
    BallController controller;
    uint32_t now_ms = 0u;
    uint32_t quiet_enter_ms = 0u;
    uint32_t first_pulse_ms = 0u;
    uint32_t first_observe_ms = 0u;
    uint16_t pulses_at_one_second = 0u;
    uint16_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 90u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.35f, 0), now_ms);
        if ((quiet_enter_ms == 0u) && (controller.quiet_active != 0u)) {
            quiet_enter_ms = now_ms;
        }
        if ((first_pulse_ms == 0u) &&
            (controller.settle_mode == BALL_SETTLE_QUIET_PULSE)) {
            first_pulse_ms = now_ms;
        }
        if ((first_pulse_ms != 0u) && (first_observe_ms == 0u) &&
            (controller.settle_mode == BALL_SETTLE_QUIET_OBSERVE)) {
            first_observe_ms = now_ms;
        }
        if ((quiet_enter_ms != 0u) &&
            ((uint32_t)(now_ms - quiet_enter_ms) <= 1000u)) {
            pulses_at_one_second =
                controller.diagnostics.quiet_pulse_count;
        }
    }
    CHECK(quiet_enter_ms != 0u, "0.65 cm bias never entered QHLD");
    CHECK(first_pulse_ms != 0u, "confirmed 0.65 cm bias never pulsed");
    CHECK((uint32_t)(first_pulse_ms - quiet_enter_ms) >=
          BALL_QUIET_BIAS_CONFIRM_MS,
          "quiet bias pulsed before 400 ms confirmation");
    CHECK(first_observe_ms != 0u,
          "40 ms quiet pulse did not enter QOBS");
    CHECK((uint32_t)(first_observe_ms - first_pulse_ms) <=
          (BALL_QUIET_PULSE_ACTIVE_MS + 20u),
          "quiet correction pulse exceeded its 40 ms frame tolerance");
    CHECK(pulses_at_one_second <= 1u,
          "more than one quiet pulse occurred in the first stable second");
    CHECK(absf_local(controller.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f ||
          controller.settle_mode == BALL_SETTLE_QUIET_PULSE,
          "quiet bias fixture ended with an invalid servo command");
    return 1;
}

static int test_47_quiet_observe_and_rearm_intervals_are_enforced(void)
{
    BallController controller;
    uint32_t now_ms = 0u;
    uint32_t observe_start_ms = 0u;
    uint32_t observe_end_ms = 0u;
    uint16_t first_pulse_count = 0u;
    uint16_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 120u; ++i) {
        BallSettleMode before = controller.settle_mode;
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.35f, 0), now_ms);
        if ((observe_start_ms == 0u) &&
            (controller.settle_mode == BALL_SETTLE_QUIET_OBSERVE)) {
            observe_start_ms = now_ms;
            first_pulse_count = controller.diagnostics.quiet_pulse_count;
        }
        if ((observe_start_ms != 0u) && (observe_end_ms == 0u) &&
            (before == BALL_SETTLE_QUIET_OBSERVE) &&
            (controller.settle_mode != BALL_SETTLE_QUIET_OBSERVE)) {
            observe_end_ms = now_ms;
        }
        if ((observe_start_ms != 0u) &&
            ((uint32_t)(now_ms - observe_start_ms) <
             BALL_QUIET_PULSE_OBSERVE_MS)) {
            CHECK(controller.settle_mode == BALL_SETTLE_QUIET_OBSERVE,
                  "QOBS ended before 160 ms");
            CHECK(absf_local(controller.servo_command_deg -
                             BALL_SERVO_CENTER_DEG) < 0.1f,
                  "QOBS did not hold centre");
        }
        if ((observe_start_ms != 0u) &&
            ((uint32_t)(now_ms - observe_start_ms) <
             BALL_QUIET_PULSE_REARM_MS)) {
            CHECK(controller.diagnostics.quiet_pulse_count ==
                  first_pulse_count,
                  "a second pulse bypassed the 300 ms rearm interval");
        }
    }
    CHECK(observe_start_ms != 0u, "QOBS was never entered");
    CHECK(observe_end_ms != 0u, "QOBS never completed");
    CHECK((uint32_t)(observe_end_ms - observe_start_ms) >=
          BALL_QUIET_PULSE_OBSERVE_MS,
          "QOBS duration was below 160 ms");
    return 1;
}

static int test_48_quiet_pulse_ends_early_on_motion(void)
{
    BallController controller;
    uint32_t now_ms = 0u;
    uint32_t pulse_start_ms = 0u;
    uint16_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_B_SETTLE;
    controller.task_started = 1u;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 50u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.35f, 0), now_ms);
        if (controller.settle_mode == BALL_SETTLE_QUIET_PULSE) {
            pulse_start_ms = now_ms;
            break;
        }
    }
    CHECK(pulse_start_ms != 0u, "quiet pulse fixture did not arm");
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-4.60f, 0), now_ms);
    CHECK(controller.settle_mode == BALL_SETTLE_QUIET_OBSERVE,
          "quiet pulse did not terminate on >=0.5 cm/s motion");
    CHECK((uint32_t)(now_ms - pulse_start_ms) <
          BALL_QUIET_PULSE_ACTIVE_MS,
          "early-stop fixture ran the complete 40 ms pulse");
    CHECK(absf_local(controller.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "early-ended quiet pulse did not return centre");
    return 1;
}

static int test_49_qhld_updates_all_pid_lanes_without_integral(void)
{
    BallController controller;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    uint32_t counts_before[BALL_PID_COUNT];
    uint8_t i;

    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        counts_before[i] = controller.pid_bank.lane[i].update_count;
        controller.pid_bank.lane[i].integral_cm_s = 1.0f;
    }
    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, 0), now_ms);
    CHECK(controller.pid_bank.update_mask == 0x3Fu,
          "QHLD update_mask is not 0x3F");
    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        CHECK(controller.pid_bank.lane[i].update_count ==
              counts_before[i] + 1u,
              "QHLD did not update every PID lane once");
        CHECK(absf_local(controller.pid_bank.lane[i].integral_cm_s) <
              0.0001f,
              "QHLD allowed PID integral accumulation");
    }
    return 1;
}

static int test_50_done_recapture_never_restarts_a(void)
{
    BallController controller;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    uint32_t task_start_before = controller.task_start_ms;
    uint32_t t_a_before = controller.diagnostics.t_a_ms;
    uint8_t saw_a_state = 0u;
    uint8_t i;

    for (i = 0u; i < 12u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.0f, 0), now_ms);
        if ((controller.state == BALL_STATE_DRIVE_A) ||
            (controller.state == BALL_STATE_BRAKE_A) ||
            (controller.state == BALL_STATE_A_CAPTURE)) {
            saw_a_state = 1u;
        }
    }
    CHECK(controller.state == BALL_STATE_B_SETTLE,
          "large confirmed DONE drift did not enter B_SETTLE");
    CHECK(saw_a_state == 0u, "DONE recapture revisited an A state");
    CHECK(controller.task_start_ms == task_start_before,
          "DONE recapture restarted the task timer");
    CHECK(controller.diagnostics.t_a_ms == t_a_before,
          "DONE recapture rewrote tA");
    return 1;
}

static int test_51_settled_timeout_uses_quiet_and_preserves_result(void)
{
    BallController controller;
    uint32_t now_ms = BALL_OFFICIAL_TIMEOUT_MS;
    float filtered_px = -BALL_TARGET_B_CM * BALL_PX_PER_CM;
    uint8_t i;

    BallController_Init(&controller, 0u);
    controller.state = BALL_STATE_TIMEOUT;
    controller.task_started = 1u;
    controller.task_start_ms = 0u;
    controller.result_flags = BALL_RESULT_TIMEOUT;
    controller.diagnostics.timeout_phase = BALL_STATE_B_SETTLE;
    controller.dx_zero_px = 0;
    for (i = 0u; i < 30u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-5.0f, 0), now_ms);
        if (controller.timeout_settled != 0u) {
            break;
        }
    }
    CHECK(controller.state == BALL_STATE_TIMEOUT,
          "settling a timeout erased TIMEOUT state");
    CHECK(controller.timeout_settled != 0u,
          "TIMEOUT did not enter settled quiet behavior");
    CHECK(controller.quiet_active != 0u,
          "settled TIMEOUT did not enter QHLD");
    CHECK((controller.result_flags & BALL_RESULT_TIMEOUT) != 0u,
          "settled TIMEOUT lost its result flag");
    CHECK((controller.result_flags & BALL_RESULT_PASS) == 0u,
          "settled TIMEOUT was falsely converted to PASS");

    for (i = 0u; i < 20u; ++i) {
        int16_t dx;
        now_ms += 20u;
        dx = k230_origin_filter_step(-5.0f,
            (i & 1u) ? 5 : -5, &filtered_px);
        BallController_OnMeasurement(&controller, dx, now_ms);
        CHECK(absf_local(controller.servo_command_deg -
                         BALL_SERVO_CENTER_DEG) < 0.1f,
              "settled TIMEOUT noise moved the servo");
    }
    for (i = 0u; i < 12u; ++i) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-4.0f, 0), now_ms);
    }
    CHECK(controller.state == BALL_STATE_TIMEOUT,
          "TIMEOUT recapture changed the result state");
    CHECK(controller.timeout_settled == 0u,
          "confirmed TIMEOUT drift did not resume B control");
    CHECK((controller.result_flags & BALL_RESULT_TIMEOUT) != 0u,
          "TIMEOUT recapture lost TIMEOUT result");
    return 1;
}

static int test_52_frozen_v32_prefix_trace_is_cycle_identical(void)
{
    BallSimulation simulation;

    simulation_init(&simulation, 15.0f, 0u, 0u, 0u);
    while ((simulation.prefix_complete == 0u) &&
           (simulation.tick < 300u)) {
        simulation_step(&simulation);
    }
    printf("    v32_prefix hash=%08lX cycles=%u tA=%lu tApr=%lu "
           "tBrk=%lu tSet=%lu\n",
           (unsigned long)simulation.prefix_hash,
           (unsigned)simulation.prefix_cycles,
           (unsigned long)simulation.controller.diagnostics.t_a_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_approach_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_brake_ms,
           (unsigned long)simulation.controller.diagnostics.t_b_settle_ms);
    CHECK(simulation.prefix_complete != 0u,
          "prefix trace never reached first BRAKE_B release");
    CHECK(simulation.prefix_hash == 0x87843EC6u,
          "pre-B_SETTLE cycle trace differs from frozen v3.2");
    CHECK(simulation.prefix_cycles == 86u,
          "pre-B_SETTLE cycle count differs from frozen v3.2");
    CHECK(simulation.controller.diagnostics.t_a_ms == 660u &&
          simulation.controller.diagnostics.t_b_approach_ms == 940u &&
          simulation.controller.diagnostics.t_b_brake_ms == 1380u &&
          simulation.controller.diagnostics.t_b_settle_ms == 1700u,
          "pre-B_SETTLE phase times differ from frozen v3.2");
    return 1;
}

static int test_53_deadzone_and_joint_models_keep_v32_budget(void)
{
    const float deadzones[] = {10.0f, 15.0f, 20.0f};
    uint8_t i;

    for (i = 0u; i < 3u; ++i) {
        BallSimulation simulation;
        simulation_init(&simulation, deadzones[i], 0u, 0u, 0u);
        CHECK(simulation_run(&simulation, BALL_BUDGET_DONE_MS) != 0u,
              "v3.3 lost a deadzone <=4.5 s result");
        CHECK(simulation.controller.diagnostics.t_done_ms <=
              BALL_BUDGET_DONE_MS,
              "v3.3 deadzone tDone exceeded 4.5 s");
    }
    {
        BallSimulation joint;
        simulation_init(&joint, 15.0f, 2u, 3u, 1u);
        joint.servo_lag_enabled = 1u;
        CHECK(simulation_run(&joint, BALL_BUDGET_DONE_MS) != 0u,
              "v3.3 lost the joint-lag <=4.5 s result");
    }
    return 1;
}

static int test_54_quiet_log_extension_stays_exactly_56_bytes(void)
{
    BallController controller;
    BallLogRecord record;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    uint16_t count;

    now_ms += 20u;
    BallController_OnMeasurement(&controller,
                                 position_to_dx(-5.0f, 0), now_ms);
    count = BallController_LogCount(&controller);
    CHECK(sizeof(BallLogRecord) == 56u,
          "BallLogRecord is not the allowed 56 bytes");
    CHECK(sizeof(controller.logs) ==
          (size_t)(BALL_LOG_CAPACITY * 56u),
          "256-record log storage is not compact");
    CHECK(count != 0u, "quiet log fixture contains no records");
    CHECK(BallController_GetLog(&controller,
          (uint16_t)(count - 1u), &record) != 0u,
          "could not read quiet log record");
    CHECK((record.quiet_flags & 0x01u) != 0u,
          "quiet-active flag missing from extended log");
    CHECK(record.pid_update_mask == 0x3Fu,
          "quiet log lost six-PID update mask");
    CHECK(record.servo_event_count ==
          (uint8_t)controller.diagnostics.servo_event_count,
          "quiet log servo-event count is inconsistent");
    return 1;
}

static int test_55_quiet_frames_keep_oled_at_four_hz(void)
{
    BallController controller;
    BallUiThrottle ui;
    uint32_t now_ms = prepare_done_quiet_controller(&controller, 0u);
    uint32_t start_ms = now_ms;
    uint32_t refreshes = 0u;

    BallUiThrottle_Init(&ui, now_ms);
    while ((uint32_t)(now_ms - start_ms) < 10000u) {
        now_ms += 20u;
        BallController_OnMeasurement(&controller,
                                     position_to_dx(-5.0f, 0), now_ms);
        BallUiThrottle_Request(&ui);
        if (BallUiThrottle_TakeRefresh(&ui, now_ms, 1u) != 0u) {
            refreshes++;
        }
    }
    CHECK(refreshes <= 40u,
          "quiet visual frames refreshed OLED above 4 Hz");
    CHECK(refreshes > 0u,
          "quiet OLED throttle fixture did not exercise the scheduler");
    return 1;
}

static int test_56_k2_and_vision_fault_clear_quiet_immediately(void)
{
    BallController aborted;
    BallController faulted;
    uint32_t now_ms = prepare_done_quiet_controller(&aborted, 0u);
    uint8_t i;

    faulted = aborted;
    BallController_RequestAbort(&aborted, now_ms + 1u);
    CHECK(aborted.state == BALL_STATE_ABORTED,
          "K2 did not abort QHLD");
    CHECK(absf_local(aborted.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "K2 did not centre QHLD immediately");
    CHECK(aborted.quiet_observer.count == 0u,
          "K2 did not clear quiet observer history");

    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        faulted.pid_bank.lane[i].integral_cm_s = 1.0f;
    }
    BallController_OnVisionFault(&faulted, now_ms + 80u, 80u);
    CHECK(faulted.state == BALL_STATE_VISION_FAULT,
          "80 ms fault did not leave QHLD for VISION_FAULT");
    CHECK(absf_local(faulted.servo_command_deg -
                     BALL_SERVO_CENTER_DEG) < 0.1f,
          "vision fault did not centre QHLD immediately");
    CHECK(faulted.quiet_observer.count == 0u,
          "vision fault did not clear quiet observer history");
    for (i = 0u; i < BALL_PID_COUNT; ++i) {
        CHECK(absf_local(faulted.pid_bank.lane[i].integral_cm_s) <
              0.0001f,
              "vision fault retained a PID integral");
    }
    return 1;
}

typedef int (*TestFunction)(void);

typedef struct {
    const char *name;
    TestFunction function;
} TestCase;

int main(void)
{
    static const TestCase tests[] = {
        {"01 A predictive brake and 4.2..5.8 cm turn", test_01_a_predictive_brake_and_turn},
        {"02 active DRIVE_B without coast", test_02_active_drive_b_no_coast},
        {"03 B predictive brake before -5 cm", test_03_b_predictive_brake_before_endpoint},
        {"04 deadzones 10/15/20 degrees", test_04_deadzone_10_15_20},
        {"05 effective 20..26 degree settle pulses", test_05_effective_pulses_not_12_degrees},
        {"06 true-time velocity at 45..60 FPS and jitter", test_06_true_time_velocity_45_to_60_fps},
        {"07 40 ms lag, +/-5 px noise and drops", test_07_lag_noise_and_drops},
        {"08 80 ms vision timeout", test_08_vision_timeout_centres_and_resets},
        {"09 K2 abort in all active states", test_09_k2_aborts_every_active_state},
        {"10 DONE_HOLD drift recaptures B only", test_10_done_hold_drift_recaptures_b_only},
        {"11 hard and automatic servo limits", test_11_servo_limits_under_arbitrary_input},
        {"12 tA/tB_enter/tDone consistency", test_12_stage_timestamps_are_consistent},
        {"13 OLED throttle", test_13_oled_throttled_not_per_frame},
        {"14 bounded log/SRAM object", test_14_log_and_sram_are_bounded},
        {"15 UART latest packet/timestamp continuity", test_15_uart_latest_timestamp_mailbox},
        {"16 paged OLED refresh", test_16_oled_refresh_is_paged},
        {"17 early K1 latches and auto-starts at RDY", test_17_k1_latches_until_prequalified_ready},
        {"18 A_CAPTURE 300 ms liveness watchdog", test_18_a_capture_watchdog_never_sticks},
        {"19 B overshoot damping rejects outward energy", test_19_b_overshoot_damping_never_adds_outward_energy},
        {"20 BRAKE_B rebound release despite filter lag", test_20_brake_b_rebound_releases_filtered_lag},
        {"21 60 ms pulse early termination", test_21_sixty_ms_pulse_can_end_early},
        {"22 40 ms ring log covers about 10.2 s", test_22_log_covers_ten_seconds_at_40_ms},
        {"23 servo lag and correlated-noise combination", test_23_servo_lag_correlated_noise_combination},
        {"24 all six PID lanes update and normalized-fuse", test_24_six_pid_lanes_update_and_fuse},
        {"25 PID region crossfades stay continuous", test_25_pid_region_crossfades_are_continuous},
        {"26 PID true-dt integral and reset", test_26_pid_true_dt_integral_and_reset},
        {"27 fast estimator true-time slope and 61 ms reset", test_27_fast_estimator_true_time_and_gap_reset},
        {"28 origin K230 filter is in the closed loop", test_28_origin_k230_filter_is_in_closed_loop},
        {"29 v_fast leads v_slow during B acceleration", test_29_fast_velocity_leads_slow_velocity},
        {"30 B approach requires two candidate frames", test_30_approach_requires_two_frames},
        {"31 BAPR log precedes same-cycle hard brake", test_31_bapproach_log_precedes_hard_brake},
        {"32 v3.2 brake leads frozen v3.1 predicate", test_32_v32_brakes_before_frozen_v31_predicate},
        {"33 fused PID cannot weaken BRAKE_B", test_33_brake_b_cannot_be_weakened_by_pid},
        {"34 nominal v3.2 timing/overshoot metrics", test_34_nominal_v32_metrics},
        {"35 joint lag/noise/deadzone/servo model", test_35_joint_lag_noise_deadzone_and_servo_delay},
        {"36 61 ms fast reset preserves state liveness", test_36_fast_gap_reset_does_not_stall_state_machine},
        {"37 extended log fields and stable state IDs", test_37_extended_log_fields_and_state_ids},
        {"38 TIMEOUT from BAPR keeps B control alive", test_38_timeout_in_bapproach_keeps_b_control_alive},
        {"39 QHLD stationary origin-K230 noise is silent", test_39_qhld_stationary_k230_noise_is_silent},
        {"40 one/two position spikes stay quiet", test_40_one_two_position_spikes_stay_quiet},
        {"41 one/two velocity spikes do not recapture", test_41_one_two_velocity_spikes_do_not_recapture},
        {"42 correlated centroid drift never alternates pulses", test_42_correlated_centroid_drift_never_alternates_pulses},
        {"43 latest raw outside done band never passes", test_43_latest_raw_outside_done_band_never_passes},
        {"44 real drift recovers within 800 ms", test_44_real_drift_recaptures_and_recovers_within_800ms},
        {"45 outward motion retains energy braking", test_45_outward_motion_still_gets_energy_brake},
        {"46 static 0.60..0.75 bias waits and pulses once", test_46_static_060_075_bias_waits_then_one_40ms_pulse},
        {"47 QOBS and pulse rearm intervals", test_47_quiet_observe_and_rearm_intervals_are_enforced},
        {"48 quiet pulse early motion termination", test_48_quiet_pulse_ends_early_on_motion},
        {"49 QHLD six PID updates without integral", test_49_qhld_updates_all_pid_lanes_without_integral},
        {"50 DONE recapture never restarts A", test_50_done_recapture_never_restarts_a},
        {"51 settled TIMEOUT preserves result", test_51_settled_timeout_uses_quiet_and_preserves_result},
        {"52 frozen v3.2 prefix per-cycle trace", test_52_frozen_v32_prefix_trace_is_cycle_identical},
        {"53 deadzone and joint models keep budget", test_53_deadzone_and_joint_models_keep_v32_budget},
        {"54 quiet log extension is 56 bytes", test_54_quiet_log_extension_stays_exactly_56_bytes},
        {"55 quiet frames keep OLED at four Hz", test_55_quiet_frames_keep_oled_at_four_hz},
        {"56 K2 and 80 ms fault clear quiet", test_56_k2_and_vision_fault_clear_quiet_immediately}
    };
    uint8_t i;

    printf("H_Q3_V3_3_B_QUIET_HYSTERESIS_HOST_TESTS\n");
    printf("sizeof(BallLogRecord)=%u sizeof(BallController)=%u\n",
           (unsigned)sizeof(BallLogRecord),
           (unsigned)sizeof(BallController));

    for (i = 0u; i < (sizeof(tests) / sizeof(tests[0])); ++i) {
        int passed;
        g_tests_run++;
        printf("[%02u] %s\n", (unsigned)(i + 1u), tests[i].name);
        passed = tests[i].function();
        if (passed != 0) {
            printf("    PASS\n");
        } else {
            printf("    FAIL\n");
            g_failures++;
        }
    }

    printf("SUMMARY: %d passed, %d failed, %d total\n",
           g_tests_run - g_failures, g_failures, g_tests_run);
    return (g_failures == 0) ? 0 : 1;
}
