#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "ball_config.h"
#include "ball_controller.h"

typedef struct {
    BallController controller;
    float x_cm;
    float velocity_cm_s;
    float history_cm[4];
    float filtered_px;
    uint32_t now_ms;
    uint32_t hash;
    uint16_t cycles;
} PrefixFixture;

static uint32_t fnv1a_u32(uint32_t hash, uint32_t value)
{
    uint8_t i;
    for (i = 0u; i < 4u; ++i) {
        hash ^= (uint8_t)(value & 0xFFu);
        hash *= 16777619u;
        value >>= 8;
    }
    return hash;
}

static void plant_step(PrefixFixture *fixture)
{
    const float dt_s = 0.020f;
    float offset_deg = fixture->controller.servo_command_deg -
                       BALL_SERVO_CENTER_DEG;
    float effective_deg = 0.0f;
    float acceleration_cm_s2;
    uint8_t i;

    if (offset_deg > 15.0f) {
        effective_deg = offset_deg - 15.0f;
    } else if (offset_deg == 15.0f) {
        effective_deg = 1.0f;
    } else if (offset_deg < -15.0f) {
        effective_deg = offset_deg + 15.0f;
    } else if (offset_deg == -15.0f) {
        effective_deg = -1.0f;
    }
    acceleration_cm_s2 = 2.75f * effective_deg -
                         1.05f * fixture->velocity_cm_s;
    fixture->velocity_cm_s += acceleration_cm_s2 * dt_s;
    fixture->x_cm += fixture->velocity_cm_s * dt_s;
    for (i = 3u; i > 0u; --i) {
        fixture->history_cm[i] = fixture->history_cm[i - 1u];
    }
    fixture->history_cm[0] = fixture->x_cm;
}

static int16_t filtered_dx(PrefixFixture *fixture)
{
    float raw_px = -fixture->history_cm[0] * BALL_PX_PER_CM;
    fixture->filtered_px = 0.7f * fixture->filtered_px + 0.3f * raw_px;
    return (int16_t)fixture->filtered_px;
}

int main(void)
{
    PrefixFixture fixture;
    uint8_t i;

    memset(&fixture, 0, sizeof(fixture));
    fixture.hash = 2166136261u;
    BallController_Init(&fixture.controller, 0u);
    for (i = 0u; i < BALL_CENTER_SAMPLE_COUNT; ++i) {
        fixture.now_ms += 20u;
        BallController_OnMeasurement(&fixture.controller, 0,
                                     fixture.now_ms);
    }
    BallController_RequestStart(&fixture.controller, fixture.now_ms);

    while ((fixture.controller.state != BALL_STATE_B_SETTLE) &&
           (fixture.cycles < 300u)) {
        int16_t dx;
        uint16_t servo10;
        uint32_t elapsed_ms;

        plant_step(&fixture);
        fixture.now_ms += 20u;
        dx = filtered_dx(&fixture);
        BallController_OnMeasurement(&fixture.controller, dx,
                                     fixture.now_ms);
        elapsed_ms = BallController_TaskElapsedMs(&fixture.controller,
                                                  fixture.now_ms);
        servo10 = (uint16_t)(fixture.controller.servo_command_deg *
                             10.0f + 0.5f);
        fixture.hash = fnv1a_u32(fixture.hash, elapsed_ms);
        fixture.hash = fnv1a_u32(fixture.hash, (uint16_t)dx);
        fixture.hash = fnv1a_u32(fixture.hash,
                                 (uint8_t)fixture.controller.state);
        fixture.hash = fnv1a_u32(fixture.hash, servo10);
        fixture.cycles++;
    }

    printf("hash=%08lX cycles=%u tA=%lu tApproach=%lu tBrake=%lu "
           "tSettle=%lu state=%u\n",
           (unsigned long)fixture.hash,
           (unsigned)fixture.cycles,
           (unsigned long)fixture.controller.diagnostics.t_a_ms,
           (unsigned long)fixture.controller.diagnostics.t_b_approach_ms,
           (unsigned long)fixture.controller.diagnostics.t_b_brake_ms,
           (unsigned long)fixture.controller.diagnostics.t_b_settle_ms,
           (unsigned)fixture.controller.state);
    return (fixture.controller.state == BALL_STATE_B_SETTLE) ? 0 : 1;
}
