$ErrorActionPreference = 'Stop'

$testRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $testRoot
$buildRoot = Join-Path $testRoot 'build'
$testExe = Join-Path $buildRoot 'test_ball_v33.exe'
$resultsPath = Join-Path $testRoot 'results.txt'
$compilerPath = Join-Path $testRoot 'compiler_version.txt'
$staticChecksPath = Join-Path $testRoot 'static_checks.txt'
$prefixResultsPath = Join-Path $testRoot 'results_prefix_comparison.txt'
$stubRoot = Join-Path $testRoot 'stubs'

New-Item -ItemType Directory -Path $buildRoot -Force | Out-Null

$gccCommand = Get-Command gcc -ErrorAction SilentlyContinue
if ($null -eq $gccCommand) {
    $knownGcc = 'Y:\Dev-C++\File\Dev-Cpp\MinGW64\bin\gcc.exe'
    if (-not (Test-Path -LiteralPath $knownGcc)) {
        throw 'gcc was not found; host tests were not built.'
    }
    $gcc = $knownGcc
} else {
    $gcc = $gccCommand.Source
}

(& $gcc --version | Select-Object -First 1) | Set-Content -LiteralPath $compilerPath -Encoding UTF8

& $gcc `
    -std=c99 -O2 -Wall -Wextra -Werror -Wno-type-limits -pedantic `
    -DUART_HOST_TEST_NO_STDIO_REDIRECT `
    "-I$stubRoot" "-I$(Join-Path $projectRoot 'driver')" "-I$projectRoot" `
    (Join-Path $projectRoot 'ball_estimator.c') `
    (Join-Path $projectRoot 'ball_fast_estimator.c') `
    (Join-Path $projectRoot 'ball_pid_bank.c') `
    (Join-Path $projectRoot 'ball_quiet_observer.c') `
    (Join-Path $projectRoot 'ball_controller.c') `
    (Join-Path $projectRoot 'ball_ui.c') `
    (Join-Path $projectRoot 'driver\uart.c') `
    (Join-Path $projectRoot 'driver\oled.c') `
    (Join-Path $testRoot 'test_ball_v26.c') `
    -o $testExe -lm

if ($LASTEXITCODE -ne 0) {
    throw "Host test compilation failed with exit code $LASTEXITCODE."
}

$prefixExe = Join-Path $buildRoot 'prefix_trace_v33.exe'
& $gcc `
    -std=c99 -O2 -Wall -Wextra -Werror -pedantic `
    "-I$projectRoot" `
    (Join-Path $projectRoot 'ball_estimator.c') `
    (Join-Path $projectRoot 'ball_fast_estimator.c') `
    (Join-Path $projectRoot 'ball_pid_bank.c') `
    (Join-Path $projectRoot 'ball_quiet_observer.c') `
    (Join-Path $projectRoot 'ball_controller.c') `
    (Join-Path $testRoot 'prefix_trace.c') `
    -o $prefixExe -lm
if ($LASTEXITCODE -ne 0) {
    throw "Prefix-trace compilation failed with exit code $LASTEXITCODE."
}
$prefixActual = (& $prefixExe 2>&1 | Out-String).Trim()
$prefixExpected = (Get-Content -LiteralPath `
    (Join-Path $testRoot 'v32_prefix_expected.txt') -Raw).Trim()
@(
    "frozen_v32=$prefixExpected"
    "current_v33=$prefixActual"
) | Set-Content -LiteralPath $prefixResultsPath -Encoding UTF8
if ($prefixActual -ne $prefixExpected) {
    throw 'v3.3 differs from frozen v3.2 before the first BRAKE_B release.'
}

$mainObject = Join-Path $buildRoot 'main_syntax.o'
$oledObject = Join-Path $buildRoot 'oled_syntax.o'
$uartObject = Join-Path $buildRoot 'uart_syntax.o'
& $gcc -std=c99 -O2 -Wall -Wextra -Werror -Wno-type-limits -pedantic `
    "-I$stubRoot" "-I$(Join-Path $projectRoot 'driver')" "-I$projectRoot" `
    -c (Join-Path $projectRoot 'main.c') -o $mainObject
if ($LASTEXITCODE -ne 0) {
    throw "main.c host-stub syntax compilation failed with exit code $LASTEXITCODE."
}
& $gcc -std=c99 -O2 -Wall -Wextra -Werror -Wno-type-limits -pedantic `
    "-I$stubRoot" "-I$(Join-Path $projectRoot 'driver')" "-I$projectRoot" `
    -c (Join-Path $projectRoot 'driver\oled.c') -o $oledObject
if ($LASTEXITCODE -ne 0) {
    throw "oled.c host-stub syntax compilation failed with exit code $LASTEXITCODE."
}
& $gcc -std=c99 -O2 -Wall -Wextra -Werror -pedantic `
    -DUART_HOST_TEST_NO_STDIO_REDIRECT `
    "-I$stubRoot" "-I$(Join-Path $projectRoot 'driver')" "-I$projectRoot" `
    -c (Join-Path $projectRoot 'driver\uart.c') -o $uartObject
if ($LASTEXITCODE -ne 0) {
    throw "uart.c host-stub syntax compilation failed with exit code $LASTEXITCODE."
}

$mainText = Get-Content -LiteralPath (Join-Path $projectRoot 'main.c') -Raw
$isrMatch = [regex]::Match(
    $mainText,
    'void\s+TIMER_PID_INST_IRQHandler\s*\(void\)\s*\{(?<body>[\s\S]*)\}\s*$',
    [System.Text.RegularExpressions.RegexOptions]::CultureInvariant)
if (-not $isrMatch.Success) {
    throw 'Could not locate the 1 ms ISR for static checks.'
}
$forbiddenIsr = 'PID_Update|huidu_get_value|OLED_|UART_(Send|Printf)|Servo_SetAngle|Servo_ApplySafe'
if ([regex]::IsMatch($isrMatch.Groups['body'].Value, $forbiddenIsr)) {
    throw 'Forbidden control/display/IO call found in the 1 ms ISR.'
}
if ($mainText -match 'DL_Timer_startCounter\s*\(\s*MOTOR_INST\s*\)|Encoder_Init\s*\(') {
    throw 'Q3 main starts MOTOR or Encoder_Init.'
}
if ($mainText -match '\bPID_Update\s*\(') {
    throw 'Q3 main still calls the legacy no-dt PID.'
}
if ($mainText -match '\bOLED_Refresh\s*\(') {
    throw 'Q3 main still performs a monolithic full-screen OLED refresh.'
}
if ($mainText -notmatch 'UART_TakeLatestPacket' -or
    $mainText -notmatch 'packet_arrival_ms') {
    throw 'Q3 main does not consume ISR-timestamped latest UART packets.'
}

$uartText = Get-Content -LiteralPath (Join-Path $projectRoot 'driver\uart.c') -Raw
if ($uartText -match "RxData\s*==\s*'@'\s*&&\s*UART_RxFlag\s*==\s*0") {
    throw 'UART ISR still stops parsing while the foreground mailbox is full.'
}
if ($uartText -notmatch 'UART_RxPacketTimeMs\s*=\s*arrival_ms' -or
    $uartText -notmatch 'UART_RxOverwriteCount\+\+') {
    throw 'UART latest-value timestamp mailbox implementation is incomplete.'
}

$controllerText = Get-Content -LiteralPath (Join-Path $projectRoot 'ball_controller.c') -Raw
$fastEstimatorText = Get-Content -LiteralPath (Join-Path $projectRoot 'ball_fast_estimator.c') -Raw
$pidBankText = Get-Content -LiteralPath (Join-Path $projectRoot 'ball_pid_bank.c') -Raw
$quietObserverText = Get-Content -LiteralPath (Join-Path $projectRoot 'ball_quiet_observer.c') -Raw
$cprojectText = Get-Content -LiteralPath (Join-Path $projectRoot '.cproject') -Raw
if ($controllerText -notmatch 'BallPidBank_Update' -or
    $controllerText -match '\bPID_Update\s*\(') {
    throw 'Controller is not wired to the six-lane true-time PID bank.'
}
if ($pidBankText -notmatch 'g_pid_config\[BALL_PID_COUNT\]' -or
    $pidBankText -notmatch 'update_mask\s*\|=') {
    throw 'Six-lane PID table or parallel execution mask is missing.'
}
if ($fastEstimatorText -notmatch 'BALL_FAST_ESTIMATOR_SAMPLE_COUNT' -or
    $controllerText -notmatch 'BALL_STATE_B_APPROACH' -or
    $controllerText -notmatch 'Ball_SetServoAutomaticOffset\(controller, BALL_BRAKE_B_OFFSET_DEG\)') {
    throw 'v3.2 fast estimator, B_APPROACH, or non-weakened BRAKE_B wiring is missing.'
}
if ($quietObserverText -notmatch 'BALL_QUIET_SAMPLE_COUNT' -or
    $controllerText -notmatch 'BALL_SETTLE_QUIET' -or
    $controllerText -notmatch 'BALL_QUIET_POSITION_CONFIRM_MS') {
    throw 'v3.3 quiet observer, QHLD mode, or hysteresis confirmation is missing.'
}
if ($cprojectText -notmatch
    'excluding="build_logs\|firmware\|host_tests\|k230_reference"') {
    throw 'CCS source path does not exclude packaged evidence/non-source directories.'
}
$packagedGeneratedInputs = Get-ChildItem -LiteralPath `
    (Join-Path $projectRoot 'build_logs') -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Name -in @('ti_msp_dl_config.c', 'device_linker.cmd', 'device.opt')
    }
if ($packagedGeneratedInputs.Count -ne 0) {
    throw ('Build evidence contains generated compiler/linker inputs that CCS may ' +
        'compile again: ' + ($packagedGeneratedInputs.FullName -join ', '))
}

@(
    'PASS main.c host-stub syntax compile with -Werror'
    'PASS modified oled.c host-stub syntax compile with -Werror'
    'PASS modified uart.c host-stub syntax compile with -Werror'
    'PASS 1 ms ISR contains only time/key/event work'
    'PASS Q3 main does not start MOTOR or call Encoder_Init'
    'PASS Q3 main does not call legacy PID_Update'
    'PASS Q3 main uses ISR-arrival timestamps and latest UART mailbox'
    'PASS Q3 main uses paged OLED refresh instead of a monolithic refresh'
    'PASS controller calls the six-lane true-time PID bank'
    'PASS six-lane PID table and update mask are present'
    'PASS v3.2 fast estimator and B_APPROACH are wired into the controller'
    'PASS BRAKE_B uses the fixed automatic +28 degree command'
    'PASS v3.3 five-sample quiet observer and hysteresis are wired'
    'PASS frozen v3.2 and v3.3 pre-B_SETTLE cycle traces are identical'
    'PASS CCS excludes packaged evidence and host/non-source directories'
    'PASS build evidence contains no duplicate generated C/CMD/OPT inputs'
) | Set-Content -LiteralPath $staticChecksPath -Encoding UTF8

& $testExe 2>&1 | Tee-Object -FilePath $resultsPath
$testExit = $LASTEXITCODE
if ($testExit -ne 0) {
    throw "Host tests failed with exit code $testExit."
}

$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
if ($null -eq $pythonCommand) {
    throw 'python was not found; K230 filter host tests were not run.'
}
$k230Output = & $pythonCommand.Source (Join-Path $testRoot 'test_k230_origin_v32.py') 2>&1
$k230Exit = $LASTEXITCODE
$k230Output | Tee-Object -FilePath $resultsPath -Append
if ($k230Exit -ne 0) {
    throw "K230 filter host tests failed with exit code $k230Exit."
}
