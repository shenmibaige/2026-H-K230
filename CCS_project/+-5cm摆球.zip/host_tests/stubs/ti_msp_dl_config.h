#ifndef HOST_TI_MSP_DL_CONFIG_H
#define HOST_TI_MSP_DL_CONFIG_H

#include <stdint.h>

#define Serial_INST ((void *)0)
#define Serial_INST_INT_IRQN 1
#define TIMER_PID_INST ((void *)0)
#define TIMER_PID_INST_INT_IRQN 2
#define SERVO_INST ((void *)0)
#define MOTOR_INST_INT_IRQN 3
#define ENCODER_GPIOA_INT_IRQN 4
#define ENCODER_GPIOB_INT_IRQN 5
#define ENCODER_A1_PORT ((void *)0)
#define ENCODER_A2_PORT ((void *)0)
#define ENCODER_A1_PIN (1u << 1)
#define ENCODER_B1_PIN (1u << 2)
#define ENCODER_A2_PIN (1u << 3)
#define ENCODER_B2_PIN (1u << 4)
#define OLED_INST ((void *)0)

#define DL_TIMER_IIDX_LOAD 1u
#define DL_UART_IIDX_RX 1u
#define DL_I2C_CONTROLLER_STATUS_IDLE 1u
#define DL_I2C_CONTROLLER_STATUS_BUSY_BUS 2u
#define DL_I2C_CONTROLLER_DIRECTION_TX 0u

extern uint8_t g_host_uart_rx_byte;
extern uint32_t g_host_i2c_transfer_count;

static inline void SYSCFG_DL_init(void) {}
static inline void NVIC_EnableIRQ(int irq) { (void)irq; }
static inline void NVIC_DisableIRQ(int irq) { (void)irq; }
static inline void NVIC_ClearPendingIRQ(int irq) { (void)irq; }
static inline void DL_GPIO_disableInterrupt(void *port, uint32_t pins)
{
    (void)port;
    (void)pins;
}
static inline void DL_SYSTICK_disableInterrupt(void) {}
static inline void DL_SYSTICK_disable(void) {}
static inline void DL_Timer_startCounter(void *timer) { (void)timer; }
static inline uint32_t DL_TimerA_getPendingInterrupt(void *timer)
{
    (void)timer;
    return DL_TIMER_IIDX_LOAD;
}
static inline uint32_t DL_UART_Main_getPendingInterrupt(void *uart)
{
    (void)uart;
    return DL_UART_IIDX_RX;
}
static inline uint8_t DL_UART_Main_receiveData(void *uart)
{
    (void)uart;
    return g_host_uart_rx_byte;
}
static inline void DL_UART_Main_transmitDataBlocking(void *uart, uint8_t data)
{
    (void)uart;
    (void)data;
}
static inline uint32_t DL_I2C_getControllerStatus(void *i2c)
{
    (void)i2c;
    return DL_I2C_CONTROLLER_STATUS_IDLE | DL_I2C_CONTROLLER_STATUS_BUSY_BUS;
}
static inline void DL_I2C_fillControllerTXFIFO(void *i2c,
                                               const uint8_t *data,
                                               uint32_t length)
{
    (void)i2c;
    (void)data;
    (void)length;
    g_host_i2c_transfer_count++;
}
static inline void DL_I2C_startControllerTransfer(void *i2c,
                                                  uint32_t address,
                                                  uint32_t direction,
                                                  uint32_t length)
{
    (void)i2c;
    (void)address;
    (void)direction;
    (void)length;
}

#endif
