import hashlib
import pathlib
import re
import sys
import unittest


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
SCRIPT_PATH = PROJECT_ROOT / "k230_reference" / "07钢珠偏差串口发送.py"
EXPECTED_SHA256 = "E32127A397766FE989B7810EC221879C252296A87D9A63DB3C329375B85F8601"


def origin_filter(samples):
    filtered = 0.0
    return_values = []
    for raw in samples:
        filtered = filtered * 0.7 + raw * 0.3
        return_values.append(int(filtered))
    return return_values


class K230OriginV32Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.payload = SCRIPT_PATH.read_bytes()
        cls.text = cls.payload.decode("utf-8")

    def test_reference_script_is_byte_identical(self):
        self.assertEqual(hashlib.sha256(self.payload).hexdigest().upper(),
                         EXPECTED_SHA256)

    def test_uart_pin_baud_and_protocol_are_unchanged(self):
        self.assertIn("fpioa.set_function(11, FPIOA.UART2_TXD)", self.text)
        self.assertIn("uart2 = UART(UART.UART2, 115200)", self.text)
        self.assertIn('uart2.write("@" + str(int(dx)) + "\\r\\n")', self.text)
        self.assertIn("LOST_DX = -999", self.text)

    def test_original_fixed_filter_is_present(self):
        self.assertRegex(
            self.text,
            re.compile(r"filtered_dx\s*=\s*filtered_dx\s*\*\s*0\.7\s*\+\s*raw_dx\s*\*\s*0\.3"),
        )
        self.assertNotIn("dt/(8", self.text)
        self.assertNotIn("three_frame_median", self.text)

    def test_fixed_filter_step_delay_is_modelled(self):
        outputs = origin_filter([100, 100, 100, 100])
        self.assertEqual(outputs, [30, 51, 65, 75])
        self.assertLess(outputs[0], 50)
        self.assertGreaterEqual(outputs[1], 50)

    def test_integer_output_uses_truncation(self):
        self.assertEqual(int(1.9), 1)
        self.assertEqual(int(-1.9), -1)
        self.assertIn("send_dx_to_m0(int(filtered_dx))", self.text)

    def test_original_jump_gate_is_retained(self):
        self.assertIn("abs(raw_dx - filtered_dx) > 300", self.text)
        self.assertIn("if consecutive_jumps >= 10", self.text)
        self.assertIn("max(jump_raw_dx_list) - min(jump_raw_dx_list) <= 300", self.text)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(K230OriginV32Tests)
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
