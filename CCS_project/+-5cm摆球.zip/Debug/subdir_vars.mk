################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../ball_controller.c \
../ball_estimator.c \
../ball_fast_estimator.c \
../ball_pid_bank.c \
../ball_quiet_observer.c \
../ball_ui.c \
../delay.c \
./ti_msp_dl_config.c \
C:/TI/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
../huidu.c \
../main.c \
../pid.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./ball_controller.d \
./ball_estimator.d \
./ball_fast_estimator.d \
./ball_pid_bank.d \
./ball_quiet_observer.d \
./ball_ui.d \
./delay.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d \
./huidu.d \
./main.d \
./pid.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./ball_controller.o \
./ball_estimator.o \
./ball_fast_estimator.o \
./ball_pid_bank.o \
./ball_quiet_observer.o \
./ball_ui.o \
./delay.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o \
./huidu.o \
./main.o \
./pid.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"ball_controller.o" \
"ball_estimator.o" \
"ball_fast_estimator.o" \
"ball_pid_bank.o" \
"ball_quiet_observer.o" \
"ball_ui.o" \
"delay.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" \
"huidu.o" \
"main.o" \
"pid.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"ball_controller.d" \
"ball_estimator.d" \
"ball_fast_estimator.d" \
"ball_pid_bank.d" \
"ball_quiet_observer.d" \
"ball_ui.d" \
"delay.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" \
"huidu.d" \
"main.d" \
"pid.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../ball_controller.c" \
"../ball_estimator.c" \
"../ball_fast_estimator.c" \
"../ball_pid_bank.c" \
"../ball_quiet_observer.c" \
"../ball_ui.c" \
"../delay.c" \
"./ti_msp_dl_config.c" \
"C:/TI/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" \
"../huidu.c" \
"../main.c" \
"../pid.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


