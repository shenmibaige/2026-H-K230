################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"F:/MCU/11_TI_MSP/CCS_ide/install/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/driver/mpu6050" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/driver" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-1310487003: ../empty.syscfg
	@echo 'SysConfig - building file: "$<"'
	"C:/TI/sysconfig_1.26.2/sysconfig_cli.bat" -s "C:/TI/mspm0_sdk_2_10_00_04/.metadata/product.json" --script "F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/empty.syscfg" -o "." --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

device_linker.cmd: build-1310487003 ../empty.syscfg
device.opt: build-1310487003
device.cmd.genlibs: build-1310487003
ti_msp_dl_config.c: build-1310487003
ti_msp_dl_config.h: build-1310487003
Event.dot: build-1310487003

%.o: ./%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"F:/MCU/11_TI_MSP/CCS_ide/install/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/driver/mpu6050" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/driver" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: C:/TI/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"F:/MCU/11_TI_MSP/CCS_ide/install/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/driver/mpu6050" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/driver" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338" -I"F:/MCU/11_TI_MSP/CCS_project/2026project_AI/H_Q3_v3_3_1_portable_build_fix_20260801_98af3338/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


