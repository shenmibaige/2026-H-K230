# H题第三问 v3.3.1 跨电脑构建修复版

## 当前结论

本版本只修复v3.3交付包在另一台电脑上由CCS重新构建时的重复链接问题，不修改小球控制算法、状态机、参数、引脚或K230协议。工程仍只执行第三问：钢球从O点出发，在A（+5 cm）附近转折，主动运行到B（-5 cm）并以QHLD迟滞逻辑静默保持。

已完成56项M0主机测试、6项原始K230脚本兼容检查、静态检查和两个独立ASCII镜像的CCS Clean/Full Build。两个镜像去除调试路径后的固件与v3.3字节完全一致。尚未在用户硬件上烧录v3.3.1并执行K1实物验收，因此不能据此声称实物已经满足5秒或稳定性要求。

## 修复基线与隔离

唯一修复基线：

`H_Q3_v3_3_b_quiet_hysteresis_20260801_00730731.zip`

- 基线ZIP SHA-256：`5390AB5C5A52FC287D6A9DF63E394132352373A69D07A51A085A4BB9251024F2`
- 基线固件SHA-256：`53246FC3E55A83CFB57D59B7100AD75EA416E10A0D981EFA211B2DFCF725AE61`
- 修复工程名：`H_Q3_V331_QHOLD`
- 修复固件名：`H_Q3_V331_QHOLD.out`

原v3.3 ZIP和工作目录均未覆盖或改写。`empty.syscfg`内容未编辑；只将其ZIP时代的1980年时间戳规范化，以确保CCS Clean后必定重新运行SysConfig。其内容SHA-256始终为`D7863A739C1D052D2655C6106A85F59054FB356D92966C1FED3A41192F06BC66`。

## 用户日志中的实际错误原因

用户提供的日志显示，全部预期C源文件均已编译成功，失败发生在最终链接阶段。原v3.3包把以下“构建证据”放在CCS工程树内：

- `build_logs/mirror_a/ti_msp_dl_config.c`
- `build_logs/mirror_b/ti_msp_dl_config.c`
- `build_logs/mirror_a/device_linker.cmd`
- `build_logs/mirror_b/device_linker.cmd`

原`.cproject`只排除了`host_tests`。另一台电脑导入工程后，CCS递归扫描到上述文件，最终链接命令同时包含三份`ti_msp_dl_config`和三份链接脚本，因而出现：

- `#10263`：FLASH、SRAM、BCR_CONFIG、BSL_CONFIG区域被重复指定；
- `#10264`：上述内存区域互相重叠；
- `#10010`：链接失败，OUT未生成。

Clean阶段“找不到旧的build_logs对象文件”的提示只是清理陈旧依赖时的伴随警告，不是根因。此故障与M0硬件、K230识别、UART、QHLD控制算法和舵机方向无关；原v3.3预编译固件本身也不是坏固件。

## v3.3.1的最小修复

1. 工程改名为`H_Q3_V331_QHOLD`，避免在CCS工作区和烧录时与旧工程混淆。
2. `.cproject`显式排除`build_logs|firmware|host_tests|k230_reference`，这些目录不会参与源码发现、编译或链接。
3. `build_logs`只保留安全的`.log/.out/.map/.xml`证据，不再放入可被CCS解释为输入的`.c/.cmd/.opt`文件。
4. 主机静态检查新增工程排除项与构建证据安全检查。
5. 两个ASCII镜像完成Clean/Full Build；镜像A额外在被排除目录中放置故意无法编译的探针，构建仍成功，证明排除规则真实生效。
6. 最终交付结构再复制到新的ASCII目录执行Clean/Full Build，验证携带安全构建证据后仍可重建。

详细诊断见`PORTABLE_BUILD_FIX.md`，原始用户日志副本见`build_logs/user_reported_compile_error.log`。

## 控制行为保持不变

v3.3.1与v3.3的43个非测试、非生成`.c/.h`文件逐项SHA-256一致。两个新ASCII镜像的原始OUT因DWARF绝对路径不同而哈希不同，但分别执行`tiarmstrip --postlink`后均为：

`267FC34225BE5307B822B30C3402657DC2946DEA9D251533AA775BD5815EBEAF`

该哈希与v3.3的stripped OUT完全一致，说明可烧录程序映像未因本次工程修复而改变。因此下列行为全部继承v3.3：

- A段、双速度估计、DRIVE_B、B_APPROACH和固定113度BRAKE_B；
- 六PID每条有效测量并行更新，`update_mask=0x3F`；
- B点QHLD五点中位数、迟滞确认、40 ms有限脉冲与DONE只重捕获B；
- K1锁存、K2中止、80 ms视觉故障、TIMEOUT继续稳定；
- PA27、PA31/PA28、115200、`@dx\r\n/@-999\r\n`和原K230脚本。

## 软件验证摘要

- M0/状态机/联合模型：56 passed，0 failed。
- 原始K230脚本兼容检查：6 passed，0 failed；脚本SHA-256为`E32127A397766FE989B7810EC221879C252296A87D9A63DB3C329375B85F8601`。
- 静止噪声10秒：进入QHLD后非85度命令0次、新舵机事件0次、静默退出0次、任意1秒最大动作数0。
- 10/15/20度死区模型：`tDone=4.280/3.600/4.260 s`。
- 联合视觉、舵机滞后、噪声和丢包模型：`tDone=4.429 s`。
- v3.2冻结前级轨迹仍为：`hash=87843EC6, cycles=86, tA=660 ms, tB_approach=940 ms, tB_brake=1380 ms, tB_settle=1700 ms`。

这些都是软件或构建证据，不是实物计时、过冲或稳定性证据。

## 构建与内存摘要

CCS 20.4.1、TI Arm Clang 4.0.4.LTS、MSPM0 SDK 2.10.0.04和SysConfig 1.26.2完成两套独立Clean/Full Build，均为0错误。正式固件为：

`firmware/H_Q3_V331_QHOLD.out`

SRAM总容量32768字节，占用17383字节，剩余15385字节（46.95%）；`.bss=16825`、`.data=46`、stack=512、heap=0。详细路径、哈希与重建证据见`BUILD_STATUS.md`。

## 使用入口

- 最短导入、构建、烧录和启动：`START_HERE.md`
- 跨电脑构建故障分析：`PORTABLE_BUILD_FIX.md`
- 构建、固件和SRAM：`BUILD_STATUS.md`
- 参数：`PARAMETERS.md`
- 实物运行和K3日志：`HARDWARE_RUNBOOK.md`
- 单变量调参：`TUNING_GUIDE.md`
- 实物记录模板：`FIELD_TUNING_LOG.csv`
- 文件校验：`SHA256SUMS.txt`

