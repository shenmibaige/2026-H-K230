# v3.3跨电脑CCS链接失败诊断与修复

## 用户日志证据

用户日志的链接命令同时出现：

- 正常的`./ti_msp_dl_config.o`；
- `./build_logs/mirror_a/ti_msp_dl_config.o`；
- `./build_logs/mirror_b/ti_msp_dl_config.o`；
- 正常的`./device_linker.cmd`；
- 两个`../build_logs/mirror_*/device_linker.cmd`。

随后链接器报告FLASH、SRAM、BCR_CONFIG和BSL_CONFIG重复指定及重叠（`#10263/#10264`），最终`#10010`表示OUT未生成。这一因果链完整且直接，不需要假设硬件或控制算法异常。

原始日志副本：`build_logs/user_reported_compile_error.log`。

## 为什么原交付机曾能构建、另一台电脑却失败

原交付包把两套镜像的SysConfig生成源码和链接脚本作为“证据”放进CCS工程根目录下的`build_logs`。原构建产物可以在证据写入交付目录之前生成，但最终ZIP再次导入时，CCS会重新发现这些文件。原`.cproject`没有排除`build_logs`，因此新电脑重建时把证据误当成正式输入。

这也是为何预编译OUT可以存在，而同一ZIP重新Build却失败：两者对应的工程树时点不同。

## 修复动作

1. 新工程名使用`H_Q3_V331_QHOLD`，不覆盖v3.3。
2. `.cproject`源码入口显式使用：

   `excluding="build_logs|firmware|host_tests|k230_reference"`

3. 构建证据仅保留`.log/.out/.map/.xml`；不在`build_logs`中存放`.c/.cmd/.opt`。
4. 主机回归脚本把上述两项设为强制静态检查。
5. 镜像A的`build_logs`中放置故意失败的`.c/.cmd`探针后仍能成功构建，证明排除项有效；探针不会进入最终交付。
6. 镜像B在无探针条件下独立成功构建。
7. 最终包结构再次在第三个ASCII路径重建，防止“先构建成功、后放入证据又破坏工程”的问题复发。

## 行为等价证据

- 比较43个正式`.c/.h`文件：0个差异。
- 镜像A、镜像B和v3.3基线的stripped OUT SHA-256均为`267FC34225BE5307B822B30C3402657DC2946DEA9D251533AA775BD5815EBEAF`。
- 主机回归仍为56/56，K230兼容检查仍为6/6。

因此本轮是构建可迁移性修复，不是控制参数或算法版本迭代。

## 回滚

原v3.3 ZIP保持不变，可随时回退使用其中已经生成的预编译固件。若只在CCS中导入了v3.3.1但尚未烧录，关闭或从workspace移除`H_Q3_V331_QHOLD`即可；不要选择删除原工程磁盘文件。

