#ifndef HUIDU_H
#define HUIDU_H


#include "ti_msp_dl_config.h"
#include "motor.h"

uint8_t get_gpio_state(GPIO_Regs *gpio_port, uint32_t gpio);

void huidu_get_value();
void adjust_motor();

#endif
