#include "ti_msp_dl_config.h"
/**
  * 函    数：直流电机1设置速度
  * 参    数：Speed 要设置的速度，范围：-100~100
  * 返 回 值：无
  */
void Motor1_SetSpeed(int8_t Speed)
{
	if (Speed >= 0)							//如果设置正转的速度值
	{
		DL_GPIO_setPins(DC_MOTOR_AIN1_PORT, DC_MOTOR_AIN1_PIN);	                        //PA8置高电平
		DL_GPIO_clearPins(DC_MOTOR_AIN2_PORT, DC_MOTOR_AIN2_PIN);	                    //PA9置低电平，设置方向为正转
		DL_Timer_setCaptureCompareValue(MOTOR_INST ,  Speed , GPIO_MOTOR_C0_IDX);   //输出到PA12,PWM设置为速度值
	}
	else									//否则，即设置反转的速度值
	{
		DL_GPIO_clearPins(DC_MOTOR_AIN1_PORT, DC_MOTOR_AIN1_PIN);	                    //PA8置低电平
		DL_GPIO_setPins(DC_MOTOR_AIN2_PORT, DC_MOTOR_AIN2_PIN);	                        //PA9置高电平，设置方向为反转
		DL_Timer_setCaptureCompareValue(MOTOR_INST , -Speed , GPIO_MOTOR_C0_IDX);   //输出到PA12,PWM设置为负的速度值，因为此时速度值为负数，而PWM只能给正数
	}
}

/**
  * 函    数：直流电机2设置速度
  * 参    数：Speed 要设置的速度，范围：-100~100
  * 返 回 值：无
  */
void Motor2_SetSpeed(int8_t Speed)
{
	if (Speed >= 0)							//如果设置正转的速度值
	{
		DL_GPIO_setPins(DC_MOTOR_BIN1_PORT, DC_MOTOR_BIN1_PIN);	                        //PB18置高电平
		DL_GPIO_clearPins(DC_MOTOR_BIN2_PORT, DC_MOTOR_BIN2_PIN);	                    //PA7置低电平，设置方向为正转
		DL_Timer_setCaptureCompareValue(MOTOR_INST ,  Speed , GPIO_MOTOR_C1_IDX);   //输出到PA13,PWM设置为速度值
	}
	else									//否则，即设置反转的速度值
	{
		DL_GPIO_clearPins(DC_MOTOR_BIN1_PORT, DC_MOTOR_BIN1_PIN);	                    //PB18置低电平
		DL_GPIO_setPins(DC_MOTOR_BIN2_PORT, DC_MOTOR_BIN2_PIN);	                        //PA7置高电平，设置方向为反转
		DL_Timer_setCaptureCompareValue(MOTOR_INST , -Speed , GPIO_MOTOR_C1_IDX);   //输出到PA13,PWM设置为负的速度值，因为此时速度值为负数，而PWM只能给正数
	}
}