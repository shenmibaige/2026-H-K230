#include "ti_msp_dl_config.h"


int16_t Encoder_Count1,Encoder_Count2;					//全局变量，用于计数旋转编码器的增量值
int16_t status1,status2;                        //全局变量，用于接收中断标志位
/**
  * 函    数：旋转编码器初始化
  * 参    数：无
  * 返 回 值：无
  */
void Encoder_Init(void)
{
    NVIC_EnableIRQ(ENCODER_GPIOB_INT_IRQN);     //开启A1相和B2相的中断
    NVIC_EnableIRQ(ENCODER_GPIOA_INT_IRQN);     //开启A2相和B2相的中断
}

/**
  * 函    数：旋转编码器获取增量值
  * 参    数：无
  * 返 回 值：自上此调用此函数后，旋转编码器的增量值
  */
int16_t Encoder_Get1(void)
{
	/*使用Temp变量作为中继，目的是返回Encoder_Count后将其清零*/
	/*在这里，也可以直接返回Encoder_Count
	  但这样就不是获取增量值的操作方法了
	  也可以实现功能，只是思路不一样*/
	int16_t Temp;
	Temp = Encoder_Count1;
	Encoder_Count1 = 0;
	return Temp;
}
int16_t Encoder_Get2(void)
{
	/*使用Temp变量作为中继，目的是返回Encoder_Count后将其清零*/
	/*在这里，也可以直接返回Encoder_Count
	  但这样就不是获取增量值的操作方法了
	  也可以实现功能，只是思路不一样*/
	int16_t Temp;
	Temp = Encoder_Count2;
	Encoder_Count2 = 0;
	return Temp;
}
/**
  * 函    数：GPIO外部中断函数
  * 参    数：无
  * 返 回 值：无
  * 注意事项：此函数为中断函数，无需调用，中断触发后自动执行
  *           函数名为预留的指定名称，可以从启动文件复制
  *           请确保函数名正确，不能有任何差异，否则中断函数将不能进入
  */
  void GROUP1_IRQHandler()
  {
    status1=DL_GPIO_getPendingInterrupt(GPIOB);
    switch (status1) 
    {
        case ENCODER_A1_IIDX:       //判断是否是A1相触发的中断
        if (DL_GPIO_readPins(ENCODER_B1_PORT, ENCODER_B1_PIN) == 0)		//A1相上升沿触发中断，此时检测另一相B1的电平，目的是判断旋转方向
			  {
				  Encoder_Count1 --;					//此方向定义为反转，计数变量自减
			  }
        break;
        
        case ENCODER_B1_IIDX:       //判断是否是B1相触发的中断
        if (DL_GPIO_readPins(ENCODER_A1_PORT, ENCODER_A1_PIN) == 0)		//B1相上升沿触发中断，此时检测另一相A1的电平，目的是判断旋转方向
			  {
				  Encoder_Count1 ++;					//此方向定义为正转，计数变量自增
			  }
        break;
    }
    status2=DL_GPIO_getPendingInterrupt(GPIOA);
    switch (status2) 
    {
        case ENCODER_A2_IIDX:       //判断是否是A2相触发的中断
        if (DL_GPIO_readPins(ENCODER_B2_PORT, ENCODER_B2_PIN) == 0)		//A2相上升沿触发中断，此时检测另一相B2的电平，目的是判断旋转方向
			  {
				  Encoder_Count2 --;					//此方向定义为反转，计数变量自减
			  }
        break;
        
        case ENCODER_B2_IIDX:       //判断是否是B2相触发的中断
        if (DL_GPIO_readPins(ENCODER_A2_PORT, ENCODER_A2_PIN) == 0)		//B2相上升沿触发中断，此时检测另一相A2的电平，目的是判断旋转方向
			  {
				  Encoder_Count2 ++;					//此方向定义为正转，计数变量自增
			  }
        break;
    }
  }
  