/*
 * Combined balance car: K1 starts line tracking and ball centering together.
 * The two control loops use independent PID implementations.
 */

#include "ti_msp_dl_config.h"
#include "delay.h"
#include "oled.h"
#include <stdio.h>
#include <string.h>
#include "uart.h"
#include "key.h"
#include "pid.h"
#include "servo.h"
#include "motor.h"
#include "encoder.h"
#include "huidu.h"
#include "curve_control.h"
#include "curve_params.h"

/* Servo 85 degrees corresponds to a level tube. */
#define BALL_SERVO_CENTER_ANGLE   85.0f

/* Physical output limit from servo 20..150 degrees. */
#define BALL_SERVO_MAX_OUT_ABS    65.0f

/* Temporary observation scale. Set back to 1.0f after tuning. */
#define BALL_PID_AGGRESSIVE_SCALE 5.0f

/* K230 dx normally stays within -225..+225; -999 means lost ball. */
#define BALL_DX_INVALID           (-999)
#define BALL_DX_MAX_ABS           450

/* Control goal: hold the ball within +/-1 cm; K230 calibration is 60 px/cm. */
#define BALL_TARGET_DX_PX         0.0f
#define BALL_HOLD_LIMIT_PX        60.0f

/* Six PID stages by |dx|. */
#define BALL_STAGE1_MAX_PX        10.0f
#define BALL_STAGE2_MAX_PX        30.0f
#define BALL_STAGE3_MAX_PX        60.0f
#define BALL_STAGE4_MAX_PX        100.0f
#define BALL_STAGE5_MAX_PX        160.0f
#define BALL_STAGE6_MAX_PX        9999.0f

/* Stage 1: 0-10 px, fine trim around center. */
#define BALL_S1_KP                0.020f
#define BALL_S1_KI                0.0012f
#define BALL_S1_KD                1.4f
#define BALL_S1_OUT               8.0f
#define BALL_S1_DELTA             1.0f

/* Stage 2: 10-30 px, smooth correction. */
#define BALL_S2_KP                0.028f
#define BALL_S2_KI                0.0008f
#define BALL_S2_KD                1.3f
#define BALL_S2_OUT               12.0f
#define BALL_S2_DELTA             1.5f

/* Stage 3: 30-60 px, inside the required +/-1 cm boundary. */
#define BALL_S3_KP                0.035f
#define BALL_S3_KI                0.0005f
#define BALL_S3_KD                1.2f
#define BALL_S3_OUT               20.0f
#define BALL_S3_DELTA             2.5f

/* Stage 4: 60-100 px, return from just outside the boundary. */
#define BALL_S4_KP                0.045f
#define BALL_S4_KI                0.0003f
#define BALL_S4_KD                1.1f
#define BALL_S4_OUT               35.0f
#define BALL_S4_DELTA             4.0f

/* Stage 5: 100-160 px, stronger pull back. */
#define BALL_S5_KP                0.055f
#define BALL_S5_KI                0.0f
#define BALL_S5_KD                1.0f
#define BALL_S5_OUT               45.0f
#define BALL_S5_DELTA             6.0f

/* Stage 6: >160 px, strongest pull back with limited servo ramp. */
#define BALL_S6_KP                0.070f
#define BALL_S6_KI                0.0f
#define BALL_S6_KD                1.0f
#define BALL_S6_OUT               55.0f
#define BALL_S6_DELTA             8.0f

/* Derivative smoothing and output deadband. */
#define BALL_PID_DERIVATIVE_ALPHA 0.40f
#define BALL_PID_OUT_DEADBAND     0.08f

/* True center hold: no output and no integral while dx and speed are tiny. */
#define BALL_PID_DX_DEADBAND      2.0f
#define BALL_PID_SPEED_DEADBAND   0.50f

/* Integral is enabled inside the 1 cm window at low speed only. */
#define BALL_PID_INTEGRAL_ERR_MAX    60.0f
#define BALL_PID_INTEGRAL_SPEED_MAX  0.30f

/* Startup inertia compensation: use ball velocity to raise the PID stage
 * and servo response for about 3 s after the car starts, then fade out. */
#define BALL_STARTUP_STABILIZE_MS     3000U
#define BALL_STARTUP_FADE_MS          500U
#define BALL_STARTUP_VEL_STAGE_GAIN   10.0f
#define BALL_STARTUP_DERIVATIVE_ALPHA 0.18f

typedef struct
{
    CurveControlOutput curve;
    int32_t encoder1_delta;
    int32_t encoder2_delta;
    uint32_t uptime_ms;
} ControlTelemetry;

static CurveControl g_curve;
static volatile ControlTelemetry g_telemetry;
static volatile uint32_t g_uptime_ms;
static uint8_t g_control_divider;
static uint8_t g_curve_start_pending;
static uint32_t g_ball_start_ms;

volatile int Ball_Dx = 0;             /* Ball offset from K230 */
volatile uint32_t UART_RxCount = 0;   /* Received frame counter for debug */
volatile float Ball_Servo_Angle = BALL_SERVO_CENTER_ANGLE;
volatile uint8_t Ball_Control_Enable = 0; /* K1 enables ball PID */
volatile uint8_t Ball_Within1cm = 0;      /* 1 when |dx| <= 60 px */
PID_t Ball_PID;

typedef struct {
    float MaxAbsDx;
    float Kp;
    float Ki;
    float Kd;
    float OutMax;
    float OutDelta;
} Ball_PidStage;

static const Ball_PidStage Ball_PidStages[6] = {
    {BALL_STAGE1_MAX_PX, BALL_S1_KP, BALL_S1_KI, BALL_S1_KD, BALL_S1_OUT, BALL_S1_DELTA},
    {BALL_STAGE2_MAX_PX, BALL_S2_KP, BALL_S2_KI, BALL_S2_KD, BALL_S2_OUT, BALL_S2_DELTA},
    {BALL_STAGE3_MAX_PX, BALL_S3_KP, BALL_S3_KI, BALL_S3_KD, BALL_S3_OUT, BALL_S3_DELTA},
    {BALL_STAGE4_MAX_PX, BALL_S4_KP, BALL_S4_KI, BALL_S4_KD, BALL_S4_OUT, BALL_S4_DELTA},
    {BALL_STAGE5_MAX_PX, BALL_S5_KP, BALL_S5_KI, BALL_S5_KD, BALL_S5_OUT, BALL_S5_DELTA},
    {BALL_STAGE6_MAX_PX, BALL_S6_KP, BALL_S6_KI, BALL_S6_KD, BALL_S6_OUT, BALL_S6_DELTA}
};

static float Ball_AbsF(float v)
{
    return (v < 0.0f) ? -v : v;
}

static float Ball_StartupProgressFade(void)
{
    uint32_t elapsed;

    if (g_ball_start_ms == 0U)
    {
        return 0.0f;
    }

    elapsed = g_uptime_ms - g_ball_start_ms;
    if (elapsed >= BALL_STARTUP_STABILIZE_MS + BALL_STARTUP_FADE_MS)
    {
        return 0.0f;
    }
    if (elapsed < BALL_STARTUP_STABILIZE_MS)
    {
        return 1.0f;
    }

    return (float)(BALL_STARTUP_STABILIZE_MS + BALL_STARTUP_FADE_MS - elapsed)
         / (float)BALL_STARTUP_FADE_MS;
}

static float Ball_StartupStageGain(void)
{
    return BALL_STARTUP_VEL_STAGE_GAIN * Ball_StartupProgressFade();
}

static void Ball_UpdateDerivativeAlpha(void)
{
    float startupFactor = Ball_StartupProgressFade();

    Ball_PID.DerivativeAlpha = BALL_STARTUP_DERIVATIVE_ALPHA
        + (BALL_PID_DERIVATIVE_ALPHA - BALL_STARTUP_DERIVATIVE_ALPHA)
          * (1.0f - startupFactor);
}

/* Select one of the six ball PID stages by |dx|. */
static void Ball_UpdatePidGains(float absDx, float absDeriv, float velocityStageGain)
{
    uint8_t i;
    float outMax;
    float effectiveDx;

    effectiveDx = absDx + absDeriv * velocityStageGain;
    if (effectiveDx > BALL_STAGE6_MAX_PX)
    {
        effectiveDx = BALL_STAGE6_MAX_PX;
    }

    for (i = 0; i < 6; i++)
    {
        if (effectiveDx <= Ball_PidStages[i].MaxAbsDx)
        {
            Ball_PID.Kp = Ball_PidStages[i].Kp * BALL_PID_AGGRESSIVE_SCALE;
            Ball_PID.Ki = Ball_PidStages[i].Ki * BALL_PID_AGGRESSIVE_SCALE;
            Ball_PID.Kd = Ball_PidStages[i].Kd * BALL_PID_AGGRESSIVE_SCALE;
            Ball_PID.OutputDeltaMax = Ball_PidStages[i].OutDelta * BALL_PID_AGGRESSIVE_SCALE;

            outMax = Ball_PidStages[i].OutMax * BALL_PID_AGGRESSIVE_SCALE;
            if (outMax > BALL_SERVO_MAX_OUT_ABS)
            {
                outMax = BALL_SERVO_MAX_OUT_ABS;
            }
            Ball_PID.OutMax = outMax;
            Ball_PID.OutMin = -outMax;
            return;
        }
    }

    /* Last stage is the fallback if the table changes in the future. */
    Ball_PID.Kp = BALL_S6_KP * BALL_PID_AGGRESSIVE_SCALE;
    Ball_PID.Ki = BALL_S6_KI * BALL_PID_AGGRESSIVE_SCALE;
    Ball_PID.Kd = BALL_S6_KD * BALL_PID_AGGRESSIVE_SCALE;
    Ball_PID.OutputDeltaMax = BALL_S6_DELTA * BALL_PID_AGGRESSIVE_SCALE;
    Ball_PID.OutMax = BALL_SERVO_MAX_OUT_ABS;
    Ball_PID.OutMin = -BALL_SERVO_MAX_OUT_ABS;
}

/* Parse K230 integer dx without calling scanf inside the timer ISR. */
static int Ball_ParseDx(const volatile char *packet)
{
    int sign = 1;
    int value = 0;
    const volatile char *p = packet;

    if (*p == '-')
    {
        sign = -1;
        p++;
    }
    else if (*p == '+')
    {
        p++;
    }

    if (*p < '0' || *p > '9')
    {
        return BALL_DX_INVALID;
    }

    while (*p >= '0' && *p <= '9')
    {
        int digit = *p - '0';
        if (value > (10000 - digit) / 10)
        {
            return BALL_DX_INVALID;
        }
        value = value * 10 + digit;
        p++;
    }

    if (*p != '\0')
    {
        return BALL_DX_INVALID;
    }

    return sign * value;
}

/* Consume one K230 frame and update the servo from the ball PID. */
static void Ball_Control_Tick(void)
{
    static uint8_t Ball_ValidPrev = 0;
    float absDx;
    float absDeriv;
    int parsedDx;
    float errorNow;
    float filteredDeriv;
    float rawDeriv;
    float stageGain;

    if (UART_RxFlag != 1)
    {
        return;
    }

    parsedDx = Ball_ParseDx(UART_RxPacket);

    /* Parse first, then clear the flag so the UART ISR cannot overwrite
     * the packet while it is being processed. */
    UART_RxFlag = 0;
    Ball_Dx = parsedDx;
    UART_RxCount++;

    if (!Ball_Control_Enable)
    {
        Ball_ValidPrev = 0;
        return;
    }

    if (parsedDx < -BALL_DX_MAX_ABS || parsedDx > BALL_DX_MAX_ABS)
    {
        Ball_ValidPrev = 0;
        return;
    }

    absDx = (float)(parsedDx < 0 ? -parsedDx : parsedDx);
    Ball_Within1cm = (absDx <= BALL_HOLD_LIMIT_PX) ? 1u : 0u;

    /* Clear old integral/derivative state after a lost-ball gap. */
    if (!Ball_ValidPrev)
    {
        Ball_PID.ErrorInt = 0.0f;
        Ball_PID.Out = 0.0f;
        Ball_PID.ErrorDerivativeFiltered = 0.0f;
        Ball_PID.Actual = (float)parsedDx;

        /* First frame derivative is zero to avoid a jump after re-acquire. */
        Ball_PID.Error0 = Ball_PID.Target - Ball_PID.Actual;
        Ball_PID.Error1 = Ball_PID.Error0;
        Ball_ValidPrev = 1;
    }
    else
    {
        Ball_PID.Actual = (float)parsedDx;
    }

    Ball_UpdateDerivativeAlpha();
    stageGain = Ball_StartupStageGain();

    /* Compute the current filtered derivative so startup velocity can be
     * used to raise the stage before PID_Update() runs. */
    errorNow = Ball_PID.Target - Ball_PID.Actual;
    rawDeriv = errorNow - Ball_PID.Error0;
    filteredDeriv = Ball_PID.DerivativeAlpha * Ball_PID.ErrorDerivativeFiltered
                  + (1.0f - Ball_PID.DerivativeAlpha) * rawDeriv;
    absDeriv = Ball_AbsF(filteredDeriv);

    Ball_UpdatePidGains(absDx, absDeriv, stageGain);

    /* Integral is only for small residual offsets near center. During a fast
     * approach it fights derivative braking and causes center oscillation. */
    Ball_PID.IntegralHold = (absDx > BALL_PID_INTEGRAL_ERR_MAX) ||
                            (absDeriv > BALL_PID_INTEGRAL_SPEED_MAX);

    PID_Update(&Ball_PID);

    /* Hold still only when the ball is essentially centered and not moving. */
    if (absDx <= BALL_PID_DX_DEADBAND &&
        Ball_AbsF(Ball_PID.ErrorDerivativeFiltered) <= BALL_PID_SPEED_DEADBAND)
    {
        Ball_PID.Out = 0.0f;
        Ball_PID.ErrorInt = 0.0f;
    }
    else if (Ball_AbsF(Ball_PID.Out) < BALL_PID_OUT_DEADBAND)
    {
        Ball_PID.Out = 0.0f;
    }

    /* dx<0 means the ball is near the servo end; output below 85 pushes it
     * back toward the hinge end. */
    Ball_Servo_Angle = BALL_SERVO_CENTER_ANGLE - Ball_PID.Out;
    Servo_SetAngle1(Ball_Servo_Angle);
}

static uint8_t Main_IsRunState(CurveRaceState state)
{
    return ((state == CURVE_STATE_STARTING) ||
            (state == CURVE_STATE_RUNNING) ||
            (state == CURVE_STATE_FINISH_ARMED))
               ? 1U
               : 0U;
}

static ControlTelemetry Main_ReadTelemetry(void)
{
    ControlTelemetry snapshot;
    uint32_t primask = __get_PRIMASK();

    __disable_irq();
    snapshot.curve = g_telemetry.curve;
    snapshot.encoder1_delta = g_telemetry.encoder1_delta;
    snapshot.encoder2_delta = g_telemetry.encoder2_delta;
    snapshot.uptime_ms = g_telemetry.uptime_ms;
    if ((primask & 1U) == 0U)
    {
        __enable_irq();
    }
    return snapshot;
}

static void Main_PublishTelemetry(
    CurveControlOutput output,
    int32_t encoder1_delta,
    int32_t encoder2_delta)
{
    g_telemetry.curve = output;
    g_telemetry.encoder1_delta = encoder1_delta;
    g_telemetry.encoder2_delta = encoder2_delta;
    g_telemetry.uptime_ms = g_uptime_ms;
}

static void Main_RenderOled(const ControlTelemetry *snapshot)
{
    int32_t error_mm;
    const char *ball_status;

    if (snapshot == 0)
    {
        return;
    }

    error_mm =
        (int32_t)snapshot->curve.error_mm_q8 / CURVE_Q8_SCALE;

    if (!Ball_Control_Enable)
    {
        ball_status = "STOP";
    }
    else if (Ball_Within1cm)
    {
        ball_status = "OK";
    }
    else
    {
        ball_status = "RUN";
    }

    OLED_Printf(0, 0, 16, "%s T%02u.%u",
                CurveControl_StateName(snapshot->curve.state),
                snapshot->curve.elapsed_ms / 1000U,
                (snapshot->curve.elapsed_ms % 1000U) / 100U);
    OLED_Printf(0, 16, 16, "M=%02u F=%02u E=%d",
                snapshot->curve.raw_mask,
                snapshot->curve.filtered_mask,
                error_mm);
    OLED_Printf(0, 32, 16, "U=%d D=%4d",
                snapshot->curve.turn_pwm,
                Ball_Dx);
    OLED_Printf(0, 48, 16, "L=%d R=%d %s",
                snapshot->curve.left_pwm,
                snapshot->curve.right_pwm,
                ball_status);
    OLED_Refresh();
}

int main(void)
{
    uint32_t last_oled_ms = UINT32_MAX;

    SYSCFG_DL_init();
    OLED_Init();
    OLED_ColorTurn(0U);
    OLED_DisplayTurn(0U);
    OLED_Clear();

    /* Initialize ball-centering PID. */
    Ball_PID.Target = BALL_TARGET_DX_PX;
    Ball_PID.Actual = 0.0f;
    Ball_PID.Out = 0.0f;
    Ball_PID.Error0 = 0.0f;
    Ball_PID.Error1 = 0.0f;
    Ball_PID.ErrorInt = 0.0f;
    Ball_PID.ErrorDerivativeFiltered = 0.0f;
    Ball_PID.DerivativeAlpha = BALL_PID_DERIVATIVE_ALPHA;
    Ball_PID.IntegralHold = 0;
    Ball_UpdatePidGains(0.0f, 0.0f, 0.0f);

    /* Initialize line-tracking state machine and PID. */
    CurveControl_Init(&g_curve);
    g_uptime_ms = 0U;
    g_control_divider = 0U;
    g_curve_start_pending = 0U;
    g_ball_start_ms = 0U;

    DL_Timer_startCounter(MOTOR_INST);
    Motor_StopSafe();
    Encoder_Init();

    NVIC_EnableIRQ(Serial_INST_INT_IRQN);
    DL_Timer_startCounter(TIMER_PID_INST);
    NVIC_EnableIRQ(TIMER_PID_INST_INT_IRQN);
    DL_Timer_startCounter(SERVO_INST);

    Servo_SetAngle1(BALL_SERVO_CENTER_ANGLE);

    Main_PublishTelemetry(
        CurveControl_GetOutput(&g_curve),
        0L,
        0L);

    while (1)
    {
        ControlTelemetry snapshot = Main_ReadTelemetry();

        if ((last_oled_ms == UINT32_MAX) ||
            ((snapshot.uptime_ms - last_oled_ms) >=
             CURVE_OLED_REFRESH_MS))
        {
            last_oled_ms = snapshot.uptime_ms;
            Main_RenderOled(&snapshot);
        }
    }
}

void TIMER_PID_INST_IRQHandler(void)
{
    if (DL_TimerA_getPendingInterrupt(TIMER_PID_INST) ==
        DL_TIMER_IIDX_LOAD)
    {
        CurveControlOutput output;
        CurveRaceState state_before_sample;
        uint8_t key_num;

        Key_Tick();
        g_uptime_ms++;
        key_num = Key_GetNum();

        /* K4 has priority and stops both line tracking and ball control. */
        if ((Key_IsPressed(CURVE_KEY_EMERGENCY_STOP) != 0U) ||
            (key_num == CURVE_KEY_EMERGENCY_STOP))
        {
            CurveControl_StopImmediate(
                &g_curve,
                CURVE_FAULT_EMERGENCY_STOP);
            Motor_StopSafe();
            Ball_Control_Enable = 0U;
            Ball_PID.Out = 0.0f;
            Ball_PID.ErrorInt = 0.0f;
            Ball_PID.ErrorDerivativeFiltered = 0.0f;
            Ball_Servo_Angle = BALL_SERVO_CENTER_ANGLE;
            Servo_SetAngle1(Ball_Servo_Angle);
            g_control_divider = 0U;
            g_curve_start_pending = 0U;
            g_ball_start_ms = 0U;
            Main_PublishTelemetry(
                CurveControl_GetOutput(&g_curve),
                0L,
                0L);
            return;
        }

        huidu_get_value();
        Ball_Control_Tick();

        state_before_sample =
            CurveControl_GetOutput(&g_curve).state;
        CurveControl_PushSample1ms(
            &g_curve,
            huidu_get_mask());
        output = CurveControl_GetOutput(&g_curve);

        /* Fast raw finish path stops the motors immediately. */
        if ((state_before_sample ==
             CURVE_STATE_FINISH_ARMED) &&
            (output.state == CURVE_STATE_STOPPED) &&
            (output.finish_trigger ==
             CURVE_FINISH_TRIGGER_RAW_FAST))
        {
            Motor_StopSafe();
            g_control_divider = 0U;
            Main_PublishTelemetry(
                output,
                0L,
                0L);
            return;
        }

        /* K1 starts both functions at the same time. */
        if (key_num == CURVE_KEY_START)
        {
            Ball_Servo_Angle = BALL_SERVO_CENTER_ANGLE;
            Servo_SetAngle1(Ball_Servo_Angle);
            if (Ball_Control_Enable == 0U)
            {
                g_ball_start_ms = g_uptime_ms;
            }
            Ball_Control_Enable = 1U;

            if ((CurveControl_GetOutput(&g_curve).state == CURVE_STATE_WAIT) ||
                (CurveControl_GetOutput(&g_curve).state == CURVE_STATE_STOPPED) ||
                (CurveControl_GetOutput(&g_curve).state == CURVE_STATE_FAULT))
            {
                g_curve_start_pending = 1U;
            }
        }

        if (g_curve_start_pending != 0U)
        {
            if (CurveControl_Start(&g_curve) != 0U)
            {
                g_curve_start_pending = 0U;
                Encoder_Reset();
            }
            else if ((CurveControl_GetOutput(&g_curve).state != CURVE_STATE_WAIT) &&
                     (CurveControl_GetOutput(&g_curve).state != CURVE_STATE_STOPPED) &&
                     (CurveControl_GetOutput(&g_curve).state != CURVE_STATE_FAULT))
            {
                g_curve_start_pending = 0U;
            }
        }

        g_control_divider++;
        if (g_control_divider >= CURVE_CONTROL_PERIOD_MS)
        {
            int32_t encoder1_delta;
            int32_t encoder2_delta;

            g_control_divider = 0U;
            output = CurveControl_Step5ms(&g_curve);
            encoder1_delta = Encoder_ReadDelta1();
            encoder2_delta = Encoder_ReadDelta2();

            if (Main_IsRunState(output.state) != 0U)
            {
                Motor1_SetSpeed(output.right_pwm);
                Motor2_SetSpeed(output.left_pwm);
            }
            else
            {
                Motor_StopSafe();
            }

            Main_PublishTelemetry(
                output,
                encoder1_delta,
                encoder2_delta);
        }
        else if (key_num != 0U)
        {
            Main_PublishTelemetry(
                CurveControl_GetOutput(&g_curve),
                g_telemetry.encoder1_delta,
                g_telemetry.encoder2_delta);
        }
    }
}
