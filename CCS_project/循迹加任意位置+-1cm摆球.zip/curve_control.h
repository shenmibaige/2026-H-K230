#ifndef CURVE_CONTROL_H
#define CURVE_CONTROL_H

#include <stdint.h>

#include "curve_params.h"
#include "curve_pid.h"

typedef enum
{
    CURVE_STATE_WAIT = 0,
    CURVE_STATE_STARTING,
    CURVE_STATE_RUNNING,
    CURVE_STATE_FINISH_ARMED,
    CURVE_STATE_STOP_DELAY,
    CURVE_STATE_STOPPED,
    CURVE_STATE_FAULT
} CurveRaceState;

typedef enum
{
    CURVE_FAULT_NONE = 0,
    CURVE_FAULT_EMERGENCY_STOP,
    CURVE_FAULT_HARD_TIMEOUT
} CurveControlFault;

typedef enum
{
    CURVE_FINISH_TRIGGER_NONE = 0,
    CURVE_FINISH_TRIGGER_RAW_FAST,
    CURVE_FINISH_TRIGGER_FILTERED_FALLBACK
} CurveFinishTrigger;

typedef struct
{
    CurveRaceState state;
    CurveControlFault fault;
    uint32_t elapsed_ms;
    uint32_t stop_delay_start_ms;
    uint8_t raw_mask;
    uint8_t filtered_mask;
    uint8_t start_line_cleared;
    uint8_t finish_confirm_count;
    uint8_t raw_finish_count;
    uint8_t approach_stage;
    CurveFinishTrigger finish_trigger;
    uint8_t gap_hold;
    int16_t error_mm_q8;
    int16_t turn_pwm;
    int16_t left_target_pwm;
    int16_t right_target_pwm;
    int16_t left_pwm;
    int16_t right_pwm;
} CurveControlOutput;

typedef struct
{
    Curve_PID_t line_pid;
    CurveControlOutput output;
    uint8_t history[CURVE_SENSOR_COUNT];
    uint8_t sample_count;
    uint8_t clear_count;
} CurveControl;

void CurveControl_Init(CurveControl *control);
uint8_t CurveControl_Start(CurveControl *control);
void CurveControl_PushSample1ms(CurveControl *control, uint8_t raw_mask);
CurveControlOutput CurveControl_Step5ms(CurveControl *control);
void CurveControl_StopImmediate(
    CurveControl *control,
    CurveControlFault fault);
CurveControlOutput CurveControl_GetOutput(const CurveControl *control);
const char *CurveControl_StateName(CurveRaceState state);

/* Pure helpers exposed for deterministic host tests. */
uint8_t CurveControl_FilteredMask(const CurveControl *control);
int16_t CurveControl_ErrorMmQ8(uint8_t filtered_mask);

#endif
